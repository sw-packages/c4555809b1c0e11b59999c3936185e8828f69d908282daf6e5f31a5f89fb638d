// Copyright 2024 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef GOOGLE_CLOUD_CPP_GOOGLE_CLOUD_STORAGE_INTERNAL_GRPC_METRICS_EXPORTER_OPTIONS_H
#define GOOGLE_CLOUD_CPP_GOOGLE_CLOUD_STORAGE_INTERNAL_GRPC_METRICS_EXPORTER_OPTIONS_H

#ifdef GOOGLE_CLOUD_CPP_STORAGE_WITH_OTEL_METRICS

#include "google/cloud/options.h"
#include "google/cloud/project.h"
#include "google/cloud/version.h"
#include <opentelemetry/sdk/resource/resource.h>

namespace google {
namespace cloud {
namespace storage_internal {
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_BEGIN

/**
 * Instruments whose name starts with this prefix are published under the
 * Google-owned internal namespace.
 *
 * gRPC's instruments are published under `storage.googleapis.com/client/`,
 * which is customer-visible. Instruments created by this library go to
 * `storage.googleapis.com/internal/client/` instead, mirroring
 * `bigtable.googleapis.com/internal/client/`.
 */
auto constexpr kInternalMetricPrefix = "internal/client/";

/// Returns the monitoring exporter options given the project and resource.
Options MetricsExporterOptions(
    Project const& project,
    opentelemetry::sdk::resource::Resource const& resource);

/// Returns the monitoring exporter connection options given the fully populated
/// storage options.
Options MetricsExporterConnectionOptions(Options const& options);

#endif  // GOOGLE_CLOUD_CPP_STORAGE_WITH_OTEL_METRICS

GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_END
}  // namespace storage_internal
}  // namespace cloud
}  // namespace google

#endif  // GOOGLE_CLOUD_CPP_GOOGLE_CLOUD_STORAGE_INTERNAL_GRPC_METRICS_EXPORTER_OPTIONS_H
