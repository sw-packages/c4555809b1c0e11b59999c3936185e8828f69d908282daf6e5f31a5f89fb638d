// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "google/cloud/storage/internal/async/writer_connection_resumed.h"
#include "google/cloud/storage/async/retry_policy.h"
#include "google/cloud/storage/internal/async/write_payload_impl.h"
#include "google/cloud/storage/internal/async/writer_connection_impl.h"
#include "google/cloud/future.h"
#include "google/cloud/internal/make_status.h"
#include "google/cloud/status.h"
#include "google/cloud/status_or.h"
#include "absl/strings/cord.h"
#include <cstdint>
#include <deque>
#include <memory>
#include <mutex>
#include <variant>
#include <vector>

namespace google {
namespace cloud {
namespace storage_internal {
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_BEGIN
namespace {

Status MakeRewindError(std::int64_t resend_offset, std::int64_t persisted_size,
                       internal::ErrorInfoBuilder eib) {
  auto const previous = std::to_string(resend_offset);
  auto const returned = std::to_string(persisted_size);
  return internal::InternalError(
      "server persisted_size rewind. This indicates a bug in the client library"
      " or the service.",
      std::move(eib)
          .WithMetadata("gcloud-cpp.storage.resend_offset", previous)
          .WithMetadata("gcloud-cpp.storage.persisted_size", returned));
}

Status MakeFastForwardError(std::int64_t resend_offset,
                            std::int64_t persisted_size,
                            internal::ErrorInfoBuilder eib) {
  auto const previous = std::to_string(resend_offset);
  auto const returned = std::to_string(persisted_size);
  return internal::InternalError(
      "server persisted_size too high. This can be caused by concurrent"
      " uploads using the same upload id. Most likely an application bug.",
      std::move(eib)
          .WithMetadata("gcloud-cpp.storage.resend_offset", previous)
          .WithMetadata("gcloud-cpp.storage.persisted_size", returned));
}

bool IsPermanentFailure(Options const& options, Status const& status) {
  if (options.has<storage::AsyncRetryPolicyOption>() &&
      options.get<storage::AsyncRetryPolicyOption>() != nullptr) {
    return options.get<storage::AsyncRetryPolicyOption>()->IsPermanentFailure(
        status);
  }
  return storage::internal::AsyncStatusTraits::IsPermanentFailure(status);
}

class AsyncWriterConnectionResumedState
    : public std::enable_shared_from_this<AsyncWriterConnectionResumedState> {
 public:
  AsyncWriterConnectionResumedState(
      WriterResultFactory factory,
      std::unique_ptr<storage::AsyncWriterConnection> impl,
      google::storage::v2::BidiWriteObjectRequest initial_request,
      std::shared_ptr<storage::internal::HashFunction> hash_function,
      google::storage::v2::BidiWriteObjectResponse const& first_response,
      Options const& options, std::size_t buffer_size_lwm,
      std::size_t buffer_size_hwm)
      : factory_(std::move(factory)),
        impl_(std::move(impl)),
        initial_request_(std::move(initial_request)),
        hash_function_(std::move(hash_function)),
        options_(internal::MakeImmutableOptions(options)),
        first_response_(std::move(first_response)),
        buffer_size_lwm_(buffer_size_lwm),
        buffer_size_hwm_(buffer_size_hwm) {
    finalized_future_ = finalized_.get_future();
    closed_future_ = closed_.get_future();
    auto state = impl_->PersistedState();
    if (std::holds_alternative<google::storage::v2::Object>(state)) {
      buffer_offset_ = std::get<google::storage::v2::Object>(state).size();
    } else {
      buffer_offset_ = std::get<std::int64_t>(state);
    }
    if (first_response_.has_write_handle()) {
      latest_write_handle_ = first_response_.write_handle();
    } else if (initial_request_.has_append_object_spec() &&
               initial_request_.append_object_spec().has_write_handle()) {
      latest_write_handle_ =
          initial_request_.append_object_spec().write_handle();
    }
  }

  void Cancel() {
    std::unique_lock<std::mutex> lk(mu_);
    cancelled_ = true;
    auto impl = Impl(lk);
    lk.unlock();
    return impl->Cancel();
  }

  std::string UploadId() const {
    return UploadId(std::unique_lock<std::mutex>(mu_));
  }

  std::optional<google::storage::v2::BidiWriteHandle> WriteHandle() const {
    std::unique_lock<std::mutex> lk(mu_);
    return latest_write_handle_;
  }

  std::variant<std::int64_t, google::storage::v2::Object> PersistedState()
      const {
    return Impl(std::unique_lock<std::mutex>(mu_))->PersistedState();
  }

  future<Status> Write(storage::WritePayload const& p) {
    std::unique_lock<std::mutex> lk(mu_);
    resend_buffer_.Append(WritePayloadImpl::GetImpl(p));
    return HandleNewData(std::move(lk));
  }

  future<StatusOr<google::storage::v2::Object>> Finalize(
      storage::WritePayload const& p) {
    std::unique_lock<std::mutex> lk(mu_);
    if (finalize_called_) {
      return make_ready_future(StatusOr<google::storage::v2::Object>(
          internal::FailedPreconditionError("Finalize() already called",
                                            GCP_ERROR_INFO())));
    }
    if (close_called_) {
      return make_ready_future(StatusOr<google::storage::v2::Object>(
          internal::FailedPreconditionError(
              "Finalize() cannot be called after Close()", GCP_ERROR_INFO())));
    }
    finalize_called_ = true;
    resend_buffer_.Append(WritePayloadImpl::GetImpl(p));
    finalize_ = true;
    HandleNewData(std::move(lk));
    // Return the unique future associated with this finalization.
    return std::move(finalized_future_);
  }

  future<Status> Flush(storage::WritePayload const& p) {
    std::unique_lock<std::mutex> lk(mu_);
    // Create a new promise for this flush operation.
    promise<Status> current_flush_promise;
    auto f = current_flush_promise.get_future();
    resend_buffer_.Append(WritePayloadImpl::GetImpl(p));
    auto const target_offset =
        buffer_offset_ + static_cast<std::int64_t>(resend_buffer_.size());
    pending_flush_promises_.push_back(
        PendingFlush{std::move(current_flush_promise), target_offset});

    flush_ = true;
    HandleNewData(std::move(lk), true);
    // Return the future associated with the new promise.
    return f;
  }

  future<Status> Close(storage::WritePayload const& p) {
    std::unique_lock<std::mutex> lk(mu_);
    if (close_called_) {
      return make_ready_future(internal::FailedPreconditionError(
          "Close() already called", GCP_ERROR_INFO()));
    }
    if (finalize_called_) {
      return make_ready_future(internal::FailedPreconditionError(
          "Close() cannot be called after Finalize()", GCP_ERROR_INFO()));
    }
    close_called_ = true;
    resend_buffer_.Append(WritePayloadImpl::GetImpl(p));
    close_ = true;
    // Force flush to drain the buffer first.
    HandleNewData(std::move(lk), true);
    return std::move(closed_future_);
  }

  future<StatusOr<std::int64_t>> Query() {
    return Impl(std::unique_lock<std::mutex>(mu_))->Query();
  }

  RpcMetadata GetRequestMetadata() {
    return Impl(std::unique_lock<std::mutex>(mu_))->GetRequestMetadata();
  }

 private:
  std::weak_ptr<AsyncWriterConnectionResumedState> WeakFromThis() {
    return shared_from_this();
  }

  // Cannot use `std::function<>` because we need to capture a move-only
  // `promise<Status>`. Cannot use `absl::AnyInvocable<>` because we need to
  // support versions of Abseil that lack such a class.
  struct BufferShrinkHandler {
    virtual ~BufferShrinkHandler() = default;
    virtual void Execute(Status status) = 0;
  };

  static std::unique_ptr<BufferShrinkHandler> MakeLwmWaiter(promise<Status> p) {
    struct Impl : public BufferShrinkHandler {
      promise<Status> p;

      explicit Impl(promise<Status> pr) : p(std::move(pr)) {}
      ~Impl() override = default;
      void Execute(Status status) override { p.set_value(std::move(status)); }
    };
    return std::make_unique<Impl>(std::move(p));
  }

  future<Status> HandleNewData(std::unique_lock<std::mutex> lk,
                               bool flush = false) {
    if (!resume_status_.ok()) return make_ready_future(resume_status_);
    auto const buffer_size = resend_buffer_.size();
    // `NeedsFlush()` stays true while `Flush()` calls are pending, so a small
    // `Write()`, possibly chained from a callback, cannot turn a queued flush
    // into a plain write. The explicit low-water mark check preserves the
    // existing behavior for an empty `Write()` when the low-water mark is 0.
    flush_ = flush || NeedsFlush(lk) || buffer_size >= buffer_size_lwm_;
    auto result = make_ready_future(Status{});
    if (buffer_size >= buffer_size_hwm_) {
      auto p = promise<Status>();
      result = p.get_future();
      flush_handlers_.push_back(MakeLwmWaiter(std::move(p)));
    }
    StartWriting(std::move(lk));
    return result;
  }

  void StartWriting(std::unique_lock<std::mutex> lk) {
    // The connection may have failed permanently while a callback ran, e.g.,
    // a chained operation failed inline. Never write on a failed connection.
    if (!resume_status_.ok()) return;
    WriteLoop(std::move(lk));
  }

  /**
   * Notifies @p handlers and @p flushes with the lock released, then restarts
   * the write loop.
   *
   * Callbacks may re-enter this class and complete another flush inline,
   * which calls this function recursively. Notifications are delivered in
   * FIFO order from the outermost call, so a flush future never completes
   * before an earlier one and the recursion depth stays bounded.
   */
  void NotifyAndStartWriting(
      std::unique_lock<std::mutex> lk,
      std::vector<std::unique_ptr<BufferShrinkHandler>> handlers,
      std::vector<promise<Status>> flushes, Status const& result) {
    for (auto& h : handlers) {
      pending_notifications_.push_back({std::move(h), Status{}});
    }
    for (auto& f : flushes) {
      pending_notifications_.push_back({MakeLwmWaiter(std::move(f)), result});
    }
    // An outer call is draining the queue and will deliver these too.
    if (notifying_) return;
    notifying_ = true;
    while (!pending_notifications_.empty()) {
      auto n = std::move(pending_notifications_.front());
      pending_notifications_.pop_front();
      // The callback may re-enter this class and need the lock.
      lk.unlock();
      n.handler->Execute(std::move(n.status));
      lk.lock();
    }
    notifying_ = false;
    // A no-op if a callback already restarted the write loop.
    StartWriting(std::move(lk));
  }

  void WriteLoop(std::unique_lock<std::mutex> lk) {
    if (state_ != State::kIdle) return;

    // Determine if there's data left to write *before* potentially finalizing.
    auto const has_data = write_offset_ < resend_buffer_.size();

    // If we are writing data, continue doing so.
    if (has_data) {
      state_ = State::kWriting;
      // Still data to write, determine the next chunk.
      auto const n = resend_buffer_.size() - write_offset_;
      auto payload = resend_buffer_.Subcord(write_offset_, n);
      if (flush_) return FlushStep(std::move(lk), std::move(payload));
      return WriteStep(std::move(lk), std::move(payload));
    }

    // No data left to write.
    // Check if we need to finalize (only if not already writing data AND not
    // already finalizing).
    if (finalize_ && !finalizing_) {
      // FinalizeStep will set the finalizing_ flag.
      return FinalizeStep(std::move(lk));
    }
    if (close_ && !closing_) {
      // CloseStep will set the closing_ flag.
      return CloseStep(std::move(lk));
    }
    // If not finalizing, check if an empty flush is needed.
    if (flush_) {
      state_ = State::kWriting;
      // Pass empty payload to FlushStep
      return FlushStep(std::move(lk), absl::Cord{});
    }

    // No data to write, not finalizing, not flushing. The loop can stop.
    state_ = State::kIdle;
  }

  // FinalizeStep is now called only when all data in resend_buffer_ is written.
  void FinalizeStep(std::unique_lock<std::mutex> lk) {
    // Check *under lock* if we are already finalizing.
    if (finalizing_ || state_ != State::kIdle) {
      // If another thread initiated FinalizeStep concurrently, just return.
      return;
    }
    // Mark that we are starting the finalization process.
    state_ = State::kWriting;
    finalizing_ = true;
    auto impl = Impl(lk);
    lk.unlock();
    // Finalize with an empty payload.
    (void)impl->Finalize(storage::WritePayload{})
        .then([w = WeakFromThis()](auto f) {
          if (auto self = w.lock()) return self->OnFinalize(f.get());
        });
  }

  void OnFinalize(StatusOr<google::storage::v2::Object> result) {
    if (!result) return Resume(std::move(result).status());
    SetFinalized(std::unique_lock<std::mutex>(mu_), std::move(result));
  }

  void CloseStep(std::unique_lock<std::mutex> lk) {
    if (closing_ || state_ != State::kIdle) {
      return;
    }
    state_ = State::kWriting;
    closing_ = true;
    auto impl = Impl(lk);
    lk.unlock();
    (void)impl->Close(storage::WritePayload{})
        .then([w = WeakFromThis()](auto f) {
          if (auto self = w.lock()) return self->OnClose(f.get());
        });
  }

  void OnClose(Status result) {
    if (!result.ok()) return Resume(std::move(result));
    SetClosed(std::unique_lock<std::mutex>(mu_), std::move(result));
  }

  void FlushStep(std::unique_lock<std::mutex> lk, absl::Cord payload) {
    auto impl = Impl(lk);
    lk.unlock();
    auto const size = payload.size();
    (void)impl->Flush(WritePayloadImpl::Make(std::move(payload)))
        .then([size, w = WeakFromThis()](auto f) {
          if (auto self = w.lock()) {
            self->OnFlush(f.get(), size);
            return;
          }
        });
  }

  void OnFlush(Status const& result, std::size_t write_size) {
    if (!result.ok()) return Resume(std::move(result));
    std::unique_lock<std::mutex> lk(mu_);
    write_offset_ += write_size;
    auto impl = Impl(lk);
    auto const& state = impl->PersistedState();
    std::int64_t persisted_size = 0;
    if (std::holds_alternative<google::storage::v2::Object>(state)) {
      persisted_size = std::get<google::storage::v2::Object>(state).size();
    } else {
      persisted_size = std::get<std::int64_t>(state);
    }
    lk.unlock();
    OnQuery(persisted_size);
  }

  void OnQuery(StatusOr<std::int64_t> persisted_size) {
    if (!persisted_size) return Resume(std::move(persisted_size).status());
    return OnQuery(std::unique_lock<std::mutex>(mu_), *persisted_size,
                   /*is_resume=*/false);
  }

  auto ClearHandlers(std::unique_lock<std::mutex> const& /* lk */) {
    decltype(flush_handlers_) tmp;
    flush_handlers_.swap(tmp);
    return tmp;
  }

  auto ClearHandlersIfEmpty(std::unique_lock<std::mutex> const& /* lk */) {
    decltype(flush_handlers_) tmp;
    // Release the waiters once the buffer is empty or below the low-water
    // mark. The emptiness check matters when the low-water mark is 0.
    if (!resend_buffer_.empty() && resend_buffer_.size() >= buffer_size_lwm_) {
      return tmp;
    }
    flush_handlers_.swap(tmp);
    return tmp;
  }

  /**
   * Returns true if the write loop must send data with `Flush()`.
   *
   * That is the case while `Flush()` calls are pending, or while the buffer is
   * non-empty and at or above the low-water mark. An empty buffer only needs a
   * flush if a `Flush()` is pending, which avoids an endless loop of empty
   * flushes when the low-water mark is 0.
   */
  bool NeedsFlush(std::unique_lock<std::mutex> const& /* lk */) const {
    return !pending_flush_promises_.empty() ||
           (!resend_buffer_.empty() &&
            resend_buffer_.size() >= buffer_size_lwm_);
  }

  void OnQuery(std::unique_lock<std::mutex> lk, std::int64_t persisted_size,
               bool is_resume = false) {
    auto handle = impl_->WriteHandle();
    if (handle) {
      latest_write_handle_ = *std::move(handle);
    }

    if (persisted_size < buffer_offset_) {
      return SetError(
          std::move(lk),
          MakeRewindError(buffer_offset_, persisted_size, GCP_ERROR_INFO()));
    }
    auto const n = persisted_size - buffer_offset_;
    if (n > static_cast<std::int64_t>(resend_buffer_.size())) {
      return SetError(std::move(lk),
                      MakeFastForwardError(buffer_offset_, persisted_size,
                                           GCP_ERROR_INFO()));
    }
    resend_buffer_.RemovePrefix(static_cast<std::size_t>(n));
    buffer_offset_ = persisted_size;
    if (state_ == State::kResuming || is_resume) {
      // Since the buffer has been modified to start exactly at the point of the
      // resume, the next write on this new stream should start from the
      // beginning of this truncated buffer.
      write_offset_ = 0;
    } else {
      // While rare, it is possible that n >= write_offset_ (i.e. the server has
      // persisted more than we have sent) if, for example, multiple clients
      // resume the same upload. If that is the case, all the bytes covered by
      // write_offset_ have been flushed and we can reset it to 0.
      if (static_cast<std::size_t>(n) >= write_offset_) {
        write_offset_ = 0;
      } else {
        write_offset_ -= static_cast<std::size_t>(n);
      }
    }
    if (is_resume) {
      // We are resuming. The pending flush promises (if any) should not be
      // satisfied yet, because we haven't actually flushed the data on the new
      // connection. The `WriteLoop` will trigger a flush (potentially empty)
      // if `flush_` is still true, which will satisfy the promises when it
      // completes.
      auto handlers = ClearHandlersIfEmpty(lk);
      // Mark the writer idle under the lock so any operation chained from a
      // handler sees an idle writer and is dispatched immediately, and
      // `state_` is never modified without holding `mu_`.
      state_ = State::kIdle;
      return NotifyAndStartWriting(std::move(lk), std::move(handlers), {},
                                   Status{});
    }
    SetFlushed(std::move(lk), Status{}, persisted_size);
  }

  void WriteStep(std::unique_lock<std::mutex> lk, absl::Cord payload) {
    auto impl = Impl(lk);
    lk.unlock();
    auto const size = payload.size();
    (void)impl->Write(WritePayloadImpl::Make(std::move(payload)))
        .then([size, w = WeakFromThis()](auto f) {
          if (auto self = w.lock()) return self->OnWrite(f.get(), size);
        });
  }

  void OnWrite(Status const& result, std::size_t write_size) {
    if (!result.ok()) return Resume(std::move(result));
    std::unique_lock<std::mutex> lk(mu_);
    write_offset_ += write_size;
    state_ = State::kIdle;
    return StartWriting(std::move(lk));
  }

  void Resume(Status const& s) {
    // Capture the finalization and close state *before* starting the async
    // resume.
    bool was_finalizing;
    bool was_closing;
    {
      std::unique_lock<std::mutex> lk(mu_);
      if (state_ == State::kResuming) return;
      was_finalizing = finalizing_;
      was_closing = closing_;
      if (!s.ok() && cancelled_) {
        return SetError(std::move(lk), std::move(s));
      }
      if (!s.ok() && IsPermanentFailure(*options_, s)) {
        return SetError(std::move(lk), std::move(s));
      }
      state_ = State::kResuming;
    }

    auto proto_status = ExtractGrpcStatus(s);
    auto request = google::storage::v2::BidiWriteObjectRequest{};
    auto& append_object_spec = *request.mutable_append_object_spec();
    if (initial_request_.has_write_object_spec()) {
      auto const& spec = initial_request_.write_object_spec();
      append_object_spec.set_bucket(spec.resource().bucket());
      append_object_spec.set_object(spec.resource().name());
    } else {
      auto const& spec = initial_request_.append_object_spec();
      append_object_spec.set_bucket(spec.bucket());
      append_object_spec.set_object(spec.object());
    }
    // Include write_handle to enable fast resume instead of slow
    // takeover. Without handle, server performs full state validation.
    if (latest_write_handle_) {
      *append_object_spec.mutable_write_handle() = *latest_write_handle_;
    }
    append_object_spec.set_generation(first_response_.resource().generation());
    ApplyWriteRedirectErrors(append_object_spec, std::move(proto_status));

    // Pass the original status `s`, `was_finalizing`, and `was_closing` to the
    // callback.
    factory_(std::move(request))
        .then([s, was_finalizing, was_closing, w = WeakFromThis()](auto f) {
          if (auto self = w.lock())
            return self->OnResume(s, was_finalizing, was_closing, f.get());
        });
  }

  void OnResume(Status const& original_status, bool was_finalizing,
                bool was_closing, StatusOr<WriteObject::WriteResult> res) {
    std::unique_lock<std::mutex> lk(mu_);
    // Update write_handle from any resume response that contains it.
    if (res && res->first_response.has_write_handle()) {
      latest_write_handle_ = res->first_response.write_handle();
    }

    if (!res) {
      // Resume attempt failed. SetError will complete everything.
      return SetError(std::move(lk), std::move(res).status());
    }

    // Resume attempt succeeded. Check if finalized.
    std::int64_t persisted_offset = 0;
    bool finalized = false;
    google::storage::v2::Object finalized_object;

    auto const& first_res = res->first_response;
    if (first_res.has_resource() && !first_res.has_write_handle()) {
      finalized = true;
      finalized_object = first_res.resource();
    } else if (first_res.has_resource()) {
      persisted_offset = first_res.resource().size();
    } else if (first_res.has_persisted_size()) {
      persisted_offset = first_res.persisted_size();
    } else {
      auto state = impl_->PersistedState();
      if (std::holds_alternative<google::storage::v2::Object>(state)) {
        finalized = true;
        finalized_object =
            std::get<google::storage::v2::Object>(std::move(state));
      } else {
        persisted_offset = std::get<std::int64_t>(state);
      }
    }

    if (finalized) {
      if (was_closing) {
        return SetClosed(std::move(lk), Status{});
      }
      return SetFinalized(std::move(lk), std::move(finalized_object));
    }

    // Handle failure if we expected finalization/closing but didn't get it.
    if (was_finalizing) {
      finalizing_ = false;
      return SetError(std::move(lk), std::move(original_status));
    }
    if (was_closing) {
      closing_ = false;
      return SetError(std::move(lk), std::move(original_status));
    }

    impl_ = std::make_unique<AsyncWriterConnectionImpl>(
        options_, initial_request_, std::move(res->stream), hash_function_,
        persisted_offset, false);
    // OnQuery will restart the WriteLoop if necessary.
    OnQuery(std::move(lk), persisted_offset, /*is_resume=*/true);
  }

  void SetFinalized(std::unique_lock<std::mutex> lk,
                    StatusOr<google::storage::v2::Object> r) {
    if (!r) return SetError(std::move(lk), std::move(r).status());
    SetFinalized(std::move(lk), *std::move(r));
  }

  void SetFinalized(std::unique_lock<std::mutex> lk,
                    google::storage::v2::Object object) {
    resend_buffer_.Clear();
    state_ = State::kIdle;
    finalize_ = false;
    finalizing_ = false;  // Reset finalizing flag
    flush_ = false;
    // Check if the promise has already been completed.
    if (finalized_promise_completed_) {
      lk.unlock();  // Release lock before returning
      return;
    }
    // Mark the promise as completed *before* moving it.
    finalized_promise_completed_ = true;
    auto handlers = ClearHandlers(lk);
    // Also clear any pending flush promises on success.
    auto pending_flushes = std::move(pending_flush_promises_);
    auto p = std::move(finalized_);  // Move the member promise
    lk.unlock();
    // Notify handlers and pending flushes *after* releasing the lock.
    for (auto& h : handlers) h->Execute(Status{});
    for (auto& pf : pending_flushes) pf.p.set_value(Status{});  // Success
    p.set_value(std::move(object));  // Set value on the moved promise
  }

  void SetClosed(std::unique_lock<std::mutex> lk, Status status) {
    resend_buffer_.Clear();
    state_ = State::kIdle;
    close_ = false;
    closing_ = false;
    flush_ = false;
    // Check if the promise has already been completed.
    if (closed_promise_completed_) {
      lk.unlock();  // Release lock before returning
      return;
    }
    // Mark the promise as completed before moving it.
    closed_promise_completed_ = true;
    auto handlers = ClearHandlers(lk);
    // Also clear any pending flush promises on success.
    auto pending_flushes = std::move(pending_flush_promises_);
    auto p = std::move(closed_);  // Move the member promise.
    lk.unlock();
    // Notify handlers and pending flushes after releasing the lock.
    for (auto& h : handlers) h->Execute(status);
    for (auto& pf : pending_flushes) pf.p.set_value(status);
    p.set_value(std::move(status));  // Set value on the moved promise.
  }

  void SetFlushed(std::unique_lock<std::mutex> lk, Status const& result,
                  std::int64_t persisted_size) {
    if (!result.ok()) return SetError(std::move(lk), std::move(result));
    // Do NOT reset finalize_ or finalizing_ here.
    // Only release the high-water mark waiters once the buffer drops below the
    // low-water mark (or is empty).
    auto handlers = ClearHandlersIfEmpty(lk);
    std::vector<promise<Status>> flushes_to_complete;
    while (!pending_flush_promises_.empty() &&
           pending_flush_promises_.front().target_offset <= persisted_size) {
      flushes_to_complete.push_back(
          std::move(pending_flush_promises_.front().p));
      pending_flush_promises_.pop_front();
    }
    // Keep flushing while `NeedsFlush()` holds, so any high-water mark waiters
    // not released above are released by a later flush.
    flush_ = NeedsFlush(lk);
    // Mark the writer idle under the lock so any operation chained from a
    // callback sees an idle writer and is dispatched immediately, and
    // `state_` is never modified without holding `mu_`.
    state_ = State::kIdle;
    NotifyAndStartWriting(std::move(lk), std::move(handlers),
                          std::move(flushes_to_complete), result);
  }

  void SetError(std::unique_lock<std::mutex> lk, Status const& status) {
    resume_status_ = status;
    state_ = State::kIdle;
    finalize_ = false;
    finalizing_ = false;  // Reset finalizing flag
    close_ = false;
    closing_ = false;  // Reset closing flag
    flush_ = false;

    // Always clear handlers and pending flushes on error.
    auto handlers = ClearHandlers(lk);
    auto pending_flushes = std::move(pending_flush_promises_);

    // Check if the finalized promise has already been completed.
    bool complete_finalized = false;
    promise<StatusOr<google::storage::v2::Object>> finalized_to_complete;
    if (!finalized_promise_completed_) {
      finalized_promise_completed_ = true;
      finalized_to_complete = std::move(finalized_);
      complete_finalized = true;
    }

    // Check if the closed promise has already been completed.
    bool complete_closed = false;
    promise<Status> closed_to_complete;
    if (!closed_promise_completed_) {
      closed_promise_completed_ = true;
      closed_to_complete = std::move(closed_);
      complete_closed = true;
    }

    lk.unlock();  // Release lock before notifying

    // Notify handlers first.
    for (auto& h : handlers) h->Execute(status);
    // Set error on all pending flush promises.
    for (auto& pf : pending_flushes) {
      pf.p.set_value(status);
    }
    // Set error on the moved promises *once*.
    if (complete_finalized) {
      finalized_to_complete.set_value(status);
    }
    if (complete_closed) {
      closed_to_complete.set_value(status);
    }
  }

  std::shared_ptr<storage::AsyncWriterConnection> Impl(
      std::unique_lock<std::mutex> const& /*lk*/) const {
    return impl_;
  }

  std::string UploadId(std::unique_lock<std::mutex> const& lk) const {
    return Impl(lk)->UploadId();
  }

  // Creates new `impl_` instances when needed.
  WriterResultFactory const factory_;

  // The remaining member variables need a mutex for access. The background
  // threads may change them as the resend_buffer_ is drained and/or as the
  // reconnect loop resets `impl_`.
  // It may be possible to reduce locking overhead as only one background thread
  // operates on these member variables at a time. That seems like too small an
  // optimization to increase the complexity of the code.
  std::mutex mutable mu_;

  // The state of the resume loop. Once the resume loop fails no more resume
  // or write attempts are made.
  Status resume_status_;

  // The current writer.
  std::shared_ptr<storage::AsyncWriterConnection> impl_;

  // The initial request.
  google::storage::v2::BidiWriteObjectRequest initial_request_;

  std::shared_ptr<storage::internal::HashFunction> hash_function_;

  google::cloud::internal::ImmutableOptions options_;

  google::storage::v2::BidiWriteObjectResponse first_response_;

  // Request a server-side flush if the buffer goes over this threshold.
  std::size_t const buffer_size_lwm_;

  // Stop sending data if the buffer goes over this threshold. Only
  // start sending data again if the size goes below buffer_size_lwm_.
  std::size_t const buffer_size_hwm_;

  // The result of calling `Finalize()`. Note that only one such call is ever
  // made.
  promise<StatusOr<google::storage::v2::Object>> finalized_;

  // Retrieve the future in the constructor, as some operations reset
  // finalized_.
  future<StatusOr<google::storage::v2::Object>> finalized_future_;

  // The result of calling `Close()`. Note that only one such call is ever
  // made.
  promise<Status> closed_;

  // Retrieve the future in the constructor, as some operations reset
  // closed_.
  future<Status> closed_future_;

  // Tracks an outstanding `Flush()` promise alongside the stream offset at the
  // time `Flush()` was called. The target offset is used to satisfy promises
  // once all data buffered at the time of the `Flush()` call has been
  // persisted.
  struct PendingFlush {
    promise<Status> p;
    std::int64_t target_offset;
  };

  // Queue of promises for outstanding Flush() calls.
  std::deque<PendingFlush> pending_flush_promises_;

  // The resend buffer. If there is an error, this will have all the data since
  // the last persisted byte and will be resent.
  //
  // If this is larger than `buffer_size_hwm_` then `Write()`, and `Flush()`
  // will return futures that become satisfied only once the buffer size gets
  // below `buffer_size_lwm_`.
  //
  // Note that `Finalize()` does not block when the buffer gets too large. It
  // always blocks on `finalized_`.
  absl::Cord resend_buffer_;

  // If true, all the data to finalize an upload is in `resend_buffer_`.
  bool finalize_ = false;

  // If true, all data should be uploaded with `Flush()`.
  bool flush_ = true;

  // The offset for the first byte in the resend_buffer_.
  std::int64_t buffer_offset_ = 0;

  // The offset in `resend_buffer_` for the last `impl_->Write()` call.
  std::size_t write_offset_ = 0;

  // Handle buffer flush events. Some member functions want to be notified of
  // permanent errors in the resume loop and changes in the buffer size.
  // The most common cases included:
  // - A Write() call that returns an unsatisfied future until the buffer size
  //   is small enough.
  // - A Flush() call that returns an unsatisified future until the buffer is
  //   small enough.
  std::vector<std::unique_ptr<BufferShrinkHandler>> flush_handlers_;

  // A callback and the status to deliver to it.
  struct PendingNotification {
    std::unique_ptr<BufferShrinkHandler> handler;
    Status status;
  };

  // Callbacks awaiting delivery, oldest first. See `NotifyAndStartWriting()`.
  std::deque<PendingNotification> pending_notifications_;

  // True while a `NotifyAndStartWriting()` call is draining
  // `pending_notifications_`. Nested calls must only enqueue.
  bool notifying_ = false;

  // True if the writing loop is activate.
  enum class State {
    kIdle,
    kWriting,
    kResuming,
  };
  State state_ = State::kIdle;

  // True if cancelled, in which case any RPC failures are final.
  bool cancelled_ = false;

  // True if FinalizeStep has been initiated. Prevents re-entry.
  bool finalizing_ = false;

  // Tracks if the final promise (`finalized_`) has been completed.
  bool finalized_promise_completed_ = false;

  // If true, all the data to close an upload is in `resend_buffer_`.
  bool close_ = false;

  // True if CloseStep has been initiated. Prevents re-entry.
  bool closing_ = false;

  // Tracks if the final promise (`closed_`) has been completed.
  bool closed_promise_completed_ = false;

  // Track the latest write handle seen in responses.
  std::optional<google::storage::v2::BidiWriteHandle> latest_write_handle_;

  // Tracks if the `Finalize()` method has been called.
  // This is distinct from `finalize_` (which tracks if a finalize operation is
  // pending in the write loop) and `finalized_promise_completed_` (which tracks
  // if the upload is finalized).
  // We need this separate field to support the case where the upload is
  // finalized on construction; in that case, the promise is completed
  // immediately, but the application is still allowed to call `Finalize()` once
  // to retrieve the object.
  bool finalize_called_ = false;

  // Tracks if the `Close()` method has been called.
  bool close_called_ = false;
};

/**
 * Implements an `AsyncWriterConnection` that automatically resumes and resends
 * data.
 *
 * This class is used in the implementation of
 * `AsyncClient::StartBufferedUpload()`. Please see that function for the
 * motivation.
 *
 * This implementation of `AsyncWriterConnection` keeps an in-memory
 * `resend_buffer_` of type `absl::Cord`. New data is added to the end of the
 * Cord. Flushed data is removed from the front of the Cord.
 *
 * Applications threads add data by calling `Write()` and `Finalize()`.
 *
 * The buffer is drained by an asynchronous loop running in background threads.
 * This loop starts (if needed) when new data is appended to the
 * `resend_buffer_`. If the buffer is neither full nor approaching fullness
 * the loop calls `impl_->Write()` to upload data to the service.
 *
 * When the application finalizes an upload the loop calls `impl_->Finalize()`
 * and sends any previously buffered data as well as the new data.
 *
 * If the buffer is getting full, the loop uses `impl_->Flush()` instead of
 * `impl_->Write()` to upload data, and it also queries the status of the upload
 * after each `impl_->Flush()` call.
 *
 * If any of these operations fail the loop resumes the upload using a factory
 * function to create new `AsyncWriterConnection` instances. This class assumes
 * that the factory function implements the retry loop.
 *
 * If the factory function returns an error the loop ends.
 *
 * The loop also ends if there are no more bytes to send in the resend buffer.
 */
class AsyncWriterConnectionResumed : public storage::AsyncWriterConnection {
 public:
  explicit AsyncWriterConnectionResumed(
      WriterResultFactory factory,
      std::unique_ptr<storage::AsyncWriterConnection> impl,
      google::storage::v2::BidiWriteObjectRequest initial_request,
      std::shared_ptr<storage::internal::HashFunction> hash_function,
      google::storage::v2::BidiWriteObjectResponse const& first_response,
      Options const& options)
      : state_(std::make_shared<AsyncWriterConnectionResumedState>(
            std::move(factory), std::move(impl), std::move(initial_request),
            std::move(hash_function), first_response, options,
            options.get<storage::BufferedUploadLwmOption>(),
            options.get<storage::BufferedUploadHwmOption>())) {}

  void Cancel() override { return state_->Cancel(); }

  std::string UploadId() const override { return state_->UploadId(); }

  std::optional<google::storage::v2::BidiWriteHandle> WriteHandle()
      const override {
    return state_->WriteHandle();
  }

  std::variant<std::int64_t, google::storage::v2::Object> PersistedState()
      const override {
    return state_->PersistedState();
  }

  future<Status> Write(storage::WritePayload p) override {
    return state_->Write(std::move(p));
  }

  future<StatusOr<google::storage::v2::Object>> Finalize(
      storage::WritePayload p) override {
    return state_->Finalize(std::move(p));
  }

  future<Status> Flush(storage::WritePayload p) override {
    return state_->Flush(std::move(p));
  }

  future<Status> Close(storage::WritePayload p) override {
    return state_->Close(std::move(p));
  }

  future<StatusOr<std::int64_t>> Query() override { return state_->Query(); }

  RpcMetadata GetRequestMetadata() override {
    return state_->GetRequestMetadata();
  }

 private:
  std::shared_ptr<AsyncWriterConnectionResumedState> state_;
};

}  // namespace

std::unique_ptr<storage::AsyncWriterConnection> MakeWriterConnectionResumed(
    WriterResultFactory factory,
    std::unique_ptr<storage::AsyncWriterConnection> impl,
    google::storage::v2::BidiWriteObjectRequest initial_request,
    std::shared_ptr<storage::internal::HashFunction> hash_function,
    google::storage::v2::BidiWriteObjectResponse const& first_response,
    Options const& options) {
  return std::make_unique<AsyncWriterConnectionResumed>(
      std::move(factory), std::move(impl), std::move(initial_request),
      std::move(hash_function), std::move(first_response), std::move(options));
}

GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_END
}  // namespace storage_internal
}  // namespace cloud
}  // namespace google
