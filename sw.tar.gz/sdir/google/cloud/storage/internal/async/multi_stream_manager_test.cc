// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "google/cloud/storage/internal/async/multi_stream_manager.h"
#include <gmock/gmock.h>
#include <memory>
#include <unordered_map>

namespace google {
namespace cloud {
namespace storage_internal {
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_BEGIN
namespace {

struct FakeRange {
  bool done = false;
  int finished = 0;
  bool IsDone() const { return done; }
  void OnFinish(Status const&) { ++finished; }
};

struct FakeStream : public StreamBase {
  void Cancel() override { ++cancelled; }
  int cancelled = 0;
  bool write_pending = false;
};

using Manager = MultiStreamManager<FakeStream, FakeRange>;

struct MultiStreamManagerTest : public ::testing::Test {
  static Manager MakeManager() {
    return Manager([] { return std::make_shared<FakeStream>(); });
  }
};

}  // namespace

TEST(MultiStreamManagerTest, ConstructsWithFactoryAndHasOneStream) {
  auto mgr = MultiStreamManagerTest::MakeManager();
  EXPECT_FALSE(mgr.Empty());
  EXPECT_EQ(mgr.Size(), 1U);
  auto it = mgr.GetFirstStream();
  ASSERT_TRUE(it->stream);
}

TEST(MultiStreamManagerTest, ConstructsWithInitialStream) {
  auto initial = std::make_shared<FakeStream>();
  Manager mgr([] { return nullptr; }, initial);
  EXPECT_EQ(mgr.Size(), 1U);
  auto it = mgr.GetFirstStream();
  EXPECT_EQ(it->stream, initial);
}

TEST(MultiStreamManagerTest, AddStreamAppendsAndGetFirstReturnsNew) {
  auto mgr = MultiStreamManagerTest::MakeManager();
  auto s = std::make_shared<FakeStream>();
  auto it = mgr.AddStream(s);
  EXPECT_EQ(mgr.Size(), 2U);
  EXPECT_EQ(it->stream.get(), s.get());
  auto it_first = mgr.GetFirstStream();
  EXPECT_EQ(it_first->stream.get(), s.get());
}

TEST(MultiStreamManagerTest, GetLeastBusyPrefersFewestActiveRanges) {
  auto mgr = MultiStreamManagerTest::MakeManager();

  // The manager starts with an initial stream (size 0).
  // We must make it "busy" so it doesn't win the comparison against our test
  // streams.
  auto it_init = mgr.GetFirstStream();
  it_init->active_ranges.emplace(999, std::make_shared<FakeRange>());
  it_init->active_ranges.emplace(998, std::make_shared<FakeRange>());

  auto s1 = std::make_shared<FakeStream>();
  auto s2 = std::make_shared<FakeStream>();
  auto it1 = mgr.AddStream(s1);
  auto it2 = mgr.AddStream(s2);

  // s1 has 2 ranges.
  it1->active_ranges.emplace(1, std::make_shared<FakeRange>());
  it1->active_ranges.emplace(2, std::make_shared<FakeRange>());

  // s2 has 1 range.
  it2->active_ranges.emplace(3, std::make_shared<FakeRange>());

  auto it_least = mgr.GetLeastBusyStream();

  // Expect it2 (1 range) over it1 (2 ranges) and it_init (2 ranges).
  EXPECT_EQ(it_least, it2);
  EXPECT_EQ(it_least->active_ranges.size(), 1U);
}

/// @test Verifies that GetLeastBusyStream with a predicate filters candidates
/// based on the provided predicate, correctly returning End() if no stream
/// matches or the least busy stream among those that satisfy the predicate.
TEST(MultiStreamManagerTest, GetLeastBusyStreamWithPredicate) {
  auto mgr = MultiStreamManagerTest::MakeManager();
  mgr.GetFirstStream()->stream->write_pending = true;

  auto s1 = std::make_shared<FakeStream>();
  auto s2 = std::make_shared<FakeStream>();
  mgr.AddStream(s1);
  auto it2 = mgr.AddStream(s2);

  // s1 has 0 ranges, but write_pending = true.
  s1->write_pending = true;
  // s2 has 1 range, write_pending = false.
  s2->write_pending = false;
  it2->active_ranges.emplace(1, std::make_shared<FakeRange>());

  // Predicate filtering out write_pending streams selects s2 even though it has
  // more ranges than s1.
  auto it_pred = mgr.GetLeastBusyStream([](Manager::Stream const& s) {
    return s.stream != nullptr && !s.stream->write_pending;
  });
  EXPECT_THAT(it_pred, ::testing::Eq(it2));

  // If predicate matches no stream, returns End().
  auto it_none =
      mgr.GetLeastBusyStream([](Manager::Stream const&) { return false; });
  EXPECT_THAT(it_none, ::testing::Eq(mgr.End()));
}

TEST(MultiStreamManagerTest, CleanupDoneRangesRemovesFinished) {
  auto mgr = MultiStreamManagerTest::MakeManager();
  auto it = mgr.GetFirstStream();
  auto r1 = std::make_shared<FakeRange>();
  r1->done = false;
  auto r2 = std::make_shared<FakeRange>();
  r2->done = true;
  auto r3 = std::make_shared<FakeRange>();
  r3->done = true;
  it->active_ranges.emplace(1, r1);
  it->active_ranges.emplace(2, r2);
  it->active_ranges.emplace(3, r3);
  mgr.CleanupDoneRanges(it);
  EXPECT_EQ(it->active_ranges.size(), 1U);
  EXPECT_TRUE(it->active_ranges.count(1));
}

TEST(MultiStreamManagerTest, RemoveStreamAndNotifyRangesCallsOnFinish) {
  auto mgr = MultiStreamManagerTest::MakeManager();
  auto it = mgr.GetFirstStream();
  auto r1 = std::make_shared<FakeRange>();
  auto r2 = std::make_shared<FakeRange>();
  it->active_ranges.emplace(11, r1);
  it->active_ranges.emplace(22, r2);
  mgr.RemoveStreamAndNotifyRanges(it, Status());  // OK status
  EXPECT_EQ(mgr.Size(), 0U);
  EXPECT_EQ(r1->finished, 1);
  EXPECT_EQ(r2->finished, 1);
}

TEST(MultiStreamManagerTest, CancelAllInvokesCancel) {
  auto mgr = MultiStreamManagerTest::MakeManager();
  auto s1 = std::make_shared<FakeStream>();
  auto s2 = std::make_shared<FakeStream>();
  mgr.AddStream(s1);
  mgr.AddStream(s2);
  mgr.CancelAll();
  EXPECT_EQ(s1->cancelled, 1);
  EXPECT_EQ(s2->cancelled, 1);
}

TEST(MultiStreamManagerTest, ReuseIdleStreamToFrontMovesElement) {
  auto mgr = MultiStreamManagerTest::MakeManager();
  // Capture the factory-created stream pointer (initial element)
  auto* factory_ptr = mgr.GetFirstStream()->stream.get();
  auto s1 = std::make_shared<FakeStream>();
  mgr.AddStream(s1);
  bool moved = mgr.ReuseIdleStreamToFront([](Manager::Stream const& s) {
    auto* fs = s.stream.get();
    return fs != nullptr && s.active_ranges.empty() && !fs->write_pending;
  });
  EXPECT_TRUE(moved);
  auto it_first = mgr.GetFirstStream();
  // After move, the s1 stream should be first
  EXPECT_EQ(it_first->stream.get(), s1.get());
  EXPECT_NE(it_first->stream.get(), factory_ptr);
}

TEST(MultiStreamManagerTest,
     ReuseIdleStreamAlreadyAtFrontReturnsTrueWithoutMove) {
  auto mgr = MultiStreamManagerTest::MakeManager();
  // The manager starts with one stream. It is the first stream, and it is idle.
  auto initial_first = mgr.GetFirstStream();
  bool reused = mgr.ReuseIdleStreamToFront(
      [](Manager::Stream const& s) { return s.active_ranges.empty(); });
  EXPECT_TRUE(reused);
  // Pointer should remain the same (it was already at the front)
  EXPECT_EQ(mgr.GetFirstStream(), initial_first);
}

TEST(MultiStreamManagerTest, ReuseIdleStreamDoesNotMoveWhenWritePending) {
  auto mgr = MultiStreamManagerTest::MakeManager();
  auto* factory_ptr = mgr.GetFirstStream()->stream.get();
  // Mark factory stream as not reusable
  mgr.GetFirstStream()->stream->write_pending = true;
  auto s1 = std::make_shared<FakeStream>();
  s1->write_pending = true;  // also mark appended stream as not reusable
  mgr.AddStream(s1);
  bool moved = mgr.ReuseIdleStreamToFront([](Manager::Stream const& s) {
    auto* fs = s.stream.get();
    return fs != nullptr && s.active_ranges.empty() && !fs->write_pending;
  });
  EXPECT_FALSE(moved);
  auto it_first = mgr.GetFirstStream();
  EXPECT_EQ(it_first->stream.get(), s1.get());
  EXPECT_NE(it_first->stream.get(), factory_ptr);
}

TEST(MultiStreamManagerTest, MoveActiveRangesTransfersAllEntries) {
  auto mgr = MultiStreamManagerTest::MakeManager();
  auto s1 = std::make_shared<FakeStream>();
  auto s2 = std::make_shared<FakeStream>();
  auto it1 = mgr.AddStream(s1);
  auto it2 = mgr.AddStream(s2);
  it1->active_ranges.emplace(101, std::make_shared<FakeRange>());
  it1->active_ranges.emplace(202, std::make_shared<FakeRange>());
  ASSERT_EQ(it1->active_ranges.size(), 2U);
  ASSERT_TRUE(it2->active_ranges.empty());
  mgr.MoveActiveRanges(it1, it2);
  EXPECT_TRUE(it1->active_ranges.empty());
  EXPECT_EQ(it2->active_ranges.size(), 2U);
  EXPECT_TRUE(it2->active_ranges.count(101));
  EXPECT_TRUE(it2->active_ranges.count(202));
}

TEST(MultiStreamManagerTest, GetFirstStreamReflectsFrontReuse) {
  auto mgr = MultiStreamManagerTest::MakeManager();
  auto s1 = std::make_shared<FakeStream>();
  mgr.AddStream(s1);
  EXPECT_EQ(mgr.GetFirstStream()->stream.get(), s1.get());
  bool moved = mgr.ReuseIdleStreamToFront([](Manager::Stream const& s) {
    return s.stream != nullptr && s.active_ranges.empty();
  });
  EXPECT_TRUE(moved);
  auto it_first = mgr.GetFirstStream();
  EXPECT_EQ(it_first->stream.get(), s1.get());
}

TEST(MultiStreamManagerTest, EmptyAndSizeTransitions) {
  auto mgr = MultiStreamManagerTest::MakeManager();
  EXPECT_FALSE(mgr.Empty());
  EXPECT_EQ(mgr.Size(), 1U);
  auto it = mgr.GetFirstStream();
  mgr.RemoveStreamAndNotifyRanges(it, Status());
  EXPECT_TRUE(mgr.Empty());
  EXPECT_EQ(mgr.Size(), 0U);
  auto s = std::make_shared<FakeStream>();
  mgr.AddStream(s);
  EXPECT_FALSE(mgr.Empty());
  EXPECT_EQ(mgr.Size(), 1U);
}

TEST(MultiStreamManagerTest, FindTracksStreamMembership) {
  auto mgr = MultiStreamManagerTest::MakeManager();
  auto it1 = mgr.GetFirstStream();
  auto s1 = it1->stream;
  EXPECT_NE(mgr.Find(s1), mgr.End());

  auto s2 = std::make_shared<FakeStream>();
  mgr.AddStream(s2);
  EXPECT_NE(mgr.Find(s1), mgr.End());
  EXPECT_NE(mgr.Find(s2), mgr.End());

  mgr.RemoveStreamAndNotifyRanges(it1, Status());
  EXPECT_EQ(mgr.Find(s1), mgr.End());
  EXPECT_NE(mgr.Find(s2), mgr.End());
}

GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_END
}  // namespace storage_internal
}  // namespace cloud
}  // namespace google
