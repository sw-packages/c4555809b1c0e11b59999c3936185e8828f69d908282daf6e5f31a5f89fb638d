// Copyright 2024 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "google/cloud/storage/internal/async/object_descriptor_impl.h"
#include "google/cloud/storage/internal/async/options.h"

// TODO(v-pratap): Remove this when EnableMD5ValidationOption and
// EnableCrc32cValidationOption are removed.
#include "google/cloud/internal/disable_deprecation_warnings.inc"
#include "google/cloud/mocks/mock_async_streaming_read_write_rpc.h"
#include "google/cloud/storage/async/options.h"
#include "google/cloud/storage/async/resume_policy.h"
#include "google/cloud/storage/internal/async/default_options.h"
#include "google/cloud/storage/options.h"
#include "google/cloud/storage/testing/canonical_errors.h"
#include "google/cloud/storage/testing/mock_resume_policy.h"
#include "google/cloud/storage/testing/mock_storage_stub.h"
#include "google/cloud/testing_util/async_sequencer.h"
#include "google/cloud/testing_util/is_proto_equal.h"
#include "google/cloud/testing_util/scoped_log.h"
#include "google/cloud/testing_util/status_matchers.h"
#include "absl/strings/match.h"
#include "absl/strings/string_view.h"
#include "google/storage/v2/storage.pb.h"
#include <google/protobuf/text_format.h>
#include <google/protobuf/util/message_differencer.h>
#include <gmock/gmock.h>
#include <string>
#include <thread>
#include <vector>

namespace google {
namespace cloud {
namespace storage_internal {
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_BEGIN
namespace {

using ::google::cloud::storage::testing::MockResumePolicy;
using ::google::cloud::storage::testing::canonical_errors::PermanentError;
using ::google::cloud::storage::testing::canonical_errors::TransientError;
using ::google::cloud::testing_util::AsyncSequencer;
using ::google::cloud::testing_util::IsOk;
using ::google::cloud::testing_util::IsProtoEqual;
using ::google::cloud::testing_util::ScopedLog;
using ::google::cloud::testing_util::StatusIs;
using ::google::protobuf::TextFormat;
using ::testing::_;
using ::testing::AllOf;
using ::testing::AnyNumber;
using ::testing::AtLeast;
using ::testing::AtMost;
using ::testing::Contains;
using ::testing::ElementsAre;
using ::testing::Eq;
using ::testing::HasSubstr;
using ::testing::IsEmpty;
using ::testing::IsFalse;
using ::testing::IsTrue;
using ::testing::Not;
using ::testing::NotNull;
using ::testing::Optional;
using ::testing::ResultOf;
using ::testing::Return;
using ::testing::VariantWith;

using Request = google::storage::v2::BidiReadObjectRequest;
using Response = google::storage::v2::BidiReadObjectResponse;
using MockStream =
    google::cloud::mocks::MockAsyncStreamingReadWriteRpc<Request, Response>;
using MockFactory =
    ::testing::MockFunction<future<StatusOr<OpenStreamResult>>(Request)>;

auto constexpr kMetadataText = R"pb(
  bucket: "projects/_/buckets/test-bucket"
  name: "test-object"
  generation: 42
)pb";

auto NoResume() { return storage::LimitedErrorCountResumePolicy(0)(); }

// The `[gcs-retry]` records, in order. Everything else the library logs is
// noise for these tests.
std::vector<std::string> RetryRecords(ScopedLog& log) {
  std::vector<std::string> records;
  for (auto const& line : log.ExtractLines()) {
    if (absl::StrContains(line, "[gcs-retry]")) records.push_back(line);
  }
  return records;
}

auto MakeTested(
    std::unique_ptr<storage::ResumePolicy> resume_policy,
    OpenStreamFactory make_stream,
    google::storage::v2::BidiReadObjectSpec read_object_spec,
    std::shared_ptr<OpenStream> stream,
    std::function<bool()> transport_ok = [] { return true; }) {
  Options options;
  options.set<storage::EnableMultiStreamOptimizationOption>(true);
  return std::make_shared<ObjectDescriptorImpl>(
      std::move(resume_policy), std::move(make_stream),
      std::move(read_object_spec), std::move(stream), std::move(options),
      std::move(transport_ok));
}

MATCHER_P(IsProtoEqualModuloRepeatedFieldOrdering, value,
          "Checks whether protos are equal, ignoring repeated field ordering") {
  std::string delta;
  google::protobuf::util::MessageDifferencer differencer;
  differencer.set_repeated_field_comparison(
      google::protobuf::util::MessageDifferencer::AS_SET);
  differencer.ReportDifferencesToString(&delta);
  if (differencer.Compare(arg, value)) return true;
  *result_listener << "\n" << delta;
  return false;
}

/// @test Verify opening a stream and closing it produces the expected results.
TEST(ObjectDescriptorImpl, LifecycleNoRead) {
  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Read).WillOnce([&sequencer]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });
  auto tested = MakeTested(NoResume(), factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream)));
  auto response = Response{};
  EXPECT_TRUE(
      TextFormat::ParseFromString(kMetadataText, response.mutable_metadata()));
  tested->Start(std::move(response));
  EXPECT_TRUE(tested->metadata().has_value());

  auto expected_metadata = google::storage::v2::Object{};
  EXPECT_TRUE(TextFormat::ParseFromString(kMetadataText, &expected_metadata));
  EXPECT_THAT(tested->metadata(), Optional(IsProtoEqual(expected_metadata)));

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");
  read1.first.set_value(true);

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);

  tested.reset();
}

/// @test A stream that closes cleanly must not be reported as a retry.
TEST(ObjectDescriptorImpl, CleanFinishIsNotReportedAsRetry) {
  ScopedLog log;

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Read).WillOnce([&sequencer]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then([](auto) { return Status{}; });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  // `LimitedErrorCountResumePolicy` returns `kContinue` for an OK status, so
  // the descriptor opens a replacement stream even after a clean close.
  EXPECT_CALL(factory, Call)
      .Times(AnyNumber())
      .WillRepeatedly([](Request const&) {
        return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
      });

  auto tested = MakeTested(storage::LimitedErrorCountResumePolicy(3)(),
                           factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream)));
  auto response = Response{};
  EXPECT_TRUE(
      TextFormat::ParseFromString(kMetadataText, response.mutable_metadata()));
  tested->Start(std::move(response));

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");
  read1.first.set_value(true);

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);

  tested.reset();

  // The stream ended successfully, yet the resume policy still says
  // `kContinue`, so the descriptor reconnects. That reconnect must not be
  // reported: otherwise every completed download emits a warning.
  //
  // The replacement streams this test hands out do fail, and reporting *those*
  // is correct, so the invariant is specifically that no OK status is ever
  // described as an error.
  EXPECT_THAT(log.ExtractLines(), Not(Contains(HasSubstr("status=OK"))));
}

/// @test A re-open that follows a clean close uses the silent factory.
TEST(ObjectDescriptorImpl, CleanResumeUsesTheSilentFactory) {
  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Read).WillOnce([&sequencer]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then([](auto) { return Status{}; });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  MockFactory clean_factory;
  // The re-open after the clean close must go to the silent factory. The
  // reporting one is used later, when the replacement re-open fails for good
  // and the descriptor queues a fresh stream; that is not what is under test
  // here, so it is merely permitted.
  EXPECT_CALL(factory, Call)
      .Times(AnyNumber())
      .WillRepeatedly([](Request const&) {
        return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
      });
  EXPECT_CALL(clean_factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });

  Options options;
  // Keep `MakeSubsequentStream()` out of the way.
  options.set<storage::EnableMultiStreamOptimizationOption>(false);
  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(), clean_factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options,
      std::function<bool()>{});
  tested->Start(Response{});

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");
  read1.first.set_value(true);

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);

  tested.reset();
}

/// @test A re-open that follows a stream failure uses the reporting factory.
///
/// Only the clean-close case is silenced. A resume that is recovering from a
/// broken stream may itself be throttled, and those retries are exactly the
/// stall the application cannot otherwise see.
TEST(ObjectDescriptorImpl, FailedResumeUsesTheReportingFactory) {
  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Read).WillOnce([&sequencer]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return TransientError(); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  MockFactory clean_factory;
  EXPECT_CALL(factory, Call)
      .Times(AtLeast(1))
      .WillRepeatedly([](Request const&) {
        return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
      });
  // The stream failed, so nothing here may take the silent path.
  EXPECT_CALL(clean_factory, Call).Times(0);

  Options options;
  options.set<storage::EnableMultiStreamOptimizationOption>(false);
  auto tested = std::make_shared<ObjectDescriptorImpl>(
      storage::LimitedErrorCountResumePolicy(1)(), factory.AsStdFunction(),
      clean_factory.AsStdFunction(), google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options,
      std::function<bool()>{});
  tested->Start(Response{});

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");
  read1.first.set_value(false);

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);

  tested.reset();
}

/// @test A permanent stream failure is not reported, even though it resumes.
///
/// The built-in resume policies only count failures, so they return
/// `kContinue` for `PERMISSION_DENIED` as well, and the descriptor re-opens.
/// It is the retry loop inside the factory that gives up on it. Nothing was
/// retried, so a "transient error" record would be misleading.
TEST(ObjectDescriptorImpl, NoRetryLogForPermanentStreamFailure) {
  ScopedLog log;

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Read).WillOnce([&sequencer]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return Status(StatusCode::kPermissionDenied, "uh-oh"); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  // The descriptor still re-opens: only the reporting changes, not whether the
  // stream is resumed.
  EXPECT_CALL(factory, Call)
      .Times(AtLeast(1))
      .WillRepeatedly([](Request const&) {
        return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
      });

  Options options;
  options.set<storage::EnableMultiStreamOptimizationOption>(false);
  auto tested = std::make_shared<ObjectDescriptorImpl>(
      storage::LimitedErrorCountResumePolicy(1)(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options,
      std::function<bool()>{});
  tested->Start(Response{});

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");
  read1.first.set_value(false);

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);

  tested.reset();

  EXPECT_THAT(RetryRecords(log), IsEmpty());
}

/// @test The attempt number counts consecutive resumes of the same stream.
///
/// The count has to restart with each new stream. A long-lived descriptor may
/// be resumed many times over its life, and a number that only ever grows says
/// nothing about how bad the current stall is.
TEST(ObjectDescriptorImpl, ResumeAttemptCountsConsecutiveFailures) {
  ScopedLog log;

  AsyncSequencer<bool> sequencer;
  auto make_failing_stream = [&sequencer](std::string const& name) {
    auto stream = std::make_unique<MockStream>();
    EXPECT_CALL(*stream, Read).WillOnce([&sequencer, name]() {
      return sequencer.PushBack("Read/" + name).then([](auto) {
        return std::optional<Response>{};
      });
    });
    EXPECT_CALL(*stream, Finish).WillOnce([&sequencer, name]() {
      return sequencer.PushBack("Finish/" + name).then([](auto) {
        return TransientError();
      });
    });
    EXPECT_CALL(*stream, Cancel).Times(AtMost(1));
    return stream;
  };

  MockFactory factory;
  // The first resume re-opens successfully, which is what restarts the count.
  // The second one fails outright, so the stream that failed is resumed again
  // and its own count continues.
  EXPECT_CALL(factory, Call)
      .WillOnce([&](Request const&) {
        auto result = OpenStreamResult{
            std::make_shared<OpenStream>(make_failing_stream("s2")),
            Response{}};
        return make_ready_future(StatusOr<OpenStreamResult>(std::move(result)));
      })
      .WillOnce([](Request const&) {
        return make_ready_future(StatusOr<OpenStreamResult>(TransientError()));
      })
      .WillOnce([](Request const&) {
        return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
      })
      // The descriptor gives up at that point and queues a replacement stream.
      .WillRepeatedly([](Request const&) {
        return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
      });

  Options options;
  options.set<storage::EnableMultiStreamOptimizationOption>(false);
  auto tested = std::make_shared<ObjectDescriptorImpl>(
      storage::LimitedErrorCountResumePolicy(3)(), factory.AsStdFunction(),
      factory.AsStdFunction(), google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(make_failing_stream("s1")), options,
      std::function<bool()>{});
  tested->Start(Response{});

  for (auto const& name : {std::string("s1"), std::string("s2")}) {
    auto read = sequencer.PopFrontWithName();
    EXPECT_EQ(read.second, "Read/" + name);
    read.first.set_value(false);

    auto finish = sequencer.PopFrontWithName();
    EXPECT_EQ(finish.second, "Finish/" + name);
    finish.first.set_value(true);
  }

  tested.reset();

  // The first stream fails: attempt 1. Its re-open succeeds, so the second
  // stream starts over: attempt 1 again. That re-open fails, and the same
  // stream is resumed once more: attempt 2.
  auto const matches = [](int attempt) {
    return AllOf(HasSubstr("[gcs-retry]"), HasSubstr("Open/resume"),
                 HasSubstr("attempt " + std::to_string(attempt)));
  };
  EXPECT_THAT(RetryRecords(log),
              ElementsAre(matches(1), matches(1), matches(2)));
}

/// @test Verify that Cancel() is called if OnFinish() is delayed.
TEST(ObjectDescriptorImpl, LifecycleCancelRacesWithFinish) {
  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Read).WillOnce([&sequencer]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });
  // This time we expect Cancel() because we will delay OnFinish().
  EXPECT_CALL(*stream, Cancel).Times(1);

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });
  auto tested = MakeTested(NoResume(), factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream)));
  auto response = Response{};
  EXPECT_TRUE(
      TextFormat::ParseFromString(kMetadataText, response.mutable_metadata()));
  tested->Start(std::move(response));
  EXPECT_TRUE(tested->metadata().has_value());

  auto expected_metadata = google::storage::v2::Object{};
  EXPECT_TRUE(TextFormat::ParseFromString(kMetadataText, &expected_metadata));
  EXPECT_THAT(tested->metadata(), Optional(IsProtoEqual(expected_metadata)));

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");
  read1.first.set_value(true);

  // This pops the future that OnFinish() waits for.
  auto finish = sequencer.PopFrontWithName();
  EXPECT_EQ(finish.second, "Finish");

  // Reset the descriptor *before* OnFinish() gets to run. This invokes the
  // destructor, which calls Cancel() on any streams that have not yet been
  // removed by OnFinish().
  tested.reset();

  // Now allow OnFinish() to run.
  finish.first.set_value(true);
}

/// @test Read a single stream and then close.
TEST(ObjectDescriptorImpl, ReadSingleRange) {
  auto constexpr kResponse0 = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
    }
    read_handle { handle: "handle-12345" }
  )pb";

  auto constexpr kRequest1 = R"pb(
    read_ranges { read_id: 1 read_offset: 20000 read_length: 100 }
  )pb";
  auto constexpr kResponse1 = R"pb(
    read_handle { handle: "handle-23456" }
    object_data_ranges {
      range_end: true
      read_range { read_id: 1 read_offset: 20000 }
      checksummed_data {
        content: "The quick brown fox jumps over the lazy dog"
      }
    }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kRequest1, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream, Read)
      .WillOnce([=, &sequencer]() {
        return sequencer.PushBack("Read[1]").then([&](auto) {
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse1, &response));
          return std::make_optional(response);
        });
      })
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });
  auto tested = MakeTested(NoResume(), factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream)));
  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponse0, &response));
  tested->Start(std::move(response));
  EXPECT_TRUE(tested->metadata().has_value());

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto expected_metadata = google::storage::v2::Object{};
  EXPECT_TRUE(TextFormat::ParseFromString(kMetadataText, &expected_metadata));
  EXPECT_THAT(tested->metadata(), Optional(IsProtoEqual(expected_metadata)));

  auto s1 = tested->Read({20000, 100});
  auto s1r1 = s1->Read();

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[1]");
  next.first.set_value(true);
  read1.first.set_value(true);

  // The future returned by `Read()` should become satisfied at this point.
  // We expect it to contain the right data.
  EXPECT_THAT(s1r1.get(),
              VariantWith<storage::ReadPayload>(ResultOf(
                  "contents are",
                  [](storage::ReadPayload const& p) { return p.contents(); },
                  ElementsAre(absl::string_view{
                      "The quick brown fox jumps over the lazy dog"}))));
  // Since the `range_end()` flag is set, we expect the stream to finish with
  // success.
  EXPECT_THAT(s1->Read().get(), VariantWith<Status>(IsOk()));

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Read[2]");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);
}

/// @test Reading multiple ranges creates a single request.
TEST(ObjectDescriptorImpl, ReadMultipleRanges) {
  auto constexpr kLength = 100;
  auto constexpr kOffset = 20000;
  auto constexpr kRequest1 = R"pb(
    read_ranges { read_id: 1 read_offset: 20000 read_length: 100 }
  )pb";
  auto constexpr kRequest2 = R"pb(
    read_ranges { read_id: 2 read_offset: 40000 read_length: 100 }
    read_ranges { read_id: 3 read_offset: 60000 read_length: 100 }
  )pb";
  auto constexpr kResponse0 = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
    }
    read_handle { handle: "handle-12345" }
  )pb";
  auto constexpr kResponse1 = R"pb(
    object_data_ranges {
      range_end: true
      read_range { read_id: 1 read_offset: 20000 }
      checksummed_data {
        content: "The quick brown fox jumps over the lazy dog"
      }
    }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kRequest1, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      })
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kRequest2, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[2]").then([](auto f) {
          return f.get();
        });
      });

  EXPECT_CALL(*stream, Read)
      .WillOnce([&]() {
        return sequencer.PushBack("Read[1]").then([&](auto) {
          // Simulate a response with 3 out of order messages.
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse1, &response));
          return std::make_optional(response);
        });
      })
      .WillRepeatedly([&]() {
        return sequencer.PushBack("Read[2]").then(
            [&](auto) { return std::optional<Response>{}; });
      });

  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });
  auto tested = MakeTested(NoResume(), factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream)));
  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponse0, &response));
  tested->Start(std::move(response));
  EXPECT_TRUE(tested->metadata().has_value());

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({kOffset, kLength});
  ASSERT_THAT(s1, NotNull());

  // Asking for data should result in an immediate `Write()` message with the
  // first range.
  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[1]");

  // Additional ranges are queued until the first `Write()` call is completed.
  auto s2 = tested->Read({2 * kOffset, kLength});
  ASSERT_THAT(s2, NotNull());

  auto s3 = tested->Read({3 * kOffset, kLength});
  ASSERT_THAT(s3, NotNull());

  // Complete the first `Write()` call, that should result in a second
  // `Write()` call with the two additional ranges.
  next.first.set_value(true);

  // And then the follow up `Write()` message with the queued information.
  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[2]");
  next.first.set_value(true);

  auto s1r1 = s1->Read();
  auto s2r1 = s2->Read();
  auto s3r1 = s3->Read();
  EXPECT_FALSE(s1r1.is_ready());
  EXPECT_FALSE(s2r1.is_ready());
  EXPECT_FALSE(s3r1.is_ready());

  read1.first.set_value(true);

  // The future returned by `Read()` should become satisfied at this point.
  // We expect it to contain the right data.
  EXPECT_THAT(s1r1.get(),
              VariantWith<storage::ReadPayload>(ResultOf(
                  "contents are",
                  [](storage::ReadPayload const& p) { return p.contents(); },
                  ElementsAre(absl::string_view{
                      "The quick brown fox jumps over the lazy dog"}))));
  // Since the `range_end()` flag is set, we expect the stream to finish with
  // success.
  EXPECT_THAT(s1->Read().get(), VariantWith<Status>(IsOk()));

  // Simulate a clean shutdown with an unrecoverable error.
  auto last_read = sequencer.PopFrontWithName();
  EXPECT_EQ(last_read.second, "Read[2]");
  last_read.first.set_value(false);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);

  EXPECT_TRUE(s2r1.is_ready());
  EXPECT_TRUE(s3r1.is_ready());
  EXPECT_THAT(s2r1.get(), VariantWith<Status>(PermanentError()));
  EXPECT_THAT(s3r1.get(), VariantWith<Status>(PermanentError()));
}

/// @test Reading a range may require many messages.
TEST(ObjectDescriptorImpl, ReadSingleRangeManyMessages) {
  auto constexpr kRequest1 = R"pb(
    read_ranges { read_id: 1 read_offset: 20000 read_length: 100 }
  )pb";
  auto constexpr kResponse0 = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
    }
    read_handle { handle: "handle-12345" }
  )pb";
  auto constexpr kResponse1 = R"pb(
    object_data_ranges {
      range_end: false
      read_range { read_id: 1 read_offset: 20000 }
      checksummed_data {
        content: "The quick brown fox jumps over the lazy dog"
      }
    }
  )pb";
  auto constexpr kResponse2 = R"pb(
    object_data_ranges {
      range_end: true
      read_range { read_id: 1 read_offset: 20026 }
      checksummed_data {
        content: "The quick brown fox jumps over the lazy dog"
      }
    }
  )pb";
  auto constexpr kOffset = 20000;
  auto constexpr kLength = 100;

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kRequest1, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });

  EXPECT_CALL(*stream, Read)
      .WillOnce([&]() {
        return sequencer.PushBack("Read[1]").then([&](auto) {
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse1, &response));
          return std::make_optional(response);
        });
      })
      .WillOnce([&]() {
        return sequencer.PushBack("Read[2]").then([&](auto) {
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse2, &response));
          return std::make_optional(response);
        });
      })
      .WillRepeatedly([&]() {
        return sequencer.PushBack("Read[3]").then(
            [&](auto) { return std::optional<Response>{}; });
      });

  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });
  auto tested = MakeTested(NoResume(), factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream)));
  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponse0, &response));
  tested->Start(std::move(response));
  EXPECT_TRUE(tested->metadata().has_value());

  auto read = sequencer.PopFrontWithName();
  EXPECT_EQ(read.second, "Read[1]");

  auto s1 = tested->Read({kOffset, kLength});
  ASSERT_THAT(s1, NotNull());

  // Asking for data should result in an immediate `Write()` message with the
  // first range.
  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[1]");
  next.first.set_value(true);

  auto s1r1 = s1->Read();
  EXPECT_FALSE(s1r1.is_ready());

  read.first.set_value(true);

  // The future returned by `Read()` should become satisfied at this point.
  // We expect it to contain the right data.
  EXPECT_THAT(s1r1.get(),
              VariantWith<storage::ReadPayload>(ResultOf(
                  "contents are",
                  [](storage::ReadPayload const& p) { return p.contents(); },
                  ElementsAre(absl::string_view{
                      "The quick brown fox jumps over the lazy dog"}))));

  auto s1r2 = s1->Read();
  EXPECT_FALSE(s1r2.is_ready());

  read = sequencer.PopFrontWithName();
  EXPECT_EQ(read.second, "Read[2]");
  read.first.set_value(true);

  // The future returned by `Read()` should become satisfied at this point.
  // We expect it to contain the right data.
  EXPECT_THAT(s1r2.get(),
              VariantWith<storage::ReadPayload>(ResultOf(
                  "contents are",
                  [](storage::ReadPayload const& p) { return p.contents(); },
                  ElementsAre(absl::string_view{
                      "The quick brown fox jumps over the lazy dog"}))));

  // Since the `range_end()` flag is set, we expect the stream to finish with
  // success.
  EXPECT_THAT(s1->Read().get(), VariantWith<Status>(IsOk()));

  auto last_read = sequencer.PopFrontWithName();
  EXPECT_EQ(last_read.second, "Read[3]");
  last_read.first.set_value(false);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);
}

/// @test When the underlying stream fails with unrecoverable errors all ranges
/// fail.
TEST(ObjectDescriptorImpl, AllRangesFailOnUnrecoverableError) {
  auto constexpr kLength = 100;
  auto constexpr kOffset = 20000;
  auto constexpr kRequest1 = R"pb(
    read_ranges { read_id: 1 read_offset: 20000 read_length: 100 }
  )pb";
  auto constexpr kRequest2 = R"pb(
    read_ranges { read_id: 2 read_offset: 40000 read_length: 100 }
    read_ranges { read_id: 3 read_offset: 60000 read_length: 100 }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kRequest1, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      })
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kRequest2, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[2]").then([](auto f) {
          return f.get();
        });
      });

  EXPECT_CALL(*stream, Read).WillOnce([&]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });

  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });
  auto tested = MakeTested(NoResume(), factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream)));
  tested->Start(Response{});
  EXPECT_FALSE(tested->metadata().has_value());

  auto read = sequencer.PopFrontWithName();
  EXPECT_EQ(read.second, "Read[1]");

  auto s1 = tested->Read({kOffset, kLength});
  ASSERT_THAT(s1, NotNull());

  // Asking for data should result in an immediate `Write()` message with the
  // first range.
  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[1]");

  // Additional ranges are queued until the first `Write()` call is completed.
  auto s2 = tested->Read({2 * kOffset, kLength});
  ASSERT_THAT(s2, NotNull());

  auto s3 = tested->Read({3 * kOffset, kLength});
  ASSERT_THAT(s3, NotNull());

  // Complete the first `Write()` call, that should result in a second
  // `Write()` call with the two additional ranges.
  next.first.set_value(true);

  // And then the follow up `Write()` message with the queued information.
  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[2]");
  next.first.set_value(true);

  auto s1r1 = s1->Read();
  auto s2r1 = s2->Read();
  auto s3r1 = s3->Read();
  EXPECT_FALSE(s1r1.is_ready());
  EXPECT_FALSE(s2r1.is_ready());
  EXPECT_FALSE(s3r1.is_ready());

  // Simulate a failure.
  read.first.set_value(false);
  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);

  // All the ranges fail with the same error.
  EXPECT_THAT(s1r1.get(), VariantWith<Status>(PermanentError()));
  EXPECT_THAT(s2r1.get(), VariantWith<Status>(PermanentError()));
  EXPECT_THAT(s3r1.get(), VariantWith<Status>(PermanentError()));
}

auto InitialStream(AsyncSequencer<bool>& sequencer) {
  auto constexpr kRequest1 = R"pb(
    read_ranges { read_id: 1 read_offset: 20000 read_length: 100 }
  )pb";
  auto constexpr kRequest2 = R"pb(
    read_ranges { read_id: 2 read_offset: 40000 read_length: 100 }
    read_ranges { read_id: 3 read_offset: 60000 read_length: 100 }
  )pb";

  auto constexpr kResponse1 = R"pb(
    object_data_ranges {
      read_range { read_id: 1 read_offset: 20000 }
      checksummed_data { content: "0123456789" crc32c: 0x280c069e }
    }
    object_data_ranges {
      read_range { read_id: 2 read_offset: 40000 }
      checksummed_data { content: "0123456789" crc32c: 0x280c069e }
    }
    object_data_ranges {
      range_end: true
      read_range { read_id: 3 read_offset: 40000 }
      checksummed_data { content: "0123456789" crc32c: 0x280c069e }
    }
  )pb";

  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));  // Always called by OpenStream
  EXPECT_CALL(*stream, Write)
      .WillOnce([=, &sequencer](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kRequest1, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      })
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kRequest2, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[2]").then([](auto f) {
          return f.get();
        });
      });

  EXPECT_CALL(*stream, Read)
      .WillOnce([=, &sequencer]() {
        return sequencer.PushBack("Read[1]").then([&](auto) {
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse1, &response));
          return std::make_optional(response);
        });
      })
      .WillOnce([&]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      });

  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return TransientError(); });
  });

  return stream;
}

/// @test Verify that resuming a stream adjusts all offsets.
TEST(ObjectDescriptorImpl, ResumeRangesOnRecoverableError) {
// There is a problem with this test and certain versions of MSVC (19.43.34808)
// skipping it on WIN32 for now.
#ifdef _WIN32
  GTEST_SKIP();
#endif

  ScopedLog log;

  auto constexpr kLength = 100;
  auto constexpr kOffset = 20000;
  auto constexpr kReadSpecText = R"pb(
    bucket: "test-only-invalid"
    object: "test-object"
    generation: 24
    if_generation_match: 42
  )pb";
  // The resume request should include all the remaining ranges, starting from
  // the remaining offset (10 bytes after the start).
  auto constexpr kResumeRequest = R"pb(
    read_object_spec {
      bucket: "test-only-invalid"
      object: "test-object"
      generation: 24
      if_generation_match: 42
      read_handle { handle: "handle-12345" }
    }
    read_ranges { read_id: 1 read_offset: 20010 read_length: 90 }
    read_ranges { read_id: 2 read_offset: 40010 read_length: 90 }
  )pb";
  auto constexpr kResponse0 = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
    }
    read_handle { handle: "handle-12345" }
  )pb";

  AsyncSequencer<bool> sequencer;
  Request expected_resume_request;
  ASSERT_TRUE(
      TextFormat::ParseFromString(kResumeRequest, &expected_resume_request));

  MockFactory factory;
  EXPECT_CALL(factory, Call)
      .WillOnce([](Request const& request) {
        EXPECT_TRUE(request.read_ranges().empty());
        return make_ready_future(StatusOr<OpenStreamResult>(TransientError()));
      })
      .WillOnce([&](Request const& request) {
        EXPECT_THAT(request, IsProtoEqualModuloRepeatedFieldOrdering(
                                 expected_resume_request));
        // Resume with an unrecoverable failure to simplify the test.
        return sequencer.PushBack("Factory").then(
            [](auto) { return StatusOr<OpenStreamResult>(PermanentError()); });
      });

  auto spec = google::storage::v2::BidiReadObjectSpec{};
  ASSERT_TRUE(TextFormat::ParseFromString(kReadSpecText, &spec));
  auto tested = MakeTested(
      storage::LimitedErrorCountResumePolicy(1)(), factory.AsStdFunction(),
      spec, std::make_shared<OpenStream>(InitialStream(sequencer)));
  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponse0, &response));
  tested->Start(std::move(response));
  EXPECT_TRUE(tested->metadata().has_value());

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({kOffset, kLength});
  ASSERT_THAT(s1, NotNull());

  // Asking for data should result in an immediate `Write()` message with the
  // first range.
  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[1]");

  // Additional ranges are queued until the first `Write()` call is completed.
  auto s2 = tested->Read({2 * kOffset, kLength});
  ASSERT_THAT(s2, NotNull());

  auto s3 = tested->Read({3 * kOffset, kLength});
  ASSERT_THAT(s3, NotNull());

  // Complete the first `Write()` call, that should result in a second
  // `Write()` call with the two additional ranges.
  next.first.set_value(true);

  // And then the follow up `Write()` message with the queued information.
  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[2]");
  next.first.set_value(true);

  auto s1r1 = s1->Read();
  auto s2r1 = s2->Read();
  auto s3r1 = s3->Read();
  EXPECT_FALSE(s1r1.is_ready());
  EXPECT_FALSE(s2r1.is_ready());
  EXPECT_FALSE(s3r1.is_ready());

  // Simulate a partial read.
  read1.first.set_value(true);
  // The ranges should have some data.
  EXPECT_TRUE(s1r1.is_ready());
  EXPECT_TRUE(s2r1.is_ready());
  EXPECT_TRUE(s3r1.is_ready());

  auto expected_r1 = VariantWith<storage::ReadPayload>(ResultOf(
      "contents are",
      [](storage::ReadPayload const& p) { return p.contents(); },
      ElementsAre(absl::string_view{"0123456789"})));

  EXPECT_THAT(s1r1.get(), expected_r1);
  EXPECT_THAT(s2r1.get(), expected_r1);
  EXPECT_THAT(s3r1.get(), expected_r1);

  auto s1r2 = s1->Read();
  auto s2r2 = s2->Read();
  auto s3r2 = s3->Read();
  EXPECT_FALSE(s1r2.is_ready());
  EXPECT_FALSE(s2r2.is_ready());
  // The third range should be fully done.
  EXPECT_TRUE(s3r2.is_ready());
  EXPECT_THAT(s3r2.get(), VariantWith<Status>(IsOk()));

  // Simulate the recoverable failure.
  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Read[2]");
  next.first.set_value(false);
  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Factory");
  next.first.set_value(true);

  // All the ranges fail with the same error.
  EXPECT_THAT(s1r2.get(), VariantWith<Status>(PermanentError()));
  EXPECT_THAT(s2r2.get(), VariantWith<Status>(PermanentError()));

  // The first failure was recoverable, so the descriptor resumed the stream.
  // That has to be visible, otherwise the application only sees the extra
  // latency.
  EXPECT_THAT(log.ExtractLines(),
              Contains(AllOf(HasSubstr("[gcs-retry]"), HasSubstr("Open/resume"),
                             HasSubstr("test-only-invalid/test-object"))));
}

Status RedirectError(absl::string_view handle, absl::string_view token) {
  auto details = [&] {
    auto redirected = google::storage::v2::BidiReadObjectRedirectedError{};
    redirected.mutable_read_handle()->set_handle(std::string(handle));
    redirected.set_routing_token(std::string(token));
    auto details_proto = google::rpc::Status{};
    details_proto.set_code(grpc::StatusCode::UNAVAILABLE);
    details_proto.set_message("redirect");
    (void)details_proto.add_details()->PackFrom(redirected);

    std::string details;
    (void)details_proto.SerializeToString(&details);
    return details;
  };

  return google::cloud::MakeStatusFromRpcError(
      grpc::Status(grpc::StatusCode::UNAVAILABLE, "redirect", details()));
}

/// @test Verify that resuming a stream uses a handle and routing token.
TEST(ObjectDescriptorImpl, PendingFinish) {
  auto constexpr kResponse0 = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
    }
    read_handle { handle: "handle-12345" }
  )pb";

  AsyncSequencer<bool> sequencer;

  auto initial_stream = [&sequencer]() {
    auto constexpr kRequest1 = R"pb(
      read_ranges { read_id: 1 read_offset: 20000 read_length: 100 }
    )pb";

    auto stream = std::make_unique<MockStream>();
    EXPECT_CALL(*stream, Cancel)
        .Times(AtMost(1));  // Always called by OpenStream
    EXPECT_CALL(*stream, Write)
        .WillOnce([=, &sequencer](Request const& request, grpc::WriteOptions) {
          auto expected = Request{};
          EXPECT_TRUE(TextFormat::ParseFromString(kRequest1, &expected));
          EXPECT_THAT(request, IsProtoEqual(expected));
          return sequencer.PushBack("Write[1]").then([](auto) {
            return false;
          });
        });

    EXPECT_CALL(*stream, Read).WillOnce([&]() {
      return sequencer.PushBack("Read[1]").then(
          [](auto) { return std::optional<Response>{}; });
    });

    EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
      return sequencer.PushBack("Finish").then(
          [](auto) { return TransientError(); });
    });

    return stream;
  };

  auto constexpr kLength = 100;
  auto constexpr kOffset = 20000;
  auto constexpr kReadSpecText = R"pb(
    bucket: "test-only-invalid"
    object: "test-object"
    generation: 24
    if_generation_match: 42
  )pb";

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });

  auto spec = google::storage::v2::BidiReadObjectSpec{};
  ASSERT_TRUE(TextFormat::ParseFromString(kReadSpecText, &spec));
  auto tested = MakeTested(NoResume(), factory.AsStdFunction(), spec,
                           std::make_shared<OpenStream>(initial_stream()));
  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponse0, &response));
  tested->Start(std::move(response));
  EXPECT_TRUE(tested->metadata().has_value());

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({kOffset, kLength});
  ASSERT_THAT(s1, NotNull());

  // Asking for data should result in an immediate `Write()` message with the
  // first range.
  auto write1 = sequencer.PopFrontWithName();
  EXPECT_EQ(write1.second, "Write[1]");

  // Simulate a (nearly) simultaneous error in the `Write()` and `Read()` calls.
  read1.first.set_value(false);
  write1.first.set_value(false);
  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);

  // The ranges fails with the same error.
  EXPECT_THAT(s1->Read().get(), VariantWith<Status>(TransientError()));
}

/// @test Verify that resuming a stream uses a handle and routing token.
TEST(ObjectDescriptorImpl, ResumeUsesRouting) {
  auto constexpr kResponse0 = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
    }
    read_handle { handle: "handle-12345" }
  )pb";

  AsyncSequencer<bool> sequencer;

  auto initial_stream = [&sequencer]() {
    auto constexpr kRequest1 = R"pb(
      read_ranges { read_id: 1 read_offset: 20000 read_length: 100 }
    )pb";

    auto stream = std::make_unique<MockStream>();
    EXPECT_CALL(*stream, Cancel).Times(AtMost(1));
    EXPECT_CALL(*stream, Write)
        .WillOnce([=, &sequencer](Request const& request, grpc::WriteOptions) {
          auto expected = Request{};
          EXPECT_TRUE(TextFormat::ParseFromString(kRequest1, &expected));
          EXPECT_THAT(request, IsProtoEqual(expected));
          return sequencer.PushBack("Write[1]").then([](auto f) {
            return f.get();
          });
        });

    EXPECT_CALL(*stream, Read).WillOnce([&]() {
      return sequencer.PushBack("Read[1]").then(
          [](auto) { return std::optional<Response>{}; });
    });

    EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
      return sequencer.PushBack("Finish").then([](auto) {
        return RedirectError("handle-redirect-3456", "token-redirect-3456");
      });
    });

    return stream;
  };

  auto constexpr kLength = 100;
  auto constexpr kOffset = 20000;
  auto constexpr kReadSpecText = R"pb(
    bucket: "test-only-invalid"
    object: "test-object"
    generation: 24
    if_generation_match: 42
  )pb";
  // The resume request should include all the remaining ranges, starting from
  // the remaining offset (10 bytes after the start).
  auto constexpr kResumeRequest = R"pb(
    read_object_spec {
      bucket: "test-only-invalid"
      object: "test-object"
      generation: 24
      if_generation_match: 42
      read_handle { handle: "handle-redirect-3456" }
      routing_token: "token-redirect-3456"
    }
    read_ranges { read_id: 1 read_offset: 20000 read_length: 100 }
  )pb";

  Request expected_resume_request;
  ASSERT_TRUE(
      TextFormat::ParseFromString(kResumeRequest, &expected_resume_request));

  MockFactory factory;
  EXPECT_CALL(factory, Call)
      .WillOnce([](Request const& request) {
        EXPECT_TRUE(request.read_ranges().empty());
        return make_ready_future(StatusOr<OpenStreamResult>(TransientError()));
      })
      .WillOnce([&](Request const& request) {
        EXPECT_THAT(request, IsProtoEqualModuloRepeatedFieldOrdering(
                                 expected_resume_request));
        // Resume with an unrecoverable failure to simplify the test.
        return sequencer.PushBack("Factory").then(
            [](auto) { return StatusOr<OpenStreamResult>(PermanentError()); });
      });

  auto spec = google::storage::v2::BidiReadObjectSpec{};
  ASSERT_TRUE(TextFormat::ParseFromString(kReadSpecText, &spec));
  auto tested = MakeTested(storage::LimitedErrorCountResumePolicy(1)(),
                           factory.AsStdFunction(), spec,
                           std::make_shared<OpenStream>(initial_stream()));
  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponse0, &response));
  tested->Start(std::move(response));
  EXPECT_TRUE(tested->metadata().has_value());

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({kOffset, kLength});
  ASSERT_THAT(s1, NotNull());

  // Asking for data should result in an immediate `Write()` message with the
  // first range.
  auto write1 = sequencer.PopFrontWithName();
  EXPECT_EQ(write1.second, "Write[1]");

  // Simulate the recoverable failure.
  read1.first.set_value(false);
  write1.first.set_value(false);
  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Factory");
  next.first.set_value(true);

  // The ranges fails with the same error.
  EXPECT_THAT(s1->Read().get(), VariantWith<Status>(PermanentError()));
}

Status PartialFailure(std::int64_t read_id) {
  auto details = [&] {
    auto error = google::storage::v2::BidiReadObjectError{};
    auto& range_error = *error.add_read_range_errors();
    range_error.set_read_id(read_id);
    range_error.mutable_status()->set_code(grpc::StatusCode::INVALID_ARGUMENT);
    range_error.mutable_status()->set_message("out of range read");

    auto details_proto = google::rpc::Status{};
    details_proto.set_code(grpc::StatusCode::INVALID_ARGUMENT);
    details_proto.set_message("some reads are out of range");
    (void)details_proto.add_details()->PackFrom(error);

    std::string details;
    (void)details_proto.SerializeToString(&details);
    return details;
  };

  return google::cloud::MakeStatusFromRpcError(
      grpc::Status(grpc::StatusCode::INVALID_ARGUMENT, "redirect", details()));
}

/// @test When the underlying stream fails with unrecoverable errors all ranges
/// fail.
TEST(ObjectDescriptorImpl, RecoverFromPartialFailure) {
  ScopedLog log;

  auto constexpr kLength = 100;
  auto constexpr kOffset = 20000;
  auto constexpr kReadSpecText = R"pb(
    bucket: "test-only-invalid"
    object: "test-object"
    generation: 24
    if_generation_match: 42
  )pb";
  auto constexpr kRequest1 = R"pb(
    read_ranges { read_id: 1 read_offset: 20000 read_length: 100 }
  )pb";
  auto constexpr kRequest2 = R"pb(
    read_ranges { read_id: 2 read_offset: 4000000 read_length: 100 }
    read_ranges { read_id: 3 read_offset: 60000 read_length: 100 }
  )pb";

  // The resume request should include all the remaining ranges.
  auto constexpr kResumeRequest = R"pb(
    read_object_spec {
      bucket: "test-only-invalid"
      object: "test-object"
      generation: 24
      if_generation_match: 42
    }
    read_ranges { read_id: 1 read_offset: 20000 read_length: 100 }
    read_ranges { read_id: 3 read_offset: 60000 read_length: 100 }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kRequest1, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      })
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kRequest2, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[2]").then([](auto f) {
          return f.get();
        });
      });

  EXPECT_CALL(*stream, Read).WillOnce([&]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });

  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then([](auto) {
      // Return an error, indicating that range #2 is invalid. It should
      // resume with the new ranges.
      return PartialFailure(2);
    });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  Request expected_resume_request;
  ASSERT_TRUE(
      TextFormat::ParseFromString(kResumeRequest, &expected_resume_request));
  MockFactory factory;
  EXPECT_CALL(factory, Call)
      .WillOnce([](Request const& request) {
        EXPECT_TRUE(request.read_ranges().empty());
        return make_ready_future(StatusOr<OpenStreamResult>(TransientError()));
      })
      .WillOnce([&](Request const& request) {
        EXPECT_THAT(request, IsProtoEqualModuloRepeatedFieldOrdering(
                                 expected_resume_request));
        // Resume with an unrecoverable failure to simplify the test.
        return sequencer.PushBack("Factory").then(
            [](auto) { return StatusOr<OpenStreamResult>(PermanentError()); });
      });

  auto spec = google::storage::v2::BidiReadObjectSpec{};
  EXPECT_TRUE(TextFormat::ParseFromString(kReadSpecText, &spec));
  auto tested = MakeTested(NoResume(), factory.AsStdFunction(), spec,
                           std::make_shared<OpenStream>(std::move(stream)));
  tested->Start(Response{});
  EXPECT_FALSE(tested->metadata().has_value());

  auto read = sequencer.PopFrontWithName();
  EXPECT_EQ(read.second, "Read[1]");

  auto s1 = tested->Read({kOffset, kLength});
  ASSERT_THAT(s1, NotNull());

  // Asking for data should result in an immediate `Write()` message with the
  // first range.
  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[1]");

  // Additional ranges are queued until the first `Write()` call is completed.
  auto s2 = tested->Read({2 * kOffset * 100, kLength});
  ASSERT_THAT(s2, NotNull());

  auto s3 = tested->Read({3 * kOffset, kLength});
  ASSERT_THAT(s3, NotNull());

  // Complete the first `Write()` call, that should result in a second
  // `Write()` call with the two additional ranges.
  next.first.set_value(true);

  // And then the follow up `Write()` message with the queued information.
  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[2]");
  next.first.set_value(true);

  auto s1r1 = s1->Read();
  auto s2r1 = s2->Read();
  auto s3r1 = s3->Read();
  EXPECT_FALSE(s1r1.is_ready());
  EXPECT_FALSE(s2r1.is_ready());
  EXPECT_FALSE(s3r1.is_ready());

  // Simulate a failure.
  read.first.set_value(false);
  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);

  // Range 2 should fail with the invalid argument error.
  EXPECT_THAT(s2r1.get(),
              VariantWith<Status>(StatusIs(StatusCode::kInvalidArgument)));

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Factory");
  next.first.set_value(true);

  // All the other ranges fail with the same error.
  EXPECT_THAT(s1r1.get(), VariantWith<Status>(PermanentError()));
  EXPECT_THAT(s3r1.get(), VariantWith<Status>(PermanentError()));

  // The stream ended to report a per-range error, and range #2 was completed
  // with that error rather than retried. Re-opening the stream carries the
  // ranges that are left; it is not a retry of anything, and calling it one
  // would attach a "transient error retried" warning to a permanent failure
  // the application has already been told about.
  EXPECT_THAT(log.ExtractLines(), Not(Contains(HasSubstr("[gcs-retry]"))));
}

/// @test Verify that a background stream is created proactively.
TEST(ObjectDescriptorImpl, ProactiveStreamCreation) {
  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Read).WillOnce([&] {
    return sequencer.PushBack("Read").then(
        [](auto) { return std::optional<Response>(); });
  });
  EXPECT_CALL(*stream, Finish).WillOnce(Return(make_ready_future(Status{})));
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));  // Always called by OpenStream

  MockFactory factory;
  // This is the proactive stream creation. The implementation is designed to
  // always keep a pending stream in flight, so it may call the factory more
  // than once if a pending stream is consumed or fails. We use WillRepeatedly
  // to make the test robust to this behavior.
  EXPECT_CALL(factory, Call).WillRepeatedly([&](Request const& request) {
    EXPECT_TRUE(request.read_ranges().empty());
    return sequencer.PushBack("Factory").then(
        [](auto) { return StatusOr<OpenStreamResult>(PermanentError()); });
  });

  auto tested = MakeTested(NoResume(), factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream)));

  tested->Start(Response{});

  // In the implementation, the Read() is started before the factory call.
  auto read_called = sequencer.PopFrontWithName();
  EXPECT_EQ(read_called.second, "Read");

  auto factory_called = sequencer.PopFrontWithName();
  EXPECT_EQ(factory_called.second, "Factory");

  // Allow the events to complete.
  read_called.first.set_value(true);
  factory_called.first.set_value(true);
}

/// @test Verify a new stream is used if all existing streams are busy.
TEST(ObjectDescriptorImpl, MakeSubsequentStreamCreatesNewWhenAllBusy) {
  AsyncSequencer<bool> sequencer;

  // Setup for the first stream, which will remain busy.
  auto stream1 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream1, Write(_, _))
      .Times(::testing::AtMost(1))
      .WillRepeatedly(
          [](Request const&, auto) { return make_ready_future(true); });
  // Keep stream1 busy but return ready futures.
  EXPECT_CALL(*stream1, Read).WillRepeatedly([] {
    return make_ready_future(std::optional<Response>{});
  });
  EXPECT_CALL(*stream1, Finish).WillOnce([] {
    return make_ready_future(Status{});
  });
  EXPECT_CALL(*stream1, Cancel).Times(AtMost(1));

  // Setup for the second stream, which will be created proactively.
  auto stream2 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream2, Write(_, _))
      .Times(::testing::AtMost(1))
      .WillRepeatedly([](...) { return make_ready_future(true); });
  EXPECT_CALL(*stream2, Read).WillRepeatedly([] {
    return make_ready_future(std::optional<Response>{});
  });
  EXPECT_CALL(*stream2, Finish).WillRepeatedly([] {
    return make_ready_future(Status{});
  });
  EXPECT_CALL(*stream2, Cancel).Times(AtMost(1));

  // First call is proactive for stream2. It may be called more than once.
  MockFactory factory;
  EXPECT_CALL(factory, Call)
      .WillOnce([&](Request const&) {
        return make_ready_future(StatusOr<OpenStreamResult>(OpenStreamResult{
            std::make_shared<OpenStream>(std::move(stream2)), Response{}}));
      })
      .WillRepeatedly([](Request const&) {
        return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
      });

  auto tested = MakeTested(NoResume(), factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream1)));
  tested->Start(Response{});

  // Start a read on stream1 to make it busy.
  auto reader1 = tested->Read({0, 100});

  // Call MakeSubsequentStream. Since stream1 is busy, this should activate the
  // pending stream (stream2).
  tested->MakeSubsequentStream();

  // A new read should now be routed to stream2.
  auto reader2 = tested->Read({100, 200});

  // stream2 returns ready futures; no sequencer pop needed here.
  tested->Cancel();
  tested.reset();
}

/// @test Verify reusing an idle stream that is already last is a no-op.
TEST(ObjectDescriptorImpl, MakeSubsequentStreamReusesIdleStreamAlreadyLast) {
  AsyncSequencer<bool> sequencer;

  // Setup for the first and only stream.
  auto stream1 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream1, Write(_, _))
      .Times(AtMost(1))
      .WillRepeatedly(
          [](auto const&, auto) { return make_ready_future(true); });

  EXPECT_CALL(*stream1, Read)
      .WillOnce([&] {  // From Start()
        return sequencer.PushBack("Read[1.1]").then([](auto) {
          auto resp = Response{};
          auto* r = resp.add_object_data_ranges();
          r->set_range_end(true);
          r->mutable_read_range()->set_read_id(0);
          r->mutable_read_range()->set_read_offset(0);
          return std::make_optional(std::move(resp));
        });
      })
      .WillOnce([&] {  // From OnRead() loop
        return sequencer.PushBack("Read[1.2]").then([](auto) {
          return std::make_optional(Response{});
        });
      })
      .WillOnce([] {  // Complete read_id=1
        auto resp = Response{};
        auto* r = resp.add_object_data_ranges();
        r->set_range_end(true);
        r->mutable_read_range()->set_read_id(1);
        r->mutable_read_range()->set_read_offset(0);
        return make_ready_future(std::make_optional(std::move(resp)));
      })
      .WillRepeatedly(
          [] { return make_ready_future(std::optional<Response>{}); });

  // Finish() will be called by the OpenStream destructor.
  EXPECT_CALL(*stream1, Finish).WillOnce(Return(make_ready_future(Status{})));
  EXPECT_CALL(*stream1, Cancel)
      .Times(AtMost(1));  // Always called by OpenStream

  MockFactory factory;
  EXPECT_CALL(factory, Call)
      .WillOnce([](Request const&) {
        return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
      })
      .WillRepeatedly([](Request const&) {
        return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
      });

  auto tested = MakeTested(NoResume(), factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream1)));
  auto start_response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(
      R"pb(object_data_ranges { read_range { read_id: 0 read_offset: 0 } })pb",
      &start_response));
  tested->Start(std::move(start_response));

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1.1]");
  read1.first.set_value(true);

  auto read2 = sequencer.PopFrontWithName();
  EXPECT_EQ(read2.second, "Read[1.2]");
  read2.first.set_value(true);

  // Call MakeSubsequentStream. It should find stream1 and return.
  tested->MakeSubsequentStream();

  // Ensure background activity stops cleanly.
  tested->Cancel();
  tested.reset();
}

/// @test Verify an idle stream at the front is moved to the back and reused.
TEST(ObjectDescriptorImpl, MakeSubsequentStreamReusesAndMovesIdleStream) {
  AsyncSequencer<bool> sequencer;

  // First stream setup
  auto stream1 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream1, Write(_, _)).WillRepeatedly([](auto const&, auto) {
    return make_ready_future(true);
  });

  EXPECT_CALL(*stream1, Read)
      .WillOnce([&] {  // From Start()
        return sequencer.PushBack("Read[1.1]").then([](auto) {
          return std::make_optional(Response{});
        });
      })
      .WillOnce([] {  // From OnRead() loop
        auto response = Response{};
        auto* r = response.add_object_data_ranges();
        r->set_range_end(true);
        r->mutable_read_range()->set_read_id(1);
        r->mutable_read_range()->set_read_offset(0);
        return make_ready_future(std::make_optional(std::move(response)));
      })
      .WillOnce([] {  // From OnRead() loop after reader1 done
        return make_ready_future(std::make_optional(Response{}));
      })
      .WillRepeatedly(
          [] { return make_ready_future(std::optional<Response>{}); });
  EXPECT_CALL(*stream1, Finish).WillOnce(Return(make_ready_future(Status{})));
  EXPECT_CALL(*stream1, Cancel).Times(AtMost(1));

  // Second stream setup
  auto stream2 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream2, Write(_, _))
      .WillOnce([&](Request const&, auto) {
        return sequencer.PushBack("Write[2.1]").then([](auto f) {
          return f.get();
        });
      })
      .WillRepeatedly(
          [](auto const&, auto) { return make_ready_future(true); });
  EXPECT_CALL(*stream2, Read)
      .WillOnce([&] {
        return sequencer.PushBack("Read[2.1]").then([](auto) {
          auto resp = Response{};
          auto* r = resp.add_object_data_ranges();
          r->set_range_end(true);
          r->mutable_read_range()->set_read_id(2);
          r->mutable_read_range()->set_read_offset(100);
          return std::make_optional(std::move(resp));
        });
      })
      .WillRepeatedly(
          [] { return make_ready_future(std::optional<Response>{}); });
  EXPECT_CALL(*stream2, Finish).WillOnce(Return(make_ready_future(Status{})));
  EXPECT_CALL(*stream2, Cancel).Times(AtMost(1));

  // Third stream setup
  auto stream3 = std::make_unique<MockStream>();
  // stream3 sits in pending_stream_ and may become active; provide ready
  // defaults.
  EXPECT_CALL(*stream3, Write(_, _)).WillRepeatedly([](auto const&, auto) {
    return make_ready_future(true);
  });
  EXPECT_CALL(*stream3, Read).WillRepeatedly([] {
    return make_ready_future(std::optional<Response>{});
  });
  // stream3 sits in pending_stream_ and is destroyed when the test ends.
  // It is never "started", so Finish() is never called.
  EXPECT_CALL(*stream3, Finish).Times(AtMost(1)).WillRepeatedly([] {
    return make_ready_future(Status{});
  });
  EXPECT_CALL(*stream3, Cancel).Times(AtMost(1));

  // Mock factory for subsequent streams
  MockFactory factory;
  EXPECT_CALL(factory, Call)
      .WillOnce([&] {  // For stream2 (Triggered by Start)
        auto resp = Response{};
        EXPECT_TRUE(
            TextFormat::ParseFromString(
                R"pb(object_data_ranges {
                       read_range { read_id: 0 read_offset: 0 }
                     })pb",
                &resp));
        return make_ready_future(StatusOr<OpenStreamResult>(
            OpenStreamResult{std::make_shared<OpenStream>(std::move(stream2)),
                             std::move(resp)}));
      })
      .WillOnce([&] {  // For stream3 (Triggered by MakeSubsequentStream)
        return make_ready_future(StatusOr<OpenStreamResult>(OpenStreamResult{
            std::make_shared<OpenStream>(std::move(stream3)), Response{}}));
      })
      .WillRepeatedly([&](Request const&) {
        return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
      });

  auto tested = MakeTested(NoResume(), factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream1)));

  auto start_response = Response{};
  ASSERT_TRUE(TextFormat::ParseFromString(
      R"pb(object_data_ranges { read_range { read_id: 0 read_offset: 0 } })pb",
      &start_response));
  tested->Start(std::move(start_response));

  auto read1_1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1_1.second, "Read[1.1]");

  // Make stream1 busy
  auto reader1 = tested->Read({0, 100});

  // Create and switch to a new stream. This happens before the first
  // stream is finished.
  tested->MakeSubsequentStream();

  auto read2_1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read2_1.second, "Read[2.1]");

  // Make stream2 busy
  auto reader2 = tested->Read({100, 200});
  auto write2_1 = sequencer.PopFrontWithName();
  EXPECT_EQ(write2_1.second, "Write[2.1]");
  write2_1.first.set_value(true);  // Complete write immediately

  // Make stream1 IDLE.
  auto r1f1 = reader1->Read();
  read1_1.first.set_value(true);
  // read1_2/read1_3 completed via ready futures; no sequencer pops needed.
  ASSERT_THAT(r1f1.get(), VariantWith<storage::ReadPayload>(_));
  auto r1f2 = reader1->Read();
  ASSERT_THAT(r1f2.get(), VariantWith<Status>(IsOk()));

  // Call MakeSubsequentStream. It finds stream1, moves it, and returns.
  tested->MakeSubsequentStream();

  auto reader3 = tested->Read({200, 300});
  read2_1.first.set_value(true);
  tested.reset();
}

/// @test Verify that a successful resume executes the OnResume logic correctly.
TEST(ObjectDescriptorImpl, OnResumeSuccessful) {
  AsyncSequencer<bool> sequencer;

  auto expect_startup_events = [&](AsyncSequencer<bool>& seq) {
    auto e1 = seq.PopFrontWithName();
    auto e2 = seq.PopFrontWithName();
    std::set<std::string> names = {e1.second, e2.second};
    if (names.count("Read[1]") != 0 && names.count("ProactiveFactory") != 0) {
      e1.first.set_value(true);
      e2.first.set_value(true);
    } else {
      ADD_FAILURE() << "Got unexpected events: " << e1.second << ", "
                    << e2.second;
    }
  };

  auto stream1 = std::make_unique<MockStream>();
  // To keep Stream 1 alive during startup, the first Read returns a valid
  // (empty) response. Subsequent reads return nullopt to trigger the
  // Finish/Resume logic.
  EXPECT_CALL(*stream1, Read)
      .WillOnce([&] {
        return sequencer.PushBack("Read[1]").then(
            [](auto) { return std::make_optional(Response{}); });
      })
      .WillRepeatedly([&] {
        return sequencer.PushBack("Read[Loop]").then([](auto) {
          return std::optional<Response>{};
        });
      });

  EXPECT_CALL(*stream1, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish[1]").then([](auto) {
      return TransientError();
    });
  });
  EXPECT_CALL(*stream1, Write)
      .WillOnce([&](Request const&, grpc::WriteOptions) {
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream1, Cancel).Times(AtMost(1));

  auto stream2 = std::make_unique<MockStream>();
  // The resumed stream to starts reading immediately.
  EXPECT_CALL(*stream2, Read).WillRepeatedly([&] {
    return sequencer.PushBack("Read[2]").then(
        [](auto) { return std::make_optional(Response{}); });
  });
  EXPECT_CALL(*stream2, Finish).WillOnce(Return(make_ready_future(Status{})));
  EXPECT_CALL(*stream2, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call)
      .WillOnce([&](auto) {
        return sequencer.PushBack("ProactiveFactory").then([](auto) {
          return StatusOr<OpenStreamResult>(TransientError());
        });
      })
      .WillOnce([&](auto) {
        return sequencer.PushBack("ResumeFactory").then([&](auto) {
          return StatusOr<OpenStreamResult>(OpenStreamResult{
              std::make_shared<OpenStream>(std::move(stream2)), Response{}});
        });
      });

  auto tested = MakeTested(storage::LimitedErrorCountResumePolicy(1)(),
                           factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream1)));

  tested->Start(Response{});
  expect_startup_events(sequencer);

  // Register the read range.
  auto reader = tested->Read({0, 100});

  bool write1_seen = false;
  bool read_loop_seen = false;
  promise<bool> fail_stream_promise;

  while (!write1_seen || !read_loop_seen) {
    auto event = sequencer.PopFrontWithName();
    if (event.second == "Write[1]") {
      EXPECT_FALSE(write1_seen);
      write1_seen = true;
      event.first.set_value(true);
    } else if (event.second == "Read[Loop]") {
      EXPECT_FALSE(read_loop_seen);
      read_loop_seen = true;
      fail_stream_promise = std::move(event.first);
    } else {
      FAIL() << "Unexpected event: " << event.second;
    }
  }

  // Trigger Failure on Stream 1.
  fail_stream_promise.set_value(true);

  auto f1 = sequencer.PopFrontWithName();
  EXPECT_EQ(f1.second, "Finish[1]");
  f1.first.set_value(true);

  auto resume = sequencer.PopFrontWithName();
  EXPECT_EQ(resume.second, "ResumeFactory");
  resume.first.set_value(true);

  // The OnResume block calls OnRead, which triggers Read() on Stream 2.
  auto r2 = sequencer.PopFrontWithName();
  EXPECT_EQ(r2.second, "Read[2]");
  r2.first.set_value(true);

  tested.reset();
}

/// @test Verify Read() behavior when all streams have failed permanently.
TEST(ObjectDescriptorImpl, ReadFailsWhenAllStreamsAreDead) {
  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();

  // Initial Read returns empty (EOF) to trigger Finish
  EXPECT_CALL(*stream, Read).WillOnce([&] {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });

  EXPECT_CALL(*stream, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([&](auto) {
    return sequencer.PushBack("ProactiveFactory").then([](auto) {
      return StatusOr<OpenStreamResult>(PermanentError());
    });
  });

  auto tested = MakeTested(NoResume(), factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream)));

  tested->Start(Response{});

  auto e1 = sequencer.PopFrontWithName();
  auto e2 = sequencer.PopFrontWithName();

  std::set<std::string> names = {e1.second, e2.second};
  ASSERT_EQ(names.count("Read[1]"), 1);
  ASSERT_EQ(names.count("ProactiveFactory"), 1);

  e1.first.set_value(true);
  e2.first.set_value(true);

  auto finish = sequencer.PopFrontWithName();
  EXPECT_EQ(finish.second, "Finish");
  finish.first.set_value(true);

  // At this point, the only active stream failed permanently and was removed.
  // The proactive stream creation also failed. The manager is now EMPTY.

  auto reader = tested->Read({0, 100});

  // The Read() should immediately fail with FailedPrecondition.
  auto result = reader->Read().get();
  EXPECT_THAT(result,
              VariantWith<Status>(StatusIs(StatusCode::kFailedPrecondition)));
}

/// @test Verify that disabling multi-stream optimization prevents background
/// stream creation.
TEST(ObjectDescriptorImpl, MultiStreamOptimizationDisabled) {
  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();

  EXPECT_CALL(*stream, Finish).WillOnce(Return(make_ready_future(Status{})));
  EXPECT_CALL(*stream, Cancel).Times(1);

  MockFactory factory;
  Options options;
  options.set<storage::EnableMultiStreamOptimizationOption>(false);

  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options);

  tested->MakeSubsequentStream();

  tested.reset();
}

/// @test Verify that IsOpen() is true by default.
TEST(ObjectDescriptorImpl, IsOpenTrueByDefault) {
  MockFactory factory;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Finish).WillOnce(Return(make_ready_future(Status{})));
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));
  auto tested = MakeTested(NoResume(), factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream)));
  EXPECT_TRUE(tested->IsOpen());
}

/// @test Verify that IsOpen() is false after Cancel().
TEST(ObjectDescriptorImpl, IsOpenFalseOnCancel) {
  MockFactory factory;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Finish).WillOnce(Return(make_ready_future(Status{})));
  EXPECT_CALL(*stream, Cancel).Times(AtMost(2));
  auto tested = MakeTested(NoResume(), factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream)));
  EXPECT_TRUE(tested->IsOpen());
  tested->Cancel();
  EXPECT_FALSE(tested->IsOpen());
}

/// @test Verify that IsOpen() is false if transport health check fails.
TEST(ObjectDescriptorImpl, IsOpenFalseOnPermanentError) {
  MockFactory factory;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Finish).WillOnce(Return(make_ready_future(Status{})));
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));
  bool transport_ok = true;
  auto transport_ok_callback = [&transport_ok] { return transport_ok; };

  auto tested = MakeTested(NoResume(), factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream)),
                           transport_ok_callback);

  EXPECT_TRUE(tested->IsOpen());
  transport_ok = false;
  EXPECT_FALSE(tested->IsOpen());
}

TEST(ObjectDescriptorImpl, IsOpenFalseOnTransportFailure) {
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Cancel).Times(1);
  EXPECT_CALL(*stream, Finish).WillOnce([] {
    return make_ready_future(Status{});
  });
  MockFactory factory;
  auto transport_ok = [] { return false; };
  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), Options{},
      std::move(transport_ok));
  EXPECT_FALSE(tested->IsOpen());
}

TEST(ObjectDescriptorImpl, IsOpenTrueOnTransportSuccess) {
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Cancel).Times(1);
  EXPECT_CALL(*stream, Finish).WillOnce([] {
    return make_ready_future(Status{});
  });
  MockFactory factory;
  auto transport_ok = [] { return true; };
  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), Options{},
      std::move(transport_ok));
  EXPECT_TRUE(tested->IsOpen());
}

TEST(ObjectDescriptorImpl, FullReadChecksumValidationSuccess) {
  auto constexpr kResponseMetadata = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
      size: 43
      finalize_time { seconds: 1234567890 }
      checksums {
        crc32c: 576848900
        md5_hash: "\236\020\175\235\067\053\266\202\153\330\035\065\102\244\031\326"
      }
    }
    read_handle { handle: "handle-12345" }
  )pb";

  auto constexpr kRequest1 = R"pb(
    read_ranges { read_id: 1 read_offset: 0 read_length: 43 }
  )pb";

  auto constexpr kResponse1 = R"pb(
    read_handle { handle: "handle-23456" }
    object_data_ranges {
      range_end: true
      read_range { read_id: 1 read_offset: 0 }
      checksummed_data {
        content: "The quick brown fox jumps over the lazy dog"
        crc32c: 576848900
      }
    }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kRequest1, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream, Read)
      .WillOnce([=, &sequencer]() {
        return sequencer.PushBack("Read[1]").then([&](auto) {
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse1, &response));
          return std::make_optional(response);
        });
      })
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });

  Options options;
  options.set<storage::EnableCrc32cValidationOption>(true);
  options.set<storage::EnableMD5ValidationOption>(true);

  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options);

  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponseMetadata, &response));
  tested->Start(std::move(response));

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({0, 43});
  auto s1r1 = s1->Read();

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[1]");
  next.first.set_value(true);
  read1.first.set_value(true);

  EXPECT_THAT(s1r1.get(),
              VariantWith<storage::ReadPayload>(ResultOf(
                  "contents are",
                  [](storage::ReadPayload const& p) { return p.contents(); },
                  ElementsAre(absl::string_view{
                      "The quick brown fox jumps over the lazy dog"}))));

  EXPECT_THAT(s1->Read().get(), VariantWith<Status>(IsOk()));

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Read[2]");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);
}

TEST(ObjectDescriptorImpl, FullReadChecksumValidationMismatchCrc32c) {
  auto constexpr kResponseMetadata = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
      size: 43
      finalize_time { seconds: 1234567890 }
      checksums {
        crc32c: 12345
        md5_hash: "\236\020\175\235\067\053\266\202\153\330\035\065\102\244\031\326"
      }
    }
    read_handle { handle: "handle-12345" }
  )pb";

  auto constexpr kRequest1 = R"pb(
    read_ranges { read_id: 1 read_offset: 0 read_length: 43 }
  )pb";

  auto constexpr kResponse1 = R"pb(
    read_handle { handle: "handle-23456" }
    object_data_ranges {
      range_end: true
      read_range { read_id: 1 read_offset: 0 }
      checksummed_data {
        content: "The quick brown fox jumps over the lazy dog"
        crc32c: 576848900
      }
    }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kRequest1, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream, Read)
      .WillOnce([=, &sequencer]() {
        return sequencer.PushBack("Read[1]").then([&](auto) {
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse1, &response));
          return std::make_optional(response);
        });
      })
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });

  Options options;
  options.set<storage::EnableCrc32cValidationOption>(true);
  options.set<storage::EnableMD5ValidationOption>(true);

  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options);

  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponseMetadata, &response));
  tested->Start(std::move(response));

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({0, 43});
  auto s1r1 = s1->Read();

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[1]");
  next.first.set_value(true);
  read1.first.set_value(true);

  EXPECT_THAT(s1r1.get(),
              VariantWith<storage::ReadPayload>(ResultOf(
                  "contents are",
                  [](storage::ReadPayload const& p) { return p.contents(); },
                  ElementsAre(absl::string_view{
                      "The quick brown fox jumps over the lazy dog"}))));

  EXPECT_THAT(s1->Read().get(),
              VariantWith<Status>(StatusIs(StatusCode::kDataLoss)));

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Read[2]");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);
}

TEST(ObjectDescriptorImpl, FullReadChecksumValidationMismatchMd5) {
  auto constexpr kResponseMetadata = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
      size: 43
      finalize_time { seconds: 1234567890 }
      checksums {
        crc32c: 576848900
        md5_hash: "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
      }
    }
    read_handle { handle: "handle-12345" }
  )pb";

  auto constexpr kRequest1 = R"pb(
    read_ranges { read_id: 1 read_offset: 0 read_length: 43 }
  )pb";

  auto constexpr kResponse1 = R"pb(
    read_handle { handle: "handle-23456" }
    object_data_ranges {
      range_end: true
      read_range { read_id: 1 read_offset: 0 }
      checksummed_data {
        content: "The quick brown fox jumps over the lazy dog"
        crc32c: 576848900
      }
    }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kRequest1, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream, Read)
      .WillOnce([=, &sequencer]() {
        return sequencer.PushBack("Read[1]").then([&](auto) {
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse1, &response));
          return std::make_optional(response);
        });
      })
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });

  Options options;
  options.set<storage::EnableCrc32cValidationOption>(true);
  options.set<storage::EnableMD5ValidationOption>(true);

  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options);

  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponseMetadata, &response));
  tested->Start(std::move(response));

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({0, 43});
  auto s1r1 = s1->Read();

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[1]");
  next.first.set_value(true);
  read1.first.set_value(true);

  EXPECT_THAT(s1r1.get(),
              VariantWith<storage::ReadPayload>(ResultOf(
                  "contents are",
                  [](storage::ReadPayload const& p) { return p.contents(); },
                  ElementsAre(absl::string_view{
                      "The quick brown fox jumps over the lazy dog"}))));

  EXPECT_THAT(s1->Read().get(),
              VariantWith<Status>(StatusIs(StatusCode::kDataLoss)));

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Read[2]");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);
}

TEST(ObjectDescriptorImpl, PartialReadChecksumValidationBypassed) {
  auto constexpr kResponseMetadata = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
      size: 100
      checksums {
        crc32c: 12345
        md5_hash: "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
      }
    }
    read_handle { handle: "handle-12345" }
  )pb";

  auto constexpr kRequest1 = R"pb(
    read_ranges { read_id: 1 read_offset: 0 read_length: 43 }
  )pb";

  auto constexpr kResponse1 = R"pb(
    read_handle { handle: "handle-23456" }
    object_data_ranges {
      range_end: true
      read_range { read_id: 1 read_offset: 0 }
      checksummed_data {
        content: "The quick brown fox jumps over the lazy dog"
        crc32c: 576848900
      }
    }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kRequest1, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream, Read)
      .WillOnce([=, &sequencer]() {
        return sequencer.PushBack("Read[1]").then([&](auto) {
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse1, &response));
          return std::make_optional(response);
        });
      })
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });

  Options options;
  options.set<storage::EnableCrc32cValidationOption>(true);
  options.set<storage::EnableMD5ValidationOption>(true);

  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options);

  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponseMetadata, &response));
  tested->Start(std::move(response));

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({0, 43});
  auto s1r1 = s1->Read();

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[1]");
  next.first.set_value(true);
  read1.first.set_value(true);

  EXPECT_THAT(s1r1.get(),
              VariantWith<storage::ReadPayload>(ResultOf(
                  "contents are",
                  [](storage::ReadPayload const& p) { return p.contents(); },
                  ElementsAre(absl::string_view{
                      "The quick brown fox jumps over the lazy dog"}))));

  EXPECT_THAT(s1->Read().get(), VariantWith<Status>(IsOk()));

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Read[2]");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);
}

/// @test Verify that reading an unfinalized object (e.g. appendable object
/// without finalize_time) from offset 0 bypasses full-object checksum
/// validation against open-time metadata checksums, while still validating
/// chunk-level CRC32C.
TEST(ObjectDescriptorImpl,
     UnfinalizedObjectReadFromOffset0BypassesFullChecksumValidation) {
  auto constexpr kResponseMetadata = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
      size: 16
      checksums {
        crc32c: 12345
        md5_hash: "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
      }
    }
    read_handle { handle: "handle-12345" }
  )pb";

  auto constexpr kRequest1 = R"pb(
    read_ranges { read_id: 1 read_offset: 0 read_length: 0 }
  )pb";

  auto constexpr kResponse1 = R"pb(
    read_handle { handle: "handle-23456" }
    object_data_ranges {
      range_end: true
      read_range { read_id: 1 read_offset: 0 }
      checksummed_data {
        content: "The quick brown fox jumps over the lazy dog"
        crc32c: 576848900
      }
    }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kRequest1, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream, Read)
      .WillOnce([=, &sequencer]() {
        return sequencer.PushBack("Read[1]").then([&](auto) {
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse1, &response));
          return std::make_optional(response);
        });
      })
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });

  Options options;
  options.set<storage::EnableCrc32cValidationOption>(true);
  options.set<storage::EnableMD5ValidationOption>(true);

  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options);

  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponseMetadata, &response));
  tested->Start(std::move(response));

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({0, 0});
  auto s1r1 = s1->Read();

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[1]");
  next.first.set_value(true);
  read1.first.set_value(true);

  EXPECT_THAT(s1r1.get(),
              VariantWith<storage::ReadPayload>(ResultOf(
                  "contents are",
                  [](storage::ReadPayload const& p) { return p.contents(); },
                  ElementsAre(std::string_view{
                      "The quick brown fox jumps over the lazy dog"}))));

  EXPECT_THAT(s1->Read().get(), VariantWith<Status>(IsOk()));

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Read[2]");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);
}

/// @test Verify that reading an unfinalized object from offset 0 still
/// validates chunk-level CRC32C and fails with DATA_LOSS if a chunk contains
/// corrupted data.
TEST(ObjectDescriptorImpl,
     UnfinalizedObjectReadFromOffset0FailsOnCorruptChunkCrc32c) {
  auto constexpr kResponseMetadata = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
      size: 16
      checksums {
        crc32c: 12345
        md5_hash: "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
      }
    }
    read_handle { handle: "handle-12345" }
  )pb";

  auto constexpr kRequest1 = R"pb(
    read_ranges { read_id: 1 read_offset: 0 read_length: 0 }
  )pb";

  auto constexpr kResponse1 = R"pb(
    read_handle { handle: "handle-23456" }
    object_data_ranges {
      range_end: true
      read_range { read_id: 1 read_offset: 0 }
      checksummed_data {
        content: "The quick brown fox jumps over the lazy dog"
        crc32c: 999999
      }
    }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kRequest1, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream, Read)
      .WillOnce([=, &sequencer]() {
        return sequencer.PushBack("Read[1]").then([&](auto) {
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse1, &response));
          return std::make_optional(response);
        });
      })
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });

  Options options;
  options.set<storage::EnableCrc32cValidationOption>(true);
  options.set<storage::EnableMD5ValidationOption>(true);

  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options);

  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponseMetadata, &response));
  tested->Start(std::move(response));

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({0, 0});
  auto s1r1 = s1->Read();

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[1]");
  next.first.set_value(true);
  read1.first.set_value(true);

  EXPECT_THAT(s1r1.get(),
              VariantWith<storage::ReadPayload>(ResultOf(
                  "contents are",
                  [](storage::ReadPayload const& p) { return p.contents(); },
                  ElementsAre(std::string_view{
                      "The quick brown fox jumps over the lazy dog"}))));

  EXPECT_THAT(s1->Read().get(),
              VariantWith<Status>(StatusIs(StatusCode::kInvalidArgument)));

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Read[2]");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);
}

TEST(ObjectDescriptorImpl, PrewarmedCacheHit) {
  auto constexpr kResponse0 = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
    }
    read_handle { handle: "handle-12345" }
  )pb";

  auto constexpr kResponse1 = R"pb(
    read_handle { handle: "handle-23456" }
    object_data_ranges {
      range_end: true
      read_range { read_id: 1 read_offset: 0 }
      checksummed_data { content: "Pre-warmed data" }
    }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write).Times(0);

  EXPECT_CALL(*stream, Read)
      .WillOnce([=, &sequencer]() {
        return sequencer.PushBack("Read[1]").then([&](auto) {
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse1, &response));
          return std::make_optional(response);
        });
      })
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });

  Options options;
  options.set<storage::EnableMultiStreamOptimizationOption>(true);
  options.set<ReadRangesOption>({{0, 15}});

  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options);

  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponse0, &response));
  tested->Start(std::move(response));

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({0, 15});
  ASSERT_THAT(s1, NotNull());

  auto s1r1 = s1->Read();
  EXPECT_FALSE(s1r1.is_ready());

  read1.first.set_value(true);

  EXPECT_TRUE(s1r1.is_ready());
  EXPECT_THAT(s1r1.get(),
              VariantWith<storage::ReadPayload>(ResultOf(
                  "contents are",
                  [](storage::ReadPayload const& p) { return p.contents(); },
                  ElementsAre(std::string_view{"Pre-warmed data"}))));

  EXPECT_THAT(s1->Read().get(), VariantWith<Status>(IsOk()));

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Read[2]");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);
}

TEST(ObjectDescriptorImpl, PrewarmedCacheMiss) {
  auto constexpr kResponse0 = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
    }
    read_handle { handle: "handle-12345" }
  )pb";

  auto constexpr kExpectedRequest = R"pb(
    read_ranges { read_id: 2 read_offset: 100 read_length: 15 }
  )pb";

  auto constexpr kResponse1 = R"pb(
    object_data_ranges {
      range_end: true
      read_range { read_id: 2 read_offset: 100 }
      checksummed_data { content: "Missed range data" }
    }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kExpectedRequest, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });

  EXPECT_CALL(*stream, Read)
      .WillOnce([=, &sequencer]() {
        return sequencer.PushBack("Read[1]").then([&](auto) {
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse1, &response));
          return std::make_optional(response);
        });
      })
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });

  Options options;
  options.set<storage::EnableMultiStreamOptimizationOption>(true);
  options.set<ReadRangesOption>({{0, 15}});

  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options);

  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponse0, &response));
  tested->Start(std::move(response));

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({100, 15});
  ASSERT_THAT(s1, NotNull());

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[1]");
  next.first.set_value(true);

  auto s1r1 = s1->Read();
  EXPECT_FALSE(s1r1.is_ready());

  read1.first.set_value(true);

  EXPECT_TRUE(s1r1.is_ready());
  EXPECT_THAT(s1r1.get(),
              VariantWith<storage::ReadPayload>(ResultOf(
                  "contents are",
                  [](storage::ReadPayload const& p) { return p.contents(); },
                  ElementsAre(std::string_view{"Missed range data"}))));

  EXPECT_THAT(s1->Read().get(), VariantWith<Status>(IsOk()));

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Read[2]");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);
}

TEST(ObjectDescriptorImpl, PrewarmedPacingEviction) {
  auto constexpr kResponse0 = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
    }
    read_handle { handle: "handle-12345" }
  )pb";

  auto constexpr kResponse1 = R"pb(
    read_handle { handle: "handle-23456" }
    object_data_ranges {
      range_end: false
      read_range { read_id: 1 read_offset: 0 }
      checksummed_data { content: "123456" }
    }
  )pb";

  auto constexpr kExpectedRequest = R"pb(
    read_ranges { read_id: 2 read_offset: 0 read_length: 10 }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kExpectedRequest, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });

  EXPECT_CALL(*stream, Read)
      .WillOnce([=, &sequencer]() {
        return sequencer.PushBack("Read[1]").then([&](auto) {
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse1, &response));
          return std::make_optional(response);
        });
      })
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });
  EXPECT_CALL(*stream, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });

  Options options;
  options.set<storage::EnableMultiStreamOptimizationOption>(true);
  options.set<ReadRangesOption>({{0, 10}});
  options.set<PreWarmBufferLimitOption>(5);

  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options);

  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponse0, &response));
  tested->Start(std::move(response));

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");
  read1.first.set_value(true);

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Read[2]");

  auto s1 = tested->Read({0, 10});
  ASSERT_THAT(s1, NotNull());

  auto write_next = sequencer.PopFrontWithName();
  EXPECT_EQ(write_next.second, "Write[1]");
  write_next.first.set_value(true);

  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);
}

TEST(ObjectDescriptorImpl, InitialReadRangesExactRangeCacheHit) {
  auto constexpr kResponse0 = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
    }
    read_handle { handle: "handle-12345" }
  )pb";

  auto constexpr kResponse1 = R"pb(
    read_handle { handle: "handle-23456" }
    object_data_ranges {
      range_end: true
      read_range { read_id: 1 read_offset: 0 }
      checksummed_data { content: "Exact hit data" }
    }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write).Times(0);

  EXPECT_CALL(*stream, Read)
      .WillOnce([=, &sequencer]() {
        return sequencer.PushBack("Read[1]").then([&](auto) {
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse1, &response));
          return std::make_optional(response);
        });
      })
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });

  Options options;
  options.set<storage::EnableMultiStreamOptimizationOption>(true);
  options.set<ReadRangesOption>({{0, 1024}});

  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options);

  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponse0, &response));
  tested->Start(std::move(response));

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({0, 1024});
  ASSERT_THAT(s1, NotNull());

  auto s1r1 = s1->Read();
  EXPECT_FALSE(s1r1.is_ready());

  read1.first.set_value(true);

  EXPECT_TRUE(s1r1.is_ready());
  EXPECT_THAT(s1r1.get(),
              VariantWith<storage::ReadPayload>(ResultOf(
                  "contents are",
                  [](storage::ReadPayload const& p) { return p.contents(); },
                  ElementsAre(std::string_view{"Exact hit data"}))));

  EXPECT_THAT(s1->Read().get(), VariantWith<Status>(IsOk()));

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Read[2]");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);
}

TEST(ObjectDescriptorImpl, InitialReadRangesSubRangeCacheMiss) {
  auto constexpr kResponse0 = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
    }
    read_handle { handle: "handle-12345" }
  )pb";

  auto constexpr kExpectedRequest = R"pb(
    read_ranges { read_id: 2 read_offset: 0 read_length: 512 }
  )pb";

  auto constexpr kResponse1 = R"pb(
    object_data_ranges {
      range_end: true
      read_range { read_id: 2 read_offset: 0 }
      checksummed_data { content: "Sub range data" }
    }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kExpectedRequest, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });

  EXPECT_CALL(*stream, Read)
      .WillOnce([=, &sequencer]() {
        return sequencer.PushBack("Read[1]").then([&](auto) {
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse1, &response));
          return std::make_optional(response);
        });
      })
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });

  Options options;
  options.set<storage::EnableMultiStreamOptimizationOption>(true);
  options.set<ReadRangesOption>({{0, 1024}});

  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options);

  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponse0, &response));
  tested->Start(std::move(response));

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({0, 512});
  ASSERT_THAT(s1, NotNull());

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Write[1]");
  next.first.set_value(true);

  auto s1r1 = s1->Read();
  EXPECT_FALSE(s1r1.is_ready());

  read1.first.set_value(true);

  EXPECT_TRUE(s1r1.is_ready());
  EXPECT_THAT(s1r1.get(),
              VariantWith<storage::ReadPayload>(ResultOf(
                  "contents are",
                  [](storage::ReadPayload const& p) { return p.contents(); },
                  ElementsAre(std::string_view{"Sub range data"}))));

  EXPECT_THAT(s1->Read().get(), VariantWith<Status>(IsOk()));

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Read[2]");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);
}

TEST(ObjectDescriptorImpl, PreWarmBufferLimitEvictionTombstone) {
  auto constexpr kResponse0 = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
    }
    read_handle { handle: "handle-12345" }
  )pb";

  auto constexpr kResponse1 = R"pb(
    read_handle { handle: "handle-23456" }
    object_data_ranges {
      range_end: false
      read_range { read_id: 1 read_offset: 0 }
      checksummed_data { content: "123456" }
    }
  )pb";

  auto constexpr kExpectedRequest = R"pb(
    read_ranges { read_id: 2 read_offset: 0 read_length: 10 }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions) {
        auto expected = Request{};
        EXPECT_TRUE(TextFormat::ParseFromString(kExpectedRequest, &expected));
        EXPECT_THAT(request, IsProtoEqual(expected));
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });

  EXPECT_CALL(*stream, Read)
      .WillOnce([=, &sequencer]() {
        return sequencer.PushBack("Read[1]").then([&](auto) {
          auto response = Response{};
          EXPECT_TRUE(TextFormat::ParseFromString(kResponse1, &response));
          return std::make_optional(response);
        });
      })
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });

  Options options;
  options.set<storage::EnableMultiStreamOptimizationOption>(true);
  options.set<ReadRangesOption>({{0, 10}});
  // Evict if buffer exceeds 5 bytes.
  options.set<PreWarmBufferLimitOption>(5);

  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options);

  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponse0, &response));
  tested->Start(std::move(response));

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");
  read1.first.set_value(true);

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Read[2]");

  // Pre-warmed range should be evicted. Fallback RPC will be requested.
  auto s1 = tested->Read({0, 10});
  ASSERT_THAT(s1, NotNull());

  auto write_next = sequencer.PopFrontWithName();
  EXPECT_EQ(write_next.second, "Write[1]");
  write_next.first.set_value(true);

  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);
}

TEST(ObjectDescriptorImpl, DuplicateInitialRangesDeduplication) {
  auto constexpr kResponse0 = R"pb(
    metadata {
      bucket: "projects/_/buckets/test-bucket"
      name: "test-object"
      generation: 42
    }
    read_handle { handle: "handle-12345" }
  )pb";

  AsyncSequencer<bool> sequencer;
  auto stream = std::make_unique<MockStream>();

  // We expect no extra Write calls since duplicates are deduplicated.
  EXPECT_CALL(*stream, Write).Times(0);

  EXPECT_CALL(*stream, Read).WillOnce([&sequencer]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  EXPECT_CALL(*stream, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish").then(
        [](auto) { return PermanentError(); });
  });

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillOnce([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });
  Options options;
  options.set<storage::EnableMultiStreamOptimizationOption>(true);
  options.set<ReadRangesOption>({{0, 1024}, {0, 1024}});

  auto tested = std::make_shared<ObjectDescriptorImpl>(
      NoResume(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream)), options);

  auto response = Response{};
  EXPECT_TRUE(TextFormat::ParseFromString(kResponse0, &response));
  tested->Start(std::move(response));

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Read[1]");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish");
  next.first.set_value(true);
}

/// @test Verify that when a stream fails and triggers resumption, concurrent
/// Read() requests queued while reconnecting are not dropped and are flushed to
/// the newly connected stream.
TEST(ObjectDescriptorImpl, ResumeRacesWithConcurrentRead) {
  AsyncSequencer<bool> sequencer;
  auto stream1 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream1, Read).WillRepeatedly([&sequencer]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  EXPECT_CALL(*stream1, Write)
      .WillRepeatedly([&sequencer](Request const&, grpc::WriteOptions) {
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream1, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish[1]").then([](auto f) {
      if (f.get()) return TransientError();
      return PermanentError();
    });
  });

  auto stream2 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream2, Read)
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      })
      .WillRepeatedly(
          []() { return make_ready_future(std::optional<Response>{}); });
  EXPECT_CALL(*stream2, Write)
      .WillRepeatedly([&sequencer](Request const&, grpc::WriteOptions) {
        return sequencer.PushBack("Write[2]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream2, Finish).WillRepeatedly([]() {
    return make_ready_future(Status{});
  });

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillRepeatedly([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(TransientError()));
  });
  EXPECT_CALL(
      factory,
      Call(ResultOf([](Request const& r) { return !r.read_ranges().empty(); },
                    true)))
      .WillOnce([&stream2](Request const&) {
        auto response = Response{};
        return make_ready_future(make_status_or(
            OpenStreamResult{std::make_shared<OpenStream>(std::move(stream2)),
                             std::move(response)}));
      });

  auto tested = MakeTested(storage::LimitedErrorCountResumePolicy(3)(),
                           factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream1)));

  tested->Start(Response{});

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({1000, 100});
  ASSERT_THAT(s1, NotNull());
  auto write1 = sequencer.PopFrontWithName();
  EXPECT_EQ(write1.second, "Write[1]");
  write1.first.set_value(true);

  // Trigger stream 1 failure and Resume
  read1.first.set_value(false);

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish[1]");
  next.first.set_value(true);

  // Concurrently issue Read for range 2 while Resume is connecting stream 2
  auto s2 = tested->Read({2000, 100});
  ASSERT_THAT(s2, NotNull());

  // Stream 2 should be read and receive the flushed Write[2] with range 2
  auto read2 = sequencer.PopFrontWithName();
  EXPECT_EQ(read2.second, "Read[2]");

  auto write2 = sequencer.PopFrontWithName();
  EXPECT_EQ(write2.second, "Write[2]");
  write2.first.set_value(true);

  tested.reset();
  read2.first.set_value(false);
}

/// @test Verify that callbacks from discarded/stale stream instances are
/// ignored and do not affect the newly active stream.
TEST(ObjectDescriptorImpl, IgnoresCallbacksFromStaleStreams) {
  AsyncSequencer<bool> sequencer;
  auto stream1 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream1, Read).WillRepeatedly([&sequencer]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  EXPECT_CALL(*stream1, Write)
      .WillRepeatedly([&sequencer](Request const&, grpc::WriteOptions) {
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream1, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish[1]").then([](auto f) {
      if (f.get()) return TransientError();
      return PermanentError();
    });
  });

  auto stream2 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream2, Read)
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      })
      .WillRepeatedly(
          []() { return make_ready_future(std::optional<Response>{}); });
  EXPECT_CALL(*stream2, Write)
      .WillRepeatedly([&sequencer](Request const&, grpc::WriteOptions) {
        return sequencer.PushBack("Write[2]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream2, Finish).WillRepeatedly([]() {
    return make_ready_future(Status{});
  });

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillRepeatedly([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(TransientError()));
  });
  EXPECT_CALL(
      factory,
      Call(ResultOf([](Request const& r) { return !r.read_ranges().empty(); },
                    true)))
      .WillOnce([&stream2](Request const&) {
        auto response = Response{};
        return make_ready_future(make_status_or(
            OpenStreamResult{std::make_shared<OpenStream>(std::move(stream2)),
                             std::move(response)}));
      });

  auto tested = MakeTested(storage::LimitedErrorCountResumePolicy(3)(),
                           factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream1)));

  tested->Start(Response{});

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({1000, 100});
  ASSERT_THAT(s1, NotNull());
  auto write1 = sequencer.PopFrontWithName();
  EXPECT_EQ(write1.second, "Write[1]");

  // Stream 1 fails on read and resumes stream 2
  read1.first.set_value(false);

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish[1]");
  next.first.set_value(true);

  // Stream 2 is now active
  auto read2 = sequencer.PopFrontWithName();
  EXPECT_EQ(read2.second, "Read[2]");

  // A stale Write[1] callback from stream 1 arrives late with false (error).
  // It should NOT call Finish[2] on stream 2!
  write1.first.set_value(false);

  EXPECT_TRUE(sequencer.empty());

  tested.reset();
  read2.first.set_value(false);
}

/// @test Verify that when a stream is cancelled due to a stall watchdog timeout
/// (StatusCode::kCancelled), it is treated as resumable by the resume policy
/// and automatically resumed.
TEST(ObjectDescriptorImpl, ResumeOnStallTimeout) {
  AsyncSequencer<bool> sequencer;
  auto stream1 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream1, Read).WillRepeatedly([&sequencer]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  EXPECT_CALL(*stream1, Write)
      .WillRepeatedly([&sequencer](Request const&, grpc::WriteOptions) {
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream1, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish[1]").then([](auto f) {
      if (f.get()) return Status(StatusCode::kCancelled, "Stream stalled");
      return PermanentError();
    });
  });

  auto stream2 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream2, Read)
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      })
      .WillRepeatedly(
          []() { return make_ready_future(std::optional<Response>{}); });
  EXPECT_CALL(*stream2, Write)
      .WillRepeatedly([&sequencer](Request const&, grpc::WriteOptions) {
        return sequencer.PushBack("Write[2]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream2, Finish).WillRepeatedly([]() {
    return make_ready_future(Status{});
  });

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillRepeatedly([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(TransientError()));
  });
  EXPECT_CALL(
      factory,
      Call(ResultOf([](Request const& r) { return !r.read_ranges().empty(); },
                    true)))
      .WillOnce([&stream2](Request const&) {
        auto response = Response{};
        return make_ready_future(make_status_or(
            OpenStreamResult{std::make_shared<OpenStream>(std::move(stream2)),
                             std::move(response)}));
      });

  auto tested = MakeTested(storage::LimitedErrorCountResumePolicy(3)(),
                           factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream1)));

  tested->Start(Response{});

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({1000, 100});
  ASSERT_THAT(s1, NotNull());
  auto write1 = sequencer.PopFrontWithName();
  EXPECT_EQ(write1.second, "Write[1]");
  write1.first.set_value(true);

  // Watchdog cancels stream 1 on read stall
  read1.first.set_value(false);

  auto next = sequencer.PopFrontWithName();
  EXPECT_EQ(next.second, "Finish[1]");
  next.first.set_value(true);

  // If resumed, stream 2 is connected and Read[2] is invoked
  auto read2 = sequencer.PopFrontWithName();
  EXPECT_EQ(read2.second, "Read[2]");

  tested.reset();
  read2.first.set_value(false);
}

/// @test Verify that when a stream starts successfully, the resume policy is
/// notified via OnStartSuccess().
TEST(ObjectDescriptorImpl, NotifiesResumePolicyOnStartSuccess) {
  auto mock_policy = std::make_unique<MockResumePolicy>();
  EXPECT_CALL(*mock_policy, clone).WillOnce([]() {
    auto p = std::make_unique<MockResumePolicy>();
    EXPECT_CALL(*p, OnStartSuccess).Times(::testing::AtLeast(1));
    return p;
  });

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillRepeatedly([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(TransientError()));
  });
  auto stream = std::make_unique<MockStream>();
  EXPECT_CALL(*stream, Read).WillRepeatedly([]() {
    return make_ready_future(std::optional<Response>{});
  });
  EXPECT_CALL(*stream, Write)
      .WillRepeatedly([](Request const&, grpc::WriteOptions) {
        return make_ready_future(true);
      });
  EXPECT_CALL(*stream, Finish).WillRepeatedly([]() {
    return make_ready_future(Status{});
  });

  auto tested = MakeTested(std::move(mock_policy), factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream)));

  tested->Start(Response{});
}

/// @test Verify that when the user explicitly cancels ObjectDescriptorImpl,
/// streams are cancelled and no resume attempts are made.
TEST(ObjectDescriptorImpl, UserCancelStopsStreamWithoutResume) {
  AsyncSequencer<bool> sequencer;
  auto stream1 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream1, Cancel).Times(::testing::AtLeast(1));
  EXPECT_CALL(*stream1, Write)
      .Times(AtMost(1))
      .WillRepeatedly([](Request const&, grpc::WriteOptions) {
        return make_ready_future(true);
      });
  EXPECT_CALL(*stream1, Read).WillOnce([&sequencer]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  EXPECT_CALL(*stream1, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish[1]").then([](auto) {
      return Status(StatusCode::kCancelled, "Cancelled by user");
    });
  });

  MockFactory factory;
  // Factory should NEVER be called on user cancellation.
  EXPECT_CALL(factory, Call).Times(0);

  Options options;
  options.set<storage::EnableMultiStreamOptimizationOption>(false);
  auto tested = std::make_shared<ObjectDescriptorImpl>(
      storage::LimitedErrorCountResumePolicy(2)(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream1)), options);

  Response start_resp;
  tested->Start(std::move(start_resp));

  auto r1 = tested->Read({100, 50});
  ASSERT_THAT(r1, NotNull());

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  // User explicitly cancels.
  tested->Cancel();
  EXPECT_FALSE(tested->IsOpen());

  read1.first.set_value(true);

  auto finish1 = sequencer.PopFrontWithName();
  EXPECT_EQ(finish1.second, "Finish[1]");
  finish1.first.set_value(true);

  // No resume factory calls happen.
  EXPECT_TRUE(sequencer.empty());
  EXPECT_FALSE(tested->IsOpen());
}

/// @test Verify that range requests arriving during multiple consecutive
/// transient reconnection retries are preserved across all attempts and
/// flushed to the new stream once reconnected.
TEST(ObjectDescriptorImpl, ConcurrentReadPreservedAcrossMultipleResumeRetries) {
  AsyncSequencer<bool> sequencer;
  auto stream1 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream1, Read).WillRepeatedly([&sequencer]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  EXPECT_CALL(*stream1, Write)
      .WillRepeatedly([&sequencer](Request const&, grpc::WriteOptions) {
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream1, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish[1]").then([](auto f) {
      if (f.get()) return TransientError();
      return PermanentError();
    });
  });

  auto stream2 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream2, Read)
      .WillOnce([&sequencer]() {
        return sequencer.PushBack("Read[2]").then(
            [](auto) { return std::optional<Response>{}; });
      })
      .WillRepeatedly(
          []() { return make_ready_future(std::optional<Response>{}); });
  EXPECT_CALL(*stream2, Write)
      .WillRepeatedly([&sequencer](Request const&, grpc::WriteOptions) {
        return sequencer.PushBack("Write[2]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream2, Finish).WillRepeatedly([]() {
    return make_ready_future(Status{});
  });

  MockFactory factory;
  int retry_count = 0;
  EXPECT_CALL(factory, Call).WillRepeatedly([&](Request const& r) {
    ++retry_count;
    if (retry_count == 1) {
      return sequencer.PushBack("Factory[1]").then([](auto f) {
        if (f.get()) {
          return StatusOr<OpenStreamResult>(TransientError());
        }
        return StatusOr<OpenStreamResult>(PermanentError());
      });
    }
    // Second attempt must contain both range 1 and range 2
    EXPECT_EQ(r.read_ranges_size(), 2);
    return sequencer.PushBack("Factory[2]").then([&stream2](auto f) {
      if (f.get()) {
        auto response = Response{};
        return make_status_or(
            OpenStreamResult{std::make_shared<OpenStream>(std::move(stream2)),
                             std::move(response)});
      }
      return StatusOr<OpenStreamResult>(PermanentError());
    });
  });

  auto tested = std::make_shared<ObjectDescriptorImpl>(
      storage::LimitedErrorCountResumePolicy(3)(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream1)),
      Options{}.set<storage::EnableMultiStreamOptimizationOption>(false));

  tested->Start(Response{});

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_EQ(read1.second, "Read[1]");

  auto s1 = tested->Read({1000, 100});
  ASSERT_THAT(s1, NotNull());
  auto write1 = sequencer.PopFrontWithName();
  EXPECT_EQ(write1.second, "Write[1]");
  write1.first.set_value(true);

  // Trigger stream 1 failure
  read1.first.set_value(false);

  auto finish1 = sequencer.PopFrontWithName();
  EXPECT_EQ(finish1.second, "Finish[1]");
  finish1.first.set_value(true);

  // Factory attempt 1 is invoked
  auto factory1 = sequencer.PopFrontWithName();
  EXPECT_EQ(factory1.second, "Factory[1]");

  // While reconnection attempt 1 is in-flight, add range 2 concurrently
  auto s2 = tested->Read({2000, 100});
  ASSERT_THAT(s2, NotNull());

  // Factory attempt 1 fails with TransientError
  factory1.first.set_value(true);

  // Factory attempt 2 is invoked with both range 1 and range 2
  auto factory2 = sequencer.PopFrontWithName();
  EXPECT_EQ(factory2.second, "Factory[2]");

  // While factory attempt 2 is in-flight, add range 3 concurrently
  auto s3 = tested->Read({3000, 100});
  ASSERT_THAT(s3, NotNull());

  // Factory attempt 2 succeeds with stream2
  factory2.first.set_value(true);

  // Range 3 (queued during factory attempt 2) is flushed to stream 2 first
  auto write2 = sequencer.PopFrontWithName();
  EXPECT_EQ(write2.second, "Write[2]");
  write2.first.set_value(true);

  // Stream 2 is read
  auto read2 = sequencer.PopFrontWithName();
  EXPECT_EQ(read2.second, "Read[2]");

  EXPECT_EQ(retry_count, 2);

  tested->Cancel();
  read2.first.set_value(false);
}

/// @test Verify that a stream waiting for a reconnection is not offered as an
/// "idle" stream, and that new reads are not parked on it.
TEST(ObjectDescriptorImpl, ResumingStreamIsNotReusedAsIdleStream) {
  AsyncSequencer<bool> sequencer;
  AsyncSequencer<bool> factory_sequencer;
  auto stream1 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream1, Read).WillOnce([&sequencer]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  EXPECT_CALL(*stream1, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish[1]").then([](auto) {
      return TransientError();
    });
  });
  EXPECT_CALL(*stream1, Cancel).Times(AtMost(1));

  auto stream2 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream2, Read).WillRepeatedly([&sequencer]() {
    return sequencer.PushBack("Read[2]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  // The read issued while stream 1 is reconnecting must be written to the
  // healthy stream.
  EXPECT_CALL(*stream2, Write)
      .WillOnce([&sequencer](Request const&, grpc::WriteOptions) {
        return sequencer.PushBack("Write[2]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream2, Finish).Times(AtMost(1)).WillRepeatedly([&sequencer]() {
    return sequencer.PushBack("Finish[2]").then([](auto) { return Status{}; });
  });
  EXPECT_CALL(*stream2, Cancel).Times(AtMost(1));

  // The first factory call is the proactive background stream queued by
  // `Start()`; it produces stream 2. Any later call (including the
  // reconnection attempt for stream 1) fails, and the reconnection is left
  // in flight for most of the test.
  int factory_calls = 0;
  MockFactory factory;
  EXPECT_CALL(factory, Call).WillRepeatedly([&](Request const&) {
    int const call = ++factory_calls;
    char const* name = call == 1 ? "Factory[background]" : "Factory[resume]";
    return factory_sequencer.PushBack(name).then(
        [&stream2, call](auto f) -> StatusOr<OpenStreamResult> {
          if (call != 1 || !f.get()) return TransientError();
          return make_status_or(OpenStreamResult{
              std::make_shared<OpenStream>(std::move(stream2)), Response{}});
        });
  });

  auto tested = MakeTested(storage::LimitedErrorCountResumePolicy(3)(),
                           factory.AsStdFunction(),
                           google::storage::v2::BidiReadObjectSpec{},
                           std::make_shared<OpenStream>(std::move(stream1)));

  tested->Start(Response{});

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_THAT(read1.second, Eq("Read[1]"));
  auto background = factory_sequencer.PopFrontWithName();
  EXPECT_THAT(background.second, Eq("Factory[background]"));

  // Stream 1 fails while it has no active ranges, e.g. the stall watchdog
  // cancelled an idle stream. The descriptor starts a reconnection which does
  // not complete yet, leaving the entry in the `resuming` state.
  read1.first.set_value(false);
  auto finish1 = sequencer.PopFrontWithName();
  EXPECT_THAT(finish1.second, Eq("Finish[1]"));
  finish1.first.set_value(true);
  auto reconnect = factory_sequencer.PopFrontWithName();
  EXPECT_THAT(reconnect.second, Eq("Factory[resume]"));

  // The application asks for an additional stream. The only entry is waiting
  // to reconnect, so the descriptor must consume the background stream
  // instead of reporting that it reused an idle one.
  tested->MakeSubsequentStream();
  background.first.set_value(true);
  EXPECT_THAT(tested->StreamSize(), Eq(std::size_t{2}));

  // The new read must go to the healthy stream. If it is queued on the
  // reconnecting stream `Flush()` is skipped and nothing reaches the wire.
  std::unique_ptr<storage::AsyncReaderConnection> reader =
      tested->Read({0, 100});
  EXPECT_THAT(reader, NotNull());
  EXPECT_THAT(sequencer.empty(), IsFalse());

  tested.reset();
  reconnect.first.set_value(false);
  while (!sequencer.empty()) sequencer.PopFront().set_value(false);
  while (!factory_sequencer.empty()) {
    factory_sequencer.PopFront().set_value(false);
  }
}

/// @test Verify the resume policy is told the actual status of the stream.
TEST(ObjectDescriptorImpl, ResumePolicyObservesCancelledStatus) {
  AsyncSequencer<bool> sequencer;
  std::optional<Status> policy_status;
  auto prototype = std::make_unique<MockResumePolicy>();
  EXPECT_CALL(*prototype, clone).WillRepeatedly([&policy_status]() {
    auto policy = std::make_unique<MockResumePolicy>();
    EXPECT_CALL(*policy, OnStartSuccess).Times(AnyNumber());
    EXPECT_CALL(*policy, OnFinish)
        .WillRepeatedly([&policy_status](Status const& status) {
          policy_status = status;
          return storage::ResumePolicy::kStop;
        });
    return policy;
  });

  auto stream1 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream1, Read).WillOnce([&sequencer]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  EXPECT_CALL(*stream1, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish[1]").then([](auto) {
      return Status(StatusCode::kCancelled, "Stream stalled");
    });
  });
  EXPECT_CALL(*stream1, Cancel).Times(AtMost(1));

  MockFactory factory;
  EXPECT_CALL(factory, Call).WillRepeatedly([](Request const&) {
    return make_ready_future(StatusOr<OpenStreamResult>(PermanentError()));
  });

  Options options;
  options.set<storage::EnableMultiStreamOptimizationOption>(false);
  auto tested = std::make_shared<ObjectDescriptorImpl>(
      std::move(prototype), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream1)), options);

  tested->Start(Response{});

  auto read1 = sequencer.PopFrontWithName();
  EXPECT_THAT(read1.second, Eq("Read[1]"));
  read1.first.set_value(false);

  auto finish1 = sequencer.PopFrontWithName();
  EXPECT_THAT(finish1.second, Eq("Finish[1]"));
  finish1.first.set_value(true);

  EXPECT_THAT(policy_status.has_value(), IsTrue());
  if (policy_status.has_value()) {
    EXPECT_THAT(*policy_status,
                StatusIs(StatusCode::kCancelled, "Stream stalled"));
  }

  tested.reset();
  while (!sequencer.empty()) sequencer.PopFront().set_value(false);
}

/// @test Verify the resume budget is consumed across successful reconnects.
TEST(ObjectDescriptorImpl, ResumeBudgetIsNotResetByASuccessfulReconnect) {
  AsyncSequencer<bool> sequencer;
  auto stream1 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream1, Read).WillOnce([&sequencer]() {
    return sequencer.PushBack("Read[1]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  EXPECT_CALL(*stream1, Write)
      .WillOnce([&sequencer](Request const&, grpc::WriteOptions) {
        return sequencer.PushBack("Write[1]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream1, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish[1]").then([](auto) {
      return TransientError();
    });
  });
  EXPECT_CALL(*stream1, Cancel).Times(AtMost(1));

  auto stream2 = std::make_unique<MockStream>();
  EXPECT_CALL(*stream2, Read).WillOnce([&sequencer]() {
    return sequencer.PushBack("Read[2]").then(
        [](auto) { return std::optional<Response>{}; });
  });
  EXPECT_CALL(*stream2, Write)
      .Times(AtMost(1))
      .WillRepeatedly([&sequencer](Request const&, grpc::WriteOptions) {
        return sequencer.PushBack("Write[2]").then([](auto f) {
          return f.get();
        });
      });
  EXPECT_CALL(*stream2, Finish).WillOnce([&sequencer]() {
    return sequencer.PushBack("Finish[2]").then([](auto) {
      return TransientError();
    });
  });
  EXPECT_CALL(*stream2, Cancel).Times(AtMost(1));

  // Reconnection attempts carry the ranges to resume; the proactive background
  // streams do not. Only the former are counted.
  int resume_attempts = 0;
  MockFactory factory;
  EXPECT_CALL(factory, Call)
      .WillRepeatedly(
          [&](Request const& request) -> future<StatusOr<OpenStreamResult>> {
            if (request.read_ranges().empty()) {
              return make_ready_future(
                  StatusOr<OpenStreamResult>(TransientError()));
            }
            if (++resume_attempts != 1) {
              return make_ready_future(
                  StatusOr<OpenStreamResult>(TransientError()));
            }
            return make_ready_future(make_status_or(OpenStreamResult{
                std::make_shared<OpenStream>(std::move(stream2)), Response{}}));
          });

  Options options;
  options.set<storage::EnableMultiStreamOptimizationOption>(false);
  // A budget of exactly one resume for the lifetime of this descriptor.
  auto tested = std::make_shared<ObjectDescriptorImpl>(
      storage::LimitedErrorCountResumePolicy(1)(), factory.AsStdFunction(),
      google::storage::v2::BidiReadObjectSpec{},
      std::make_shared<OpenStream>(std::move(stream1)), options);

  tested->Start(Response{});

  // `Start()` leaves a read outstanding on stream 1.
  auto read1 = sequencer.PopFrontWithName();
  EXPECT_THAT(read1.second, Eq("Read[1]"));

  std::unique_ptr<storage::AsyncReaderConnection> reader =
      tested->Read({0, 100});
  EXPECT_THAT(reader, NotNull());
  auto write1 = sequencer.PopFrontWithName();
  EXPECT_THAT(write1.second, Eq("Write[1]"));
  write1.first.set_value(true);

  // First failure: consumes the single resume allowed by the policy.
  read1.first.set_value(false);
  auto finish1 = sequencer.PopFrontWithName();
  EXPECT_THAT(finish1.second, Eq("Finish[1]"));
  finish1.first.set_value(true);
  EXPECT_THAT(resume_attempts, Eq(1));

  // Second failure, on the replacement stream. The budget is exhausted, so the
  // descriptor must give up instead of reconnecting again.
  auto read2 = sequencer.PopFrontWithName();
  EXPECT_THAT(read2.second, Eq("Read[2]"));
  read2.first.set_value(false);

  auto finish2 = sequencer.PopFrontWithName();
  EXPECT_THAT(finish2.second, Eq("Finish[2]"));
  finish2.first.set_value(true);

  EXPECT_THAT(resume_attempts, Eq(1));
  EXPECT_THAT(tested->IsOpen(), IsFalse());

  tested.reset();
  while (!sequencer.empty()) sequencer.PopFront().set_value(false);
}

}  // namespace
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_END
}  // namespace storage_internal
}  // namespace cloud
}  // namespace google
#include "google/cloud/internal/diagnostics_pop.inc"
