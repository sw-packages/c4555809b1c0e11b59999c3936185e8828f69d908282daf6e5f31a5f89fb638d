// Copyright 2023 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "google/cloud/internal/disable_deprecation_warnings.inc"
#include "google/cloud/storage/internal/async/writer_connection_impl.h"
#include "google/cloud/storage/async/options.h"
#include "google/cloud/storage/hashing_options.h"
#include "google/cloud/storage/internal/async/handle_redirect_error.h"
#include "google/cloud/storage/internal/async/partial_upload.h"
#include "google/cloud/storage/internal/async/write_payload_impl.h"
#include "google/cloud/storage/internal/grpc/ctype_cord_workaround.h"
#include "google/cloud/storage/internal/grpc/object_metadata_parser.h"
#include "google/cloud/storage/internal/grpc/object_request_parser.h"
#include "google/cloud/internal/make_status.h"
#include <variant>

namespace google {
namespace cloud {
namespace storage_internal {
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_BEGIN
namespace {

auto HandleFinishAfterError(std::string msg) {
  return [m = std::move(msg)](future<Status> f) {
    auto status = f.get();
    if (!status.ok()) return status;
    // A `Write()` or `Read()` operation unexpectedly returned `ok == false`.
    // The `Finish()` call should return the detailed error, but returned
    // "success". This is some kind of internal error in the client library,
    // gRPC, or the service.
    return internal::InternalError(std::move(m), GCP_ERROR_INFO());
  };
}

auto HandleFinishAfterError(Status s) {
  return [s = std::move(s)](future<Status>) mutable { return std::move(s); };
}

}  // namespace

AsyncWriterConnectionImpl::AsyncWriterConnectionImpl(
    google::cloud::internal::ImmutableOptions options,
    google::storage::v2::BidiWriteObjectRequest request,
    std::unique_ptr<StreamingRpc> impl,
    std::shared_ptr<storage::internal::HashFunction> hash_function,
    std::int64_t persisted_size, bool first_request)
    : AsyncWriterConnectionImpl(
          std::move(options), std::move(request), std::move(impl),
          std::move(hash_function), PersistedStateType(persisted_size),
          /*offset=*/persisted_size, std::move(first_request)) {}

AsyncWriterConnectionImpl::AsyncWriterConnectionImpl(
    google::cloud::internal::ImmutableOptions options,
    google::storage::v2::BidiWriteObjectRequest request,
    std::unique_ptr<StreamingRpc> impl,
    std::shared_ptr<storage::internal::HashFunction> hash_function,
    google::storage::v2::Object metadata, bool first_request)
    : AsyncWriterConnectionImpl(
          std::move(options), std::move(request), std::move(impl),
          std::move(hash_function), PersistedStateType(metadata),
          /*offset=*/metadata.size(), std::move(first_request)) {}

AsyncWriterConnectionImpl::AsyncWriterConnectionImpl(
    google::cloud::internal::ImmutableOptions options,
    google::storage::v2::BidiWriteObjectRequest request,
    std::unique_ptr<StreamingRpc> impl,
    std::shared_ptr<storage::internal::HashFunction> hash_function,
    PersistedStateType persisted_state, std::int64_t offset, bool first_request)
    : options_(std::move(options)),
      impl_(std::move(impl)),
      request_(std::move(request)),
      hash_function_(std::move(hash_function)),
      persisted_state_(std::move(persisted_state)),
      offset_(offset),
      first_request_(std::move(first_request)),
      finished_(on_finish_.get_future()) {
  request_.clear_object_checksums();
  request_.set_state_lookup(false);
  request_.set_flush(false);
  request_.set_finish_write(false);
}

AsyncWriterConnectionImpl::~AsyncWriterConnectionImpl() {
  // Cancel the streaming RPC.
  impl_->Cancel();
  // It is safe to call Finish() because:
  // (1) this is a no-op if it was already called.
  // (2) calls to `Write()`, `Finalize()`, and `Query()` must have completed
  //     by the time the destructor is called
  Finish();

  // We use a local copy of `impl` moved under lock to avoid
  // data races with concurrent calls to `Finish()` from callbacks.
  std::unique_lock<std::mutex> lk(mu_);
  auto impl = std::move(impl_);
  lk.unlock();

  // When `impl_->Finish()` is satisfied then `finished_` is satisfied too.
  // This extends the lifetime of `impl_` until it is safe to delete.
  finished_.then([impl = std::move(impl)](auto) mutable {
    // Break the ownership cycle between the completion queue and this callback.
    impl.reset();
  });
}

std::string AsyncWriterConnectionImpl::UploadId() const {
  return request_.upload_id();
}

std::variant<std::int64_t, google::storage::v2::Object>
AsyncWriterConnectionImpl::PersistedState() const {
  std::unique_lock<std::mutex> lk(mu_);
  return persisted_state_;
}

future<Status> AsyncWriterConnectionImpl::Write(storage::WritePayload payload) {
  auto write = MakeRequest();
  auto p = WritePayloadImpl::GetImpl(payload);
  auto size = p.size();
  auto coro = PartialUpload::Call(impl_, hash_function_, std::move(write),
                                  std::move(p), PartialUpload::kNone);

  return coro->Start().then([coro, size, this](auto f) mutable {
    coro.reset();  // breaks the cycle between the completion queue and coro
    return OnPartialUpload(size, f.get());
  });
}

future<StatusOr<google::storage::v2::Object>>
AsyncWriterConnectionImpl::Finalize(storage::WritePayload payload) {
  auto write = MakeRequest();
  write.set_finish_write(true);

  auto p = WritePayloadImpl::GetImpl(payload);
  auto size = p.size();
  auto is_append = request_.has_append_object_spec() ||
                   request_.write_object_spec().appendable();
  auto const& current_options = google::cloud::internal::CurrentOptions();
  auto merged = google::cloud::internal::MergeOptions(
      current_options, options_ ? *options_ : google::cloud::Options{});

  // Default to letting the internal hash function compute and send the
  // checksum.
  auto action = PartialUpload::kFinalizeWithChecksum;

  if (is_append) {
    // For appendable uploads, the internal hash function only sees the chunks
    // uploaded in this stream, not the full object. We use `kFinalize` to avoid
    // sending this partial hash, which would otherwise fail validation.
    if (merged.has<google::cloud::storage::UseCrc32cValueOption>()) {
      write.mutable_object_checksums()->set_crc32c(
          merged.get<google::cloud::storage::UseCrc32cValueOption>());
    }
    action = PartialUpload::kFinalize;
  } else if (current_options
                 .has<google::cloud::storage::UseCrc32cValueOption>() ||
             current_options.has<google::cloud::storage::UseMD5ValueOption>()) {
    // If the user specified a manual expected checksum dynamically at
    // Finalize() via current_options, we manually inject it and use `kFinalize`
    // so the internal hash function doesn't overwrite it with its own computed
    // hash.
    if (current_options.has<google::cloud::storage::UseCrc32cValueOption>()) {
      write.mutable_object_checksums()->set_crc32c(
          current_options.get<google::cloud::storage::UseCrc32cValueOption>());
    }
    if (current_options.has<google::cloud::storage::UseMD5ValueOption>()) {
      write.mutable_object_checksums()->set_md5_hash(
          current_options.get<google::cloud::storage::UseMD5ValueOption>());
    }
    action = PartialUpload::kFinalize;
  }

  auto coro = PartialUpload::Call(impl_, hash_function_, std::move(write),
                                  std::move(p), std::move(action));
  return coro->Start().then([coro, size, this](auto f) mutable {
    coro.reset();  // breaks the cycle between the completion queue and coro
    return OnFinalUpload(size, f.get());
  });
}

future<Status> AsyncWriterConnectionImpl::Flush(storage::WritePayload payload) {
  auto write = MakeRequest();
  auto p = WritePayloadImpl::GetImpl(payload);
  auto size = p.size();
  auto coro = PartialUpload::Call(impl_, hash_function_, std::move(write),
                                  std::move(p), PartialUpload::kFlush);

  return coro->Start().then([coro, size, this](auto f) mutable {
    coro.reset();  // breaks the cycle between the completion queue and coro
    return OnFlush(size, f.get());
  });
}

future<Status> AsyncWriterConnectionImpl::Close(storage::WritePayload payload) {
  auto write = MakeRequest();
  auto p = WritePayloadImpl::GetImpl(payload);
  auto size = p.size();
  auto coro = PartialUpload::Call(impl_, hash_function_, std::move(write),
                                  std::move(p), PartialUpload::kFlushAndClose);

  return coro->Start().then([coro, size, this](auto f) mutable {
    coro.reset();  // breaks the cycle between the completion queue and coro
    return OnClose(size, f.get());
  });
}

future<StatusOr<std::int64_t>> AsyncWriterConnectionImpl::Query() {
  std::unique_lock<std::mutex> lk(mu_);
  if (auto* size = std::get_if<std::int64_t>(&persisted_state_)) {
    return make_ready_future(make_status_or(*size));
  }
  if (auto* meta =
          std::get_if<google::storage::v2::Object>(&persisted_state_)) {
    return make_ready_future(
        make_status_or(static_cast<std::int64_t>(meta->size())));
  }
  return make_ready_future(make_status_or(static_cast<std::int64_t>(0)));
}

RpcMetadata AsyncWriterConnectionImpl::GetRequestMetadata() {
  return impl_->GetRequestMetadata();
}

google::storage::v2::BidiWriteObjectRequest
AsyncWriterConnectionImpl::MakeRequest() {
  auto request = request_;
  if (first_request_) {
    first_request_ = false;
    if (latest_write_handle_.has_value() && request.has_append_object_spec()) {
      *request.mutable_append_object_spec()->mutable_write_handle() =
          *latest_write_handle_;
    }
  } else {
    request.clear_upload_id();
    request.clear_write_object_spec();
    request.clear_append_object_spec();
  }
  request.set_write_offset(offset_);
  return request;
}

future<Status> AsyncWriterConnectionImpl::OnPartialUpload(
    std::size_t upload_size, StatusOr<bool> success) {
  if (!success) {
    return Finish().then(HandleFinishAfterError(std::move(success).status()));
  }
  if (!*success) {
    return Finish().then(
        HandleFinishAfterError("Expected Finish() error after non-ok Write()"));
  }
  std::unique_lock<std::mutex> lk(mu_);
  offset_ += upload_size;
  lk.unlock();
  return make_ready_future(Status{});
}

future<Status> AsyncWriterConnectionImpl::OnFlush(std::size_t upload_size,
                                                  StatusOr<bool> success) {
  if (!success) {
    return Finish().then(HandleFinishAfterError(std::move(success).status()));
  }
  if (!*success) {
    return Finish().then(
        HandleFinishAfterError("Expected Finish() error after non-ok Write()"));
  }
  std::unique_lock<std::mutex> lk(mu_);
  offset_ += upload_size;
  auto expected_offset = offset_;
  auto impl = impl_;
  lk.unlock();

  struct ConsumeLoop {
    AsyncWriterConnectionImpl* self;
    std::shared_ptr<StreamingRpc> impl;
    std::int64_t expected_offset;

    future<Status> operator()(
        future<std::optional<google::storage::v2::BidiWriteObjectResponse>> f) {
      auto response = std::move(f).get();
      if (!response.has_value()) {
        return self->Finish().then(HandleFinishAfterError(
            "Expected error in Finish() after non-ok Read()"));
      }
      std::unique_lock<std::mutex> lk(self->mu_);
      if (response->has_write_handle()) {
        self->latest_write_handle_ = response->write_handle();
      }
      if (response->has_persisted_size()) {
        self->persisted_state_ = response->persisted_size();
        if (response->persisted_size() >= expected_offset) {
          return make_ready_future(Status{});
        }
      }
      if (response->has_resource()) {
        self->persisted_state_ = response->resource();
        return make_ready_future(Status{});
      }
      lk.unlock();
      return impl->Read().then(std::move(*this));
    }
  };
  return impl->Read().then(ConsumeLoop{this, impl, expected_offset});
}

future<Status> AsyncWriterConnectionImpl::OnClose(std::size_t upload_size,
                                                  StatusOr<bool> success) {
  if (!success) {
    return Finish().then(HandleFinishAfterError(std::move(success).status()));
  }
  if (!*success) {
    return Finish().then(
        HandleFinishAfterError("Expected Finish() error after non-ok Write()"));
  }
  std::unique_lock<std::mutex> lk(mu_);
  offset_ += upload_size;
  auto impl = impl_;
  lk.unlock();

  struct ConsumeLoop {
    std::shared_ptr<StreamingRpc> impl;

    future<void> operator()(
        future<std::optional<google::storage::v2::BidiWriteObjectResponse>> f) {
      auto response = std::move(f).get();
      if (!response.has_value()) return make_ready_future();
      return impl->Read().then(*this);
    }
  };

  return impl->Read().then(ConsumeLoop{impl}).then([this](auto f) {
    f.get();
    return Finish();
  });
}

future<StatusOr<google::storage::v2::Object>>
AsyncWriterConnectionImpl::OnFinalUpload(std::size_t upload_size,
                                         StatusOr<bool> success) {
  auto transform = [](future<Status> f) {
    return StatusOr<google::storage::v2::Object>(f.get());
  };
  if (!success) {
    return Finish()
        .then(HandleFinishAfterError(std::move(success).status()))
        .then(transform);
  }
  if (!*success) {
    return Finish()
        .then(HandleFinishAfterError(
            "Expected error in Finish() after non-ok Write()"))
        .then(transform);
  }
  std::unique_lock<std::mutex> lk(mu_);
  offset_ += upload_size;

  auto impl = impl_;
  lk.unlock();

  struct ConsumeLoop {
    AsyncWriterConnectionImpl* self;
    std::shared_ptr<StreamingRpc> impl;

    future<void> operator()(
        future<std::optional<google::storage::v2::BidiWriteObjectResponse>> f) {
      auto response = std::move(f).get();
      if (!response.has_value()) return make_ready_future();
      {
        std::unique_lock<std::mutex> lk(self->mu_);
        if (response->has_write_handle()) {
          self->latest_write_handle_ = response->write_handle();
        }
        if (response->has_persisted_size()) {
          self->persisted_state_ = response->persisted_size();
        }
        if (response->has_resource()) {
          self->persisted_state_ = response->resource();
        }
      }
      return impl->Read().then(std::move(*this));
    }
  };

  return impl->Read().then(ConsumeLoop{this, impl}).then([this](auto f) {
    std::move(f).get();
    return Finish().then(
        [this](auto f2) -> StatusOr<google::storage::v2::Object> {
          auto status = f2.get();
          if (!status.ok()) return status;
          if (!std::holds_alternative<google::storage::v2::Object>(
                  persisted_state_)) {
            return internal::InternalError(
                "no object metadata returned after finalizing upload",
                GCP_ERROR_INFO());
          }
          return std::get<google::storage::v2::Object>(persisted_state_);
        });
  });
}

future<Status> AsyncWriterConnectionImpl::Finish() {
  std::unique_lock<std::mutex> lk(mu_);
  if (std::exchange(finish_called_, true)) {
    return make_ready_future(
        internal::CancelledError("already finished", GCP_ERROR_INFO()));
  }
  auto impl = impl_;
  lk.unlock();

  return impl->Finish().then([p = std::move(on_finish_)](auto f) mutable {
    p.set_value();
    return f.get();
  });
}

GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_END
}  // namespace storage_internal
}  // namespace cloud
}  // namespace google
