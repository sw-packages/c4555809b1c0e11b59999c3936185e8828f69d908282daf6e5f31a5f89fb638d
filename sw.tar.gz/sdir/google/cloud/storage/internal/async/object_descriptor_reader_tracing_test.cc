// Copyright 2024 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "google/cloud/storage/internal/async/object_descriptor_reader_tracing.h"
#include "google/cloud/storage/testing/canonical_errors.h"
#include "google/cloud/opentelemetry_options.h"
#include "google/cloud/options.h"
#include "google/cloud/testing_util/opentelemetry_matchers.h"
#include <google/protobuf/text_format.h>
#include <gmock/gmock-matchers.h>
#include <gmock/gmock.h>
#include <opentelemetry/semconv/incubating/thread_attributes.h>

namespace google {
namespace cloud {
namespace storage_internal {
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_BEGIN
namespace {

using ::google::cloud::storage::testing::canonical_errors::PermanentError;
using ::google::cloud::testing_util::EventNamed;
using ::google::cloud::testing_util::InstallSpanCatcher;
using ::google::cloud::testing_util::OTelAttribute;
using ::google::cloud::testing_util::SpanEventAttributesAre;
using ::google::cloud::testing_util::SpanHasAttributes;
using ::google::cloud::testing_util::SpanHasEvents;
using ::google::cloud::testing_util::SpanNamed;
using ::google::cloud::testing_util::SpanWithParent;
using ::google::protobuf::TextFormat;
using ::testing::_;
using ::testing::AllOf;
using ::testing::ElementsAre;

namespace sc = ::opentelemetry::semconv;

TEST(ObjectDescriptorReaderTracing, Read) {
  auto span_catcher = InstallSpanCatcher();

  auto impl = std::make_shared<ReadRange>(10000, 30);
  auto reader = MakeTracingObjectDescriptorReader(impl, "TEST");

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data { content: "0123456789" }
    read_range { read_offset: 10000 read_length: 10 read_id: 7 }
    range_end: false
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));
  impl->OnRead(std::move(data), /*is_transcoded=*/false);

  auto actual = reader->Read().get();
  auto spans = span_catcher->GetSpans();
  EXPECT_THAT(spans,
              ElementsAre(AllOf(
                  SpanNamed("storage::AsyncConnection::ReadRange"),
                  SpanHasAttributes(OTelAttribute<std::string>(
                      "gl-cpp.initial-read-ranges.cache-status", "TEST")),
                  SpanHasEvents(AllOf(
                      EventNamed("gl-cpp.read-range"),
                      SpanEventAttributesAre(
                          OTelAttribute<std::uint32_t>("message.size", 10),
                          OTelAttribute<std::string>(sc::thread::kThreadId, _),
                          OTelAttribute<std::string>("rpc.message.type",
                                                     "RECEIVED")))))));
}

TEST(ObjectDescriptorReaderTracing, ReadError) {
  auto span_catcher = InstallSpanCatcher();
  auto impl = std::make_shared<ReadRange>(10000, 30);
  auto reader = MakeTracingObjectDescriptorReader(impl, "TEST");

  impl->OnFinish(PermanentError());

  auto actual = reader->Read().get();
  auto spans = span_catcher->GetSpans();
  EXPECT_THAT(
      spans,
      ElementsAre(AllOf(
          SpanNamed("storage::AsyncConnection::ReadRange"),
          SpanHasAttributes(
              OTelAttribute<std::string>("gl-cpp.status_code", "NOT_FOUND"),
              OTelAttribute<std::string>(
                  "gl-cpp.initial-read-ranges.cache-status", "TEST")),
          SpanHasEvents(
              AllOf(EventNamed("gl-cpp.read-range"),
                    SpanEventAttributesAre(
                        OTelAttribute<std::string>(sc::thread::kThreadId, _),
                        OTelAttribute<std::string>("rpc.message.type",
                                                   "RECEIVED")))))));
}

TEST(ObjectDescriptorReaderTracing, ReadWithoutInitialReadRanges) {
  auto span_catcher = InstallSpanCatcher();
  auto impl = std::make_shared<ReadRange>(10000, 30);
  // Pass empty string for cache_status when initial read ranges were not
  // configured.
  auto reader = MakeTracingObjectDescriptorReader(impl, "");

  impl->OnFinish(PermanentError());

  auto actual = reader->Read().get();
  auto spans = span_catcher->GetSpans();
  ASSERT_EQ(spans.size(), 1);
  auto const& attributes = spans[0]->GetAttributes();
  EXPECT_EQ(attributes.find("gl-cpp.initial-read-ranges.cache-status"),
            attributes.end());
}

TEST(ObjectDescriptorReaderTracing, ReadWithCacheStatuses) {
  for (auto const* status : {"HIT", "MISS", "EVICTED"}) {
    auto span_catcher = InstallSpanCatcher();
    auto impl = std::make_shared<ReadRange>(10000, 30);
    auto reader = MakeTracingObjectDescriptorReader(impl, status);

    impl->OnFinish(PermanentError());

    auto actual = reader->Read().get();
    auto spans = span_catcher->GetSpans();
    EXPECT_THAT(spans,
                ElementsAre(AllOf(
                    SpanNamed("storage::AsyncConnection::ReadRange"),
                    SpanHasAttributes(OTelAttribute<std::string>(
                        "gl-cpp.initial-read-ranges.cache-status", status)))));
  }
}

TEST(ObjectDescriptorReaderTracing, ReadWithParentSpan) {
  auto span_catcher = InstallSpanCatcher();

  auto parent_span = internal::MakeSpan("test-parent-span");
  auto impl = std::make_shared<ReadRange>(10000, 30);
  auto reader =
      MakeTracingObjectDescriptorReader(impl, /*cache_status=*/"", parent_span);

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data { content: "0123456789" }
    read_range { read_offset: 10000 read_length: 10 read_id: 7 }
    range_end: false
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));
  impl->OnRead(std::move(data), /*is_transcoded=*/false);

  auto actual = reader->Read().get();
  internal::EndSpan(*parent_span);

  auto spans = span_catcher->GetSpans();
  EXPECT_THAT(
      spans, ElementsAre(AllOf(SpanNamed("storage::AsyncConnection::ReadRange"),
                               SpanWithParent(parent_span)),
                         SpanNamed("test-parent-span")));
}

}  // namespace
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_END
}  // namespace storage_internal
}  // namespace cloud
}  // namespace google
