// Copyright 2024 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "google/cloud/storage/internal/async/read_range.h"
#include "google/cloud/storage/internal/grpc/ctype_cord_workaround.h"
#include "google/cloud/storage/internal/hash_function.h"
#include "google/cloud/storage/internal/hash_function_impl.h"
#include "google/cloud/storage/internal/hash_validator_impl.h"
#include "google/cloud/storage/internal/hash_values.h"
#include "google/cloud/storage/testing/canonical_errors.h"
#include "google/cloud/storage/testing/mock_hash_function.h"
#include "google/cloud/testing_util/is_proto_equal.h"
#include "google/cloud/testing_util/scoped_log.h"
#include "google/cloud/testing_util/status_matchers.h"
#include "absl/strings/cord.h"
#include "absl/strings/string_view.h"
#include <google/protobuf/text_format.h>
#include <gmock/gmock.h>
#include <gtest/gtest.h>
#include <memory>
#include <string>
#include <type_traits>

namespace google {
namespace cloud {
namespace storage_internal {
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_BEGIN
namespace {

using ::google::cloud::storage::ReadPayload;
using ::google::cloud::storage::testing::MockHashFunction;
using ::google::cloud::storage::testing::canonical_errors::PermanentError;
using ::google::cloud::testing_util::IsOk;
using ::google::cloud::testing_util::IsProtoEqual;
using ::google::cloud::testing_util::ScopedLog;
using ::google::cloud::testing_util::StatusIs;
using ::google::protobuf::TextFormat;
using ::testing::_;
using ::testing::An;
using ::testing::AtLeast;
using ::testing::ElementsAre;
using ::testing::HasSubstr;
using ::testing::Optional;
using ::testing::ResultOf;
using ::testing::VariantWith;

using HashUpdateType =
    std::conditional_t<std::is_same<absl::Cord, ContentType>::value,
                       absl::Cord const&, absl::string_view>;

TEST(ReadRange, BasicLifecycle) {
  ReadRange actual(10000, 40);
  EXPECT_FALSE(actual.IsDone());
  auto range = google::storage::v2::ReadRange{};
  auto constexpr kRange0 = R"pb(
    read_id: 7 read_offset: 10000 read_length: 40
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kRange0, &range));
  EXPECT_THAT(actual.RangeForResume(7), Optional(IsProtoEqual(range)));

  auto pending = actual.Read();
  EXPECT_FALSE(pending.is_ready());

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data { content: "0123456789" }
    read_range { read_offset: 10000 read_length: 10 read_id: 7 }
    range_end: false
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));
  actual.OnRead(std::move(data));

  EXPECT_TRUE(pending.is_ready());
  EXPECT_THAT(pending.get(),
              VariantWith<ReadPayload>(ResultOf(
                  "contents", [](ReadPayload const& p) { return p.contents(); },
                  ElementsAre("0123456789"))));
  range = google::storage::v2::ReadRange{};
  auto constexpr kRange1 = R"pb(
    read_id: 7 read_offset: 10010 read_length: 30
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kRange1, &range));
  EXPECT_THAT(actual.RangeForResume(7), Optional(IsProtoEqual(range)));

  auto constexpr kData1 = R"pb(
    checksummed_data { content: "1234567890" }
    read_range { read_offset: 10020 read_length: 10 read_id: 7 }
    range_end: false
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData1, &data));
  actual.OnRead(std::move(data));

  pending = actual.Read();
  EXPECT_TRUE(pending.is_ready());
  EXPECT_THAT(pending.get(),
              VariantWith<ReadPayload>(ResultOf(
                  "contents", [](ReadPayload const& p) { return p.contents(); },
                  ElementsAre("1234567890"))));

  data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData2 = R"pb(
    checksummed_data { content: "2345678901" }
    read_range { read_offset: 10030 read_length: 10 read_id: 7 }
    range_end: true
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData2, &data));
  actual.OnRead(std::move(data));

  EXPECT_TRUE(actual.IsDone());
  EXPECT_FALSE(actual.RangeForResume(7).has_value());

  pending = actual.Read();
  EXPECT_TRUE(pending.is_ready());
  EXPECT_THAT(pending.get(),
              VariantWith<ReadPayload>(ResultOf(
                  "contents", [](ReadPayload const& p) { return p.contents(); },
                  ElementsAre("2345678901"))));

  actual.OnFinish(Status{});
  EXPECT_THAT(actual.Read().get(), VariantWith<Status>(IsOk()));
  // A second Read() should be harmless.
  EXPECT_THAT(actual.Read().get(), VariantWith<Status>(IsOk()));
}

TEST(ReadRange, Error) {
  ReadRange actual(10000, 40);
  auto pending = actual.Read();
  EXPECT_FALSE(pending.is_ready());
  actual.OnFinish(PermanentError());

  EXPECT_THAT(pending.get(),
              VariantWith<Status>(StatusIs(PermanentError().code())));
}

TEST(ReadRange, Queue) {
  ReadRange actual(10000, 40);

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data { content: "0123456789" }
    read_range { read_offset: 10000 read_length: 10 read_id: 7 }
    range_end: false
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));
  actual.OnRead(std::move(data));

  auto constexpr kData1 = R"pb(
    checksummed_data { content: "1234567890" }
    read_range { read_offset: 10020 read_length: 10 read_id: 7 }
    range_end: false
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData1, &data));
  actual.OnRead(std::move(data));

  auto matcher = ResultOf(
      "contents",
      [](ReadPayload const& p) {
        // For small strings, absl::Cord may choose to merge the strings into a
        // single value. Testing with `ElementsAre()` won't work in all
        // environments.
        std::string m;
        for (auto sv : p.contents()) {
          m += std::string(sv);
        }
        return m;
      },
      "01234567891234567890");
  EXPECT_THAT(actual.Read().get(), VariantWith<ReadPayload>(matcher));
}

TEST(ReadRange, HashFunctionCalled) {
  auto hash_function = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash_function, Update(0, An<HashUpdateType>(), _))
      .Times(AtLeast(1));

  ReadRange actual(0, 10, hash_function);
  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data { content: "1234567890" }
    read_range { read_offset: 0 read_length: 10 read_id: 7 }
    range_end: false
  )pb";

  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));
  actual.OnRead(std::move(data));
}

TEST(ReadRange, FullObjectChecksumValidationMismatch) {
  auto hash_function =
      std::make_shared<storage::internal::Crc32cHashFunction>();
  auto hash_validator =
      std::make_unique<storage::internal::Crc32cHashValidator>();

  storage::internal::HashValues expected_hashes;
  expected_hashes.crc32c = "n3tPLw==";  // Some expected hash
  hash_validator->ProcessHashValues(expected_hashes);

  ReadRange actual(0, 10, hash_function, std::move(hash_validator));

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data { content: "1234567890" }
    read_range { read_offset: 0 read_length: 10 read_id: 7 }
    range_end: true
  )pb";

  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));

  auto pending = actual.Read();
  actual.OnRead(std::move(data));

  EXPECT_TRUE(actual.IsDone());

  // First read gets the data
  EXPECT_TRUE(pending.is_ready());
  EXPECT_THAT(pending.get(), VariantWith<ReadPayload>(_));

  // Second read gets the error
  auto next_read = actual.Read();
  EXPECT_TRUE(next_read.is_ready());
  EXPECT_THAT(next_read.get(),
              VariantWith<Status>(StatusIs(StatusCode::kDataLoss)));
}

TEST(ReadRange, FullObjectChecksumValidationMismatchMD5) {
  auto hash_function = std::shared_ptr<storage::internal::HashFunction>(
      storage::internal::MD5HashFunction::Create());
  auto hash_validator = std::make_unique<storage::internal::MD5HashValidator>();

  storage::internal::HashValues expected_hashes;
  expected_hashes.md5 = "wrong-md5-hash";
  hash_validator->ProcessHashValues(expected_hashes);

  ReadRange actual(0, 43, std::move(hash_function), std::move(hash_validator));

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data {
      content: "The quick brown fox jumps over the lazy dog"
      crc32c: 576848900
    }
    read_range { read_offset: 0 read_length: 43 read_id: 7 }
    range_end: true
  )pb";

  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));

  auto pending = actual.Read();
  actual.OnRead(std::move(data));

  EXPECT_TRUE(actual.IsDone());

  // First read gets the data
  EXPECT_TRUE(pending.is_ready());
  EXPECT_THAT(pending.get(), VariantWith<ReadPayload>(_));

  // Second read gets the error
  auto next_read = actual.Read();
  EXPECT_TRUE(next_read.is_ready());
  EXPECT_THAT(next_read.get(),
              VariantWith<Status>(StatusIs(StatusCode::kDataLoss)));
}

TEST(ReadRange, FullObjectChecksumValidationMismatchComposite) {
  auto hash_function = std::make_shared<storage::internal::CompositeFunction>(
      std::make_unique<storage::internal::Crc32cHashFunction>(),
      storage::internal::MD5HashFunction::Create());
  auto hash_validator = std::make_unique<storage::internal::CompositeValidator>(
      std::make_unique<storage::internal::Crc32cHashValidator>(),
      std::make_unique<storage::internal::MD5HashValidator>());

  storage::internal::HashValues expected_hashes;
  expected_hashes.crc32c = "wrong-crc32c";
  expected_hashes.md5 = "wrong-md5";
  hash_validator->ProcessHashValues(expected_hashes);

  ReadRange actual(0, 43, hash_function, std::move(hash_validator));

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data {
      content: "The quick brown fox jumps over the lazy dog"
      crc32c: 576848900
    }
    read_range { read_offset: 0 read_length: 43 read_id: 7 }
    range_end: true
  )pb";

  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));

  auto pending = actual.Read();
  actual.OnRead(std::move(data));

  EXPECT_TRUE(actual.IsDone());

  // First read gets the data
  EXPECT_TRUE(pending.is_ready());
  EXPECT_THAT(pending.get(), VariantWith<ReadPayload>(_));

  // Second read gets the error
  auto next_read = actual.Read();
  EXPECT_TRUE(next_read.is_ready());
  EXPECT_THAT(next_read.get(),
              VariantWith<Status>(StatusIs(StatusCode::kDataLoss)));
}

TEST(ReadRange, FullObjectChecksumValidationSuccessComposite) {
  auto hash_function = std::make_shared<storage::internal::CompositeFunction>(
      std::make_unique<storage::internal::Crc32cHashFunction>(),
      storage::internal::MD5HashFunction::Create());
  auto hash_validator = std::make_unique<storage::internal::CompositeValidator>(
      std::make_unique<storage::internal::Crc32cHashValidator>(),
      std::make_unique<storage::internal::MD5HashValidator>());

  storage::internal::HashValues expected_hashes;
  // CRC32C of "The quick brown fox jumps over the lazy dog" is "ImIEBA=="
  // MD5 of "The quick brown fox jumps over the lazy dog" is
  // "nhB9nTcrtoJr2B01QqQZ1g=="
  expected_hashes.crc32c = "ImIEBA==";
  expected_hashes.md5 = "nhB9nTcrtoJr2B01QqQZ1g==";
  hash_validator->ProcessHashValues(expected_hashes);

  ReadRange actual(0, 43, hash_function, std::move(hash_validator));

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data {
      content: "The quick brown fox jumps over the lazy dog"
      crc32c: 576848900
    }
    read_range { read_offset: 0 read_length: 43 read_id: 7 }
    range_end: true
  )pb";

  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));

  auto pending = actual.Read();
  actual.OnRead(std::move(data));

  EXPECT_TRUE(actual.IsDone());

  // First read gets the data
  EXPECT_TRUE(pending.is_ready());
  EXPECT_THAT(pending.get(), VariantWith<ReadPayload>(_));

  // Second read gets OK status instead of DataLoss
  auto next_read = actual.Read();
  EXPECT_TRUE(next_read.is_ready());
  EXPECT_THAT(next_read.get(), VariantWith<Status>(IsOk()));
}

TEST(ReadRange, OverrunLogging) {
  ScopedLog log;
  ReadRange actual(0, 10, "my-bucket", "my-object");

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data { content: "012345678901234" }
    read_range { read_offset: 0 read_length: 10 read_id: 7 }
    range_end: true
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));

  auto pending = actual.Read();
  actual.OnRead(std::move(data));

  auto lines = log.ExtractLines();
  EXPECT_EQ(lines.size(), 1);
  EXPECT_THAT(
      lines[0],
      HasSubstr(
          "storage: received 5 more bytes than requested from GCS for bucket "
          "\"my-bucket\", object \"my-object\""));
}

TEST(ReadRange, ReadLastLessIndexNoLogging) {
  ScopedLog log;
  // Simulating ReadLast(100) where GCS returns 50 bytes (e.g. object size is
  // 50)
  ReadRange actual(-100, 100, "my-bucket", "my-object");

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data {
      content: "01234567890123456789012345678901234567890123456789"
    }
    read_range { read_offset: -100 read_length: 100 read_id: 7 }
    range_end: true
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));

  auto pending = actual.Read();
  actual.OnRead(std::move(data));

  auto lines = log.ExtractLines();
  EXPECT_TRUE(lines.empty());
}

TEST(ReadRange, ReadLastOvershootLogging) {
  ScopedLog log;
  // Simulating ReadLast(50) where GCS returns 60 bytes (overshoot by 10)
  ReadRange actual(-50, 50, "my-bucket", "my-object");

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data {
      content: "012345678901234567890123456789012345678901234567890123456789"
    }
    read_range { read_offset: -50 read_length: 50 read_id: 7 }
    range_end: true
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));

  auto pending = actual.Read();
  actual.OnRead(std::move(data));

  auto lines = log.ExtractLines();
  EXPECT_EQ(lines.size(), 1);
  EXPECT_THAT(
      lines[0],
      HasSubstr(
          "storage: received 10 more bytes than requested from GCS for bucket "
          "\"my-bucket\", object \"my-object\""));
}

TEST(ReadRange, TranscodingSuppressesWarning) {
  ScopedLog log;
  ReadRange actual(0, 10, "my-bucket", "my-object");

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data { content: "012345678901234" }
    read_range { read_offset: 0 read_length: 10 read_id: 7 }
    range_end: false
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));

  auto pending = actual.Read();
  actual.OnRead(std::move(data), /*is_transcoded=*/true);

  auto lines = log.ExtractLines();
  EXPECT_TRUE(lines.empty());
}

TEST(ReadRange, ZeroLengthOverrunLogging) {
  ScopedLog log;
  // Pass 0 as the limit (not nullopt, which would mean read to end).
  ReadRange actual(0, std::make_optional<std::int64_t>(0), "my-bucket",
                   "my-object");

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data { content: "1" }
    read_range { read_offset: 0 read_length: 0 read_id: 7 }
    range_end: true
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));

  auto pending = actual.Read();
  actual.OnRead(std::move(data));

  auto lines = log.ExtractLines();
  EXPECT_EQ(lines.size(), 1);
  EXPECT_THAT(
      lines[0],
      HasSubstr(
          "storage: received 1 more bytes than requested from GCS for bucket "
          "\"my-bucket\", object \"my-object\""));
}

TEST(ReadRange, ReadLastOverrunLogging) {
  ScopedLog log;
  // ReadLast(5) is represented by start = -5, limit = 5.
  ReadRange actual(-5, std::make_optional<std::int64_t>(5), "my-bucket",
                   "my-object");

  // GCS returns 10 bytes (overrun of 5 bytes)
  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data { content: "0123456789" }
    read_range { read_offset: -5 read_length: 5 read_id: 7 }
    range_end: true
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));

  auto pending = actual.Read();
  actual.OnRead(std::move(data));

  auto lines = log.ExtractLines();
  EXPECT_EQ(lines.size(), 1);
  EXPECT_THAT(
      lines[0],
      HasSubstr(
          "storage: received 5 more bytes than requested from GCS for bucket "
          "\"my-bucket\", object \"my-object\""));
}

TEST(ReadRange, TranscodingIgnoresChecksumMismatch) {
  auto hash_function =
      std::make_shared<storage::internal::Crc32cHashFunction>();
  auto hash_validator =
      std::make_unique<storage::internal::Crc32cHashValidator>();

  storage::internal::HashValues expected_hashes;
  expected_hashes.crc32c = "wrong-crc32c";
  hash_validator->ProcessHashValues(expected_hashes);

  ReadRange actual(0, 10, hash_function, std::move(hash_validator), "my-bucket",
                   "my-object");

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data { content: "0123456789" crc32c: 576848900 }
    read_range { read_offset: 0 read_length: 10 read_id: 7 }
    range_end: true
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));

  auto pending = actual.Read();
  // Pass is_transcoded = true to suppress the checksum mismatch error!
  actual.OnRead(std::move(data), /*is_transcoded=*/true);

  EXPECT_TRUE(actual.IsDone());
  EXPECT_TRUE(pending.is_ready());
  EXPECT_THAT(pending.get(), VariantWith<ReadPayload>(_));

  // The second read should return Status::OK instead of DataLossError!
  auto next_read = actual.Read();
  EXPECT_TRUE(next_read.is_ready());
  EXPECT_THAT(next_read.get(), VariantWith<Status>(IsOk()));
}

TEST(ReadRange, NoResumeIfRequestSatisfied) {
  ReadRange actual(0, 10, "my-bucket", "my-object");

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data { content: "0123456789" }
    read_range { read_offset: 0 read_length: 10 read_id: 7 }
    range_end: false
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));

  auto pending = actual.Read();
  actual.OnRead(std::move(data));

  // The range is fully satisfied (10 bytes received for 10-byte request)
  // RangeForResume should return nullopt to prevent resuming!
  auto resume = actual.RangeForResume(42);
  EXPECT_FALSE(resume.has_value());
}

TEST(ReadRange, NoResumeIfRequestExceeded) {
  ReadRange actual(0, 10, "my-bucket", "my-object");

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData0 = R"pb(
    checksummed_data { content: "012345678901234" }
    read_range { read_offset: 0 read_length: 10 read_id: 7 }
    range_end: false
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData0, &data));

  auto pending = actual.Read();
  actual.OnRead(std::move(data));

  // The range is exceeded (15 bytes received for 10-byte request)
  // RangeForResume should return nullopt to prevent resuming!
  auto resume = actual.RangeForResume(42);
  EXPECT_FALSE(resume.has_value());
}

TEST(ReadRange, DeduplicateRangesBasic) {
  std::vector<ReadRangeConfig> ranges = {
      {0, 10},  {10, 10}, {0, 10},  // Duplicate
      {20, 10}, {10, 10},           // Duplicate
  };

  auto deduped = DeduplicateRanges(ranges);
  ASSERT_EQ(deduped.size(), 3);
  EXPECT_EQ(deduped[0].config.offset, 0);
  EXPECT_EQ(deduped[0].config.length, 10);
  EXPECT_EQ(deduped[0].read_id, 1);

  EXPECT_EQ(deduped[1].config.offset, 10);
  EXPECT_EQ(deduped[1].config.length, 10);
  EXPECT_EQ(deduped[1].read_id, 2);

  EXPECT_EQ(deduped[2].config.offset, 20);
  EXPECT_EQ(deduped[2].config.length, 10);
  EXPECT_EQ(deduped[2].read_id, 3);
}

TEST(ReadRange, DeduplicateRangesInitialId) {
  std::vector<ReadRangeConfig> ranges = {
      {0, 10},
  };

  auto deduped = DeduplicateRanges(ranges, /*initial_id=*/5);
  ASSERT_EQ(deduped.size(), 1);
  EXPECT_EQ(deduped[0].config.offset, 0);
  EXPECT_EQ(deduped[0].config.length, 10);
  EXPECT_EQ(deduped[0].read_id, 6);
}

/// @test Verify that single chunk receiving all requested bytes auto-completes
/// the range even if range_end is false.
TEST(ReadRange, AutoCompleteRangeEndWhenLengthZero) {
  ReadRange actual(10000, 10);
  EXPECT_FALSE(actual.IsDone());
  future<ReadRange::ReadResponse> pending = actual.Read();
  EXPECT_FALSE(pending.is_ready());

  auto data = google::storage::v2::ObjectRangeData{};
  auto constexpr kData = R"pb(
    checksummed_data { content: "0123456789" }
    read_range { read_offset: 10000 read_length: 10 read_id: 7 }
    range_end: false
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kData, &data));
  actual.OnRead(std::move(data));

  EXPECT_TRUE(pending.is_ready());
  EXPECT_THAT(pending.get(),
              VariantWith<ReadPayload>(ResultOf(
                  "contents", [](ReadPayload const& p) { return p.contents(); },
                  ElementsAre("0123456789"))));

  // Verify that when server delivers full requested bytes (10 bytes), even if
  // range_end was originally false in the proto, ReadRange completes
  // immediately.
  EXPECT_TRUE(actual.IsDone());
  future<ReadRange::ReadResponse> next_read = actual.Read();
  EXPECT_TRUE(next_read.is_ready());
  EXPECT_THAT(next_read.get(), VariantWith<Status>(IsOk()));
}

/// @test Verify that a bounded read (e.g. 10 bytes) delivered in multiple
/// chunks (e.g. 4 bytes, then 6 bytes) only auto-completes after the total
/// requested bytes are received.
TEST(ReadRange, MultiChunkBoundedRead) {
  ReadRange actual(10000, 10);
  EXPECT_FALSE(actual.IsDone());
  future<ReadRange::ReadResponse> pending1 = actual.Read();
  EXPECT_FALSE(pending1.is_ready());

  // First chunk: 4 bytes with range_end: false.
  auto data1 = google::storage::v2::ObjectRangeData{};
  auto constexpr kChunk1 = R"pb(
    checksummed_data { content: "0123" }
    read_range { read_offset: 10000 read_length: 10 read_id: 7 }
    range_end: false
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kChunk1, &data1));
  actual.OnRead(std::move(data1));

  EXPECT_TRUE(pending1.is_ready());
  EXPECT_THAT(pending1.get(),
              VariantWith<ReadPayload>(ResultOf(
                  "contents", [](ReadPayload const& p) { return p.contents(); },
                  ElementsAre("0123"))));
  // Stream should not be done yet because 6 bytes remain.
  EXPECT_FALSE(actual.IsDone());

  future<ReadRange::ReadResponse> pending2 = actual.Read();
  EXPECT_FALSE(pending2.is_ready());

  // Second chunk: remaining 6 bytes with range_end: false.
  auto data2 = google::storage::v2::ObjectRangeData{};
  auto constexpr kChunk2 = R"pb(
    checksummed_data { content: "456789" }
    read_range { read_offset: 10004 read_length: 6 read_id: 7 }
    range_end: false
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kChunk2, &data2));
  actual.OnRead(std::move(data2));

  EXPECT_TRUE(pending2.is_ready());
  EXPECT_THAT(pending2.get(),
              VariantWith<ReadPayload>(ResultOf(
                  "contents", [](ReadPayload const& p) { return p.contents(); },
                  ElementsAre("456789"))));

  // Now all 10 bytes are received, so the stream auto-completes.
  EXPECT_TRUE(actual.IsDone());
  future<ReadRange::ReadResponse> next_read = actual.Read();
  EXPECT_TRUE(next_read.is_ready());
  EXPECT_THAT(next_read.get(), VariantWith<Status>(IsOk()));
}

/// @test Verify that an unbounded read (requested_length == std::nullopt,
/// reading to EOF) does not auto-complete upon receiving data with range_end:
/// false.
TEST(ReadRange, UnboundedReadDoesNotAutoComplete) {
  // std::nullopt represents unbounded read to EOF in ReadRange.
  ReadRange actual(10000, std::nullopt);
  EXPECT_FALSE(actual.IsDone());
  future<ReadRange::ReadResponse> pending1 = actual.Read();
  EXPECT_FALSE(pending1.is_ready());

  auto data1 = google::storage::v2::ObjectRangeData{};
  auto constexpr kChunk = R"pb(
    checksummed_data { content: "0123456789" }
    read_range { read_offset: 10000 read_length: 0 read_id: 7 }
    range_end: false
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kChunk, &data1));
  actual.OnRead(std::move(data1));

  EXPECT_TRUE(pending1.is_ready());
  EXPECT_THAT(pending1.get(),
              VariantWith<ReadPayload>(ResultOf(
                  "contents", [](ReadPayload const& p) { return p.contents(); },
                  ElementsAre("0123456789"))));

  // Stream must remain open for future chunks until server sends range_end:
  // true.
  EXPECT_FALSE(actual.IsDone());
  future<ReadRange::ReadResponse> pending2 = actual.Read();
  EXPECT_FALSE(pending2.is_ready());

  // Final chunk from server with range_end: true.
  auto data2 = google::storage::v2::ObjectRangeData{};
  auto constexpr kFinalChunk = R"pb(
    checksummed_data { content: "ABCDEF" }
    read_range { read_offset: 10010 read_length: 0 read_id: 7 }
    range_end: true
  )pb";
  EXPECT_TRUE(TextFormat::ParseFromString(kFinalChunk, &data2));
  actual.OnRead(std::move(data2));

  EXPECT_TRUE(pending2.is_ready());
  EXPECT_THAT(pending2.get(),
              VariantWith<ReadPayload>(ResultOf(
                  "contents", [](ReadPayload const& p) { return p.contents(); },
                  ElementsAre("ABCDEF"))));

  EXPECT_TRUE(actual.IsDone());
  future<ReadRange::ReadResponse> next_read = actual.Read();
  EXPECT_TRUE(next_read.is_ready());
  EXPECT_THAT(next_read.get(), VariantWith<Status>(IsOk()));
}

}  // namespace
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_END
}  // namespace storage_internal
}  // namespace cloud
}  // namespace google
