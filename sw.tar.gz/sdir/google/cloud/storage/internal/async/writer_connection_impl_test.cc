// Copyright 2023 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// TODO(#16404): Remove deprecation disable include.
#include "google/cloud/internal/disable_deprecation_warnings.inc"
#include "google/cloud/storage/internal/async/writer_connection_impl.h"
#include "google/cloud/mocks/mock_async_streaming_read_write_rpc.h"
#include "google/cloud/storage/async/options.h"
#include "google/cloud/storage/internal/async/write_object.h"
#include "google/cloud/storage/internal/crc32c.h"
#include "google/cloud/storage/internal/grpc/ctype_cord_workaround.h"
#include "google/cloud/storage/internal/grpc/object_metadata_parser.h"
#include "google/cloud/storage/internal/hash_function_impl.h"
#include "google/cloud/storage/options.h"
#include "google/cloud/storage/testing/canonical_errors.h"
#include "google/cloud/storage/testing/mock_hash_function.h"
#include "google/cloud/internal/status_payload_keys.h"
#include "google/cloud/status.h"
#include "google/cloud/testing_util/async_sequencer.h"
#include "google/cloud/testing_util/is_proto_equal.h"
#include "google/cloud/testing_util/status_matchers.h"
#include <gmock/gmock.h>

namespace google {
namespace cloud {
namespace storage_internal {
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_BEGIN

using ::google::cloud::storage::WritePayload;
using ::google::cloud::storage::testing::MockHashFunction;
using ::google::cloud::storage::testing::canonical_errors::PermanentError;
using ::google::cloud::testing_util::AsyncSequencer;
using ::google::cloud::testing_util::IsOk;
using ::google::cloud::testing_util::IsOkAndHolds;
using ::google::cloud::testing_util::IsProtoEqual;
using ::google::cloud::testing_util::StatusIs;
using ::testing::_;
using ::testing::An;
using ::testing::Pair;
using ::testing::Return;
using ::testing::UnorderedElementsAre;
using ::testing::VariantWith;

using Request = google::storage::v2::BidiWriteObjectRequest;
using Response = google::storage::v2::BidiWriteObjectResponse;
using MockStream =
    ::google::cloud::mocks::MockAsyncStreamingReadWriteRpc<Request, Response>;

auto TestOptions() {
  return google::cloud::internal::MakeImmutableOptions(
      Options{}.set<storage::RestEndpointOption>(
          "https://test-only.p.googleapis.com"));
}

auto MakeTestResponse() {
  Response response;
  response.mutable_resource()->set_size(2048);
  response.mutable_resource()->set_bucket("projects/_/buckets/test-bucket");
  response.mutable_resource()->set_name("test-object");
  return response;
}

auto MakeTestObject() {
  auto object = google::storage::v2::Object{};
  object.set_size(2048);
  object.set_bucket("projects/_/buckets/test-bucket");
  object.set_name("test-object");
  return object;
}

auto MakeRequest() {
  auto request = Request{};
  request.set_upload_id("test-upload-id");
  // We use this field as a canary to verify the request fields are preserved.
  request.mutable_common_object_request_params()->set_encryption_algorithm(
      "test-only-algo");
  return request;
}

TEST(AsyncWriterConnectionTest, Basic) {
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Finish).WillOnce([] {
    return make_ready_future(Status{});
  });
  EXPECT_CALL(*mock, GetRequestMetadata)
      .WillOnce(Return(RpcMetadata{{{"hk0", "v0"}, {"hk1", "v1"}},
                                   {{"tk0", "v0"}, {"tk1", "v1"}}}));
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(0);
  EXPECT_CALL(*hash, Finish).Times(0);

  AsyncWriterConnectionImpl tested(TestOptions(), MakeRequest(),
                                   std::move(mock), hash, 1024);
  EXPECT_EQ(tested.UploadId(), "test-upload-id");
  EXPECT_THAT(tested.PersistedState(), VariantWith<std::int64_t>(1024));

  auto const metadata = tested.GetRequestMetadata();
  EXPECT_THAT(metadata.headers,
              UnorderedElementsAre(Pair("hk0", "v0"), Pair("hk1", "v1")));
  EXPECT_THAT(metadata.trailers,
              UnorderedElementsAre(Pair("tk0", "v0"), Pair("tk1", "v1")));
}

TEST(AsyncWriterConnectionTest, ResumeFinalized) {
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Finish).WillOnce([] {
    return make_ready_future(Status{});
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(0);
  EXPECT_CALL(*hash, Finish).Times(0);

  AsyncWriterConnectionImpl tested(TestOptions(), MakeRequest(),
                                   std::move(mock), hash, MakeTestObject());
  EXPECT_EQ(tested.UploadId(), "test-upload-id");
  EXPECT_THAT(tested.PersistedState(), VariantWith<google::storage::v2::Object>(
                                           IsProtoEqual(MakeTestObject())));
}

TEST(AsyncWriterConnectionTest, Cancel) {
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(2);
  EXPECT_CALL(*mock, Finish).WillOnce([] {
    return make_ready_future(Status{});
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(0);
  EXPECT_CALL(*hash, Finish).Times(0);

  AsyncWriterConnectionImpl tested(TestOptions(), MakeRequest(),
                                   std::move(mock), hash, 1024);
  tested.Cancel();
  EXPECT_EQ(tested.UploadId(), "test-upload-id");
  EXPECT_THAT(tested.PersistedState(), VariantWith<std::int64_t>(1024));
}

TEST(AsyncWriterConnectionTest, WriteSimple) {
  auto constexpr kChunk =
      google::storage::v2::ServiceConstants::MAX_WRITE_CHUNK_BYTES;
  auto constexpr kWriteCount = 4;
  auto constexpr kChunkCount = 5;
  std::int64_t offset = 3 * kChunk;

  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write)
      .Times(kWriteCount * kChunkCount)
      .WillRepeatedly([&](Request const& request, grpc::WriteOptions wopt) {
        EXPECT_FALSE(request.finish_write());
        EXPECT_EQ(request.write_offset(), offset);
        EXPECT_EQ(request.common_object_request_params().encryption_algorithm(),
                  "test-only-algo");
        EXPECT_FALSE(wopt.is_last_message());
        offset += kChunk;
        return sequencer.PushBack("Write");
      });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _))
      .Times(kWriteCount * kChunkCount);
  EXPECT_CALL(*hash, Finish).Times(0);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, offset);

  for (int i = 0; i != kWriteCount; ++i) {
    auto response =
        tested->Write(WritePayload(std::string(kChunkCount * kChunk, 'A')));
    for (int j = 0; j != kChunkCount; ++j) {
      auto next = sequencer.PopFrontWithName();
      ASSERT_THAT(next.second, "Write");
      next.first.set_value(true);
    }
    EXPECT_STATUS_OK(response.get());
  }

  tested = {};
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(true);
}

TEST(AsyncWriterConnectionTest, WriteError) {
  auto constexpr kChunk =
      google::storage::v2::ServiceConstants::MAX_WRITE_CHUNK_BYTES;

  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write).WillOnce([&](Request const&, grpc::WriteOptions) {
    return sequencer.PushBack("Write");
  });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(0);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 0);

  auto response = tested->Write(WritePayload(std::string(kChunk, 'A')));
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(false);  // Detect an error on Write()
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(false);  // Return an error from Finish()
  EXPECT_THAT(response.get(), StatusIs(PermanentError().code()));
}

TEST(AsyncWriterConnectionTest, UnexpectedWriteFailsWithoutError) {
  auto constexpr kChunk =
      google::storage::v2::ServiceConstants::MAX_WRITE_CHUNK_BYTES;

  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write).WillOnce([&](Request const&, grpc::WriteOptions) {
    return sequencer.PushBack("Write");
  });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(0);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 0);

  auto response = tested->Write(WritePayload(std::string(kChunk, 'A')));
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(false);  // Detect an error on Write()
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(true);  // Return success from Finish()
  EXPECT_THAT(response.get(), StatusIs(StatusCode::kInternal));
}

TEST(AsyncWriterConnectionTest, FinalizeEmpty) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions wopt) {
        EXPECT_TRUE(request.finish_write());
        EXPECT_TRUE(wopt.is_last_message());
        EXPECT_EQ(request.common_object_request_params().encryption_algorithm(),
                  "test-only-algo");
        return sequencer.PushBack("Write");
      });
  EXPECT_CALL(*mock, Read)
      .WillOnce([&]() {
        return sequencer.PushBack("Read1").then([](auto f) {
          if (!f.get()) return std::optional<Response>();
          return std::make_optional(MakeTestResponse());
        });
      })
      .WillOnce([&]() {
        return sequencer.PushBack("Read2").then([](auto f) {
          f.get();
          return std::optional<Response>();
        });
      });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(1);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 1024);
  auto response = tested->Finalize(WritePayload{});
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read1");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read2");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(true);

  auto object = response.get();
  EXPECT_THAT(object, IsOkAndHolds(IsProtoEqual(MakeTestObject())))
      << "=" << object->DebugString();

  tested = {};
}

TEST(AsyncWriterConnectionTest, FinalizeFails) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write).WillOnce([&](Request const&, grpc::WriteOptions) {
    return sequencer.PushBack("Write");
  });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(1);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 1024);
  auto response = tested->Finalize(WritePayload{});
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(false);  // Detect an error on Write()
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(false);  // Return success from Finish()
  EXPECT_THAT(response.get(), StatusIs(PermanentError().code()));
}

TEST(AsyncWriterConnectionTest, UnexpectedFinalizeFailsWithoutError) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write).WillOnce([&](Request const&, grpc::WriteOptions) {
    return sequencer.PushBack("Write");
  });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(1);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 1024);
  auto response = tested->Finalize(WritePayload{});
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(false);  // Detect an error on Write()
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(true);  // Return success from Finish()
  EXPECT_THAT(response.get(), StatusIs(StatusCode::kInternal));
}

TEST(AsyncWriterConnectionTest, QueryFinalFails) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write).WillOnce([&](Request const&, grpc::WriteOptions) {
    return sequencer.PushBack("Write");
  });
  EXPECT_CALL(*mock, Read).WillOnce([&]() {
    return sequencer.PushBack("Read").then([](auto f) {
      if (!f.get()) return std::optional<Response>();
      return std::make_optional(MakeTestResponse());
    });
  });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(1);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 1024);
  auto response = tested->Finalize(WritePayload{});
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read");
  next.first.set_value(false);  // Detect an error during Read()
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(false);  // Return success from Finish()
  EXPECT_THAT(response.get(), StatusIs(PermanentError().code()));
}

TEST(AsyncWriterConnectionTest, UnexpectedQueryFinalFailsWithoutError) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write).WillOnce([&](Request const&, grpc::WriteOptions) {
    return sequencer.PushBack("Write");
  });
  EXPECT_CALL(*mock, Read).WillOnce([&]() {
    return sequencer.PushBack("Read").then([](auto f) {
      if (!f.get()) return std::optional<Response>();
      return std::make_optional(MakeTestResponse());
    });
  });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(1);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 1024);
  auto response = tested->Finalize(WritePayload{});
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read");
  next.first.set_value(false);  // Detect an error during Read()
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(true);  // Return success from Finish()
  EXPECT_THAT(response.get(), StatusIs(StatusCode::kInternal));
}

TEST(AsyncWriterConnectionTest, UnexpectedQueryFinalMissingResource) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write).WillOnce([&](Request const&, grpc::WriteOptions) {
    return sequencer.PushBack("Write");
  });
  EXPECT_CALL(*mock, Read)
      .WillOnce([&]() {
        return sequencer.PushBack("Read1").then([](auto f) {
          if (!f.get()) return std::optional<Response>();
          return std::make_optional(Response{});
        });
      })
      .WillOnce([&]() {
        return sequencer.PushBack("Read2").then([](auto f) {
          f.get();
          return std::optional<Response>();
        });
      });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(1);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 0);
  auto response = tested->Finalize(WritePayload{});
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read1");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read2");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(true);

  EXPECT_THAT(response.get(), StatusIs(StatusCode::kInternal));

  tested = {};
}

TEST(AsyncWriterConnectionTest, FlushEmpty) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions wopt) {
        EXPECT_TRUE(request.flush());
        EXPECT_TRUE(request.state_lookup());
        EXPECT_FALSE(wopt.is_last_message());
        EXPECT_EQ(request.common_object_request_params().encryption_algorithm(),
                  "test-only-algo");
        return sequencer.PushBack("Write");
      });
  EXPECT_CALL(*mock, Read).WillOnce([&]() {
    return sequencer.PushBack("Read").then([](auto f) {
      if (!f.get()) return std::optional<Response>();
      auto response = Response{};
      response.set_persisted_size(16384);
      return std::make_optional(std::move(response));
    });
  });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(0);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 1024);
  auto flush = tested->Flush(WritePayload{});
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read");
  next.first.set_value(true);
  EXPECT_THAT(flush.get(), IsOk());

  auto query = tested->Query();
  EXPECT_THAT(query.get(), IsOkAndHolds(16384));

  tested = {};
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(true);
}

TEST(AsyncWriterConnectionTest, FlushFails) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write).WillOnce([&](Request const&, grpc::WriteOptions) {
    return sequencer.PushBack("Write");
  });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(1);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 1024);
  auto response = tested->Finalize(WritePayload{});
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(false);  // Detect an error on Write()
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(false);  // Return error from Finish()
  EXPECT_THAT(response.get(), StatusIs(PermanentError().code()));
}

TEST(AsyncWriterConnectionTest, UnexpectedFlushFailsWithoutError) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write).WillOnce([&](Request const&, grpc::WriteOptions) {
    return sequencer.PushBack("Write");
  });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(1);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 1024);
  auto response = tested->Finalize(WritePayload{});
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(false);  // Detect an error on Write()
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(true);  // Return success from Finish()
  EXPECT_THAT(response.get(), StatusIs(StatusCode::kInternal));
}

TEST(AsyncWriterConnectionTest, FlushFailsOnRead) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write).WillOnce([&](Request const&, grpc::WriteOptions) {
    return sequencer.PushBack("Write");
  });
  EXPECT_CALL(*mock, Read).WillOnce([&]() {
    return sequencer.PushBack("Read").then(
        [](auto) { return std::optional<Response>(); });
  });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 1024);
  auto flush = tested->Flush(WritePayload{std::string("fake-payload-data")});
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read");
  next.first.set_value(false);  // Detect error from Read()

  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(false);  // Return error from Finish()
  EXPECT_THAT(flush.get(), StatusIs(PermanentError().code()));
}

TEST(AsyncWriterConnectionTest, UnexpectedFlushFailsOnReadWithoutError) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write).WillOnce([&](Request const&, grpc::WriteOptions) {
    return sequencer.PushBack("Write");
  });
  EXPECT_CALL(*mock, Read).WillOnce([&]() {
    return sequencer.PushBack("Read").then(
        [](auto) { return std::optional<Response>(); });
  });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 1024);
  auto flush = tested->Flush(WritePayload{std::string("fake-payload-data")});
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read");
  next.first.set_value(false);  // Detect error from Read()

  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(true);  // Return success from Finish()
  EXPECT_THAT(flush.get(), StatusIs(StatusCode::kInternal));
}

TEST(AsyncWriterConnectionTest, FlushFailsWithRedirect) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write).WillOnce([&](Request const&, grpc::WriteOptions) {
    return sequencer.PushBack("Write");
  });
  EXPECT_CALL(*mock, Read).WillOnce([&]() {
    return sequencer.PushBack("Read").then(
        [](auto) { return std::optional<Response>(); });
  });

  google::rpc::Status rpc_status;
  rpc_status.set_code(static_cast<int>(StatusCode::kAborted));
  rpc_status.set_message("redirect");
  google::storage::v2::BidiWriteObjectRedirectedError redirect;
  redirect.mutable_write_handle()->set_handle("redirect-handle");
  redirect.set_routing_token("redirect-token");
  redirect.set_generation(4321);
  (void)rpc_status.add_details()->PackFrom(redirect);
  std::string rpc_status_payload;
  ASSERT_TRUE(rpc_status.SerializeToString(&rpc_status_payload));
  Status status(StatusCode::kAborted, "redirect");
  internal::SetPayload(status, internal::StatusPayloadGrpcProto(),
                       rpc_status_payload);

  EXPECT_CALL(*mock, Finish).WillOnce([&, status] {
    return sequencer.PushBack("Finish").then([s = status](auto f) -> Status {
      if (f.get()) return Status{};
      return s;
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 1024);
  auto flush = tested->Flush(WritePayload{std::string("fake-payload-data")});
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read");
  next.first.set_value(false);  // Detect error from Read()

  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(false);  // Return error from Finish()
  EXPECT_THAT(flush.get(), StatusIs(StatusCode::kAborted));
}

TEST(AsyncWriterConnectionTest, FinalizeAppendableNoChecksum) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions wopt) {
        EXPECT_TRUE(request.finish_write());
        EXPECT_TRUE(wopt.is_last_message());
        EXPECT_EQ(request.common_object_request_params().encryption_algorithm(),
                  "test-only-algo");
        EXPECT_FALSE(request.has_object_checksums());
        return sequencer.PushBack("Write");
      });
  EXPECT_CALL(*mock, Read)
      .WillOnce([&]() {
        return sequencer.PushBack("Read1").then([](auto f) {
          if (!f.get()) return std::optional<Response>();
          return std::make_optional(MakeTestResponse());
        });
      })
      .WillOnce([&]() {
        return sequencer.PushBack("Read2").then([](auto f) {
          f.get();
          return std::optional<Response>();
        });
      });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(0);

  auto request = MakeRequest();
  request.mutable_write_object_spec()->set_appendable(true);
  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), std::move(request), std::move(mock), hash, 1024);
  auto response = tested->Finalize(WritePayload{});
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read1");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read2");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(true);

  auto object = response.get();
  EXPECT_THAT(object, IsOkAndHolds(IsProtoEqual(MakeTestObject())))
      << "=" << object->DebugString();

  tested = {};
}

TEST(AsyncWriterConnectionTest, FinalizeAppendableWithExpectedChecksum) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions wopt) {
        EXPECT_TRUE(request.finish_write());
        EXPECT_TRUE(wopt.is_last_message());
        EXPECT_EQ(request.common_object_request_params().encryption_algorithm(),
                  "test-only-algo");
        EXPECT_TRUE(request.has_object_checksums());
        EXPECT_EQ(request.object_checksums().crc32c(), 123456);
        return sequencer.PushBack("Write");
      });
  EXPECT_CALL(*mock, Read)
      .WillOnce([&]() {
        return sequencer.PushBack("Read1").then([](auto f) {
          if (!f.get()) return std::optional<Response>();
          return std::make_optional(MakeTestResponse());
        });
      })
      .WillOnce([&]() {
        return sequencer.PushBack("Read2").then([](auto f) {
          f.get();
          return std::optional<Response>();
        });
      });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(0);

  auto request = MakeRequest();
  request.mutable_write_object_spec()->set_appendable(true);

  auto options = internal::MakeImmutableOptions(
      Options{}.set<storage::UseCrc32cValueOption>(123456));

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      options, std::move(request), std::move(mock), hash, 1024);
  auto response = tested->Finalize(WritePayload{});

  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read1");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read2");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(true);

  auto object = response.get();
  EXPECT_THAT(object, IsOkAndHolds(IsProtoEqual(MakeTestObject())))
      << "=" << object->DebugString();

  tested = {};
}

TEST(AsyncWriterConnectionTest,
     FinalizeAppendableWithExpectedChecksumFromCurrentOptions) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions wopt) {
        EXPECT_TRUE(request.finish_write());
        EXPECT_TRUE(wopt.is_last_message());
        EXPECT_EQ(request.common_object_request_params().encryption_algorithm(),
                  "test-only-algo");
        EXPECT_TRUE(request.has_object_checksums());
        EXPECT_EQ(request.object_checksums().crc32c(), 654321);
        return sequencer.PushBack("Write");
      });
  EXPECT_CALL(*mock, Read)
      .WillOnce([&]() {
        return sequencer.PushBack("Read1").then([](auto f) {
          if (!f.get()) return std::optional<Response>();
          return std::make_optional(MakeTestResponse());
        });
      })
      .WillOnce([&]() {
        return sequencer.PushBack("Read2").then([](auto f) {
          f.get();
          return std::optional<Response>();
        });
      });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  // It shouldn't call Finish() because we use kFinalize!
  EXPECT_CALL(*hash, Finish).Times(0);

  auto request = MakeRequest();
  request.mutable_write_object_spec()->set_appendable(true);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), std::move(request), std::move(mock), hash, 1024);

  internal::OptionsSpan span(
      Options{}.set<storage::UseCrc32cValueOption>(654321));
  auto response = tested->Finalize(WritePayload{});

  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read1");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read2");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(true);

  auto object = response.get();
  EXPECT_THAT(object, IsOkAndHolds(IsProtoEqual(MakeTestObject())))
      << "=" << object->DebugString();

  tested = {};
}

TEST(AsyncWriterConnectionTest,
     FinalizeNonAppendableWithExpectedChecksumFromCurrentOptions) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions wopt) {
        EXPECT_TRUE(request.finish_write());
        EXPECT_TRUE(wopt.is_last_message());
        EXPECT_EQ(request.common_object_request_params().encryption_algorithm(),
                  "test-only-algo");
        EXPECT_TRUE(request.has_object_checksums());
        EXPECT_EQ(request.object_checksums().crc32c(), 654321);
        return sequencer.PushBack("Write");
      });
  EXPECT_CALL(*mock, Read)
      .WillOnce([&]() {
        return sequencer.PushBack("Read1").then([](auto f) {
          if (!f.get()) return std::optional<Response>();
          return std::make_optional(MakeTestResponse());
        });
      })
      .WillOnce([&]() {
        return sequencer.PushBack("Read2").then([](auto f) {
          f.get();
          return std::optional<Response>();
        });
      });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  // It shouldn't call Finish() because we use kFinalize!
  EXPECT_CALL(*hash, Finish).Times(0);

  auto request = MakeRequest();
  // Ensure it's explicitly not appendable.
  request.mutable_write_object_spec()->set_appendable(false);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), std::move(request), std::move(mock), hash, 1024);

  internal::OptionsSpan span(
      Options{}.set<storage::UseCrc32cValueOption>(654321));
  auto response = tested->Finalize(WritePayload{});

  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read1");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read2");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(true);

  auto object = response.get();
  EXPECT_THAT(object, IsOkAndHolds(IsProtoEqual(MakeTestObject())))
      << "=" << object->DebugString();

  tested = {};
}

TEST(AsyncWriterConnectionTest,
     FinalizeNonAppendableWithExpectedMD5FromCurrentOptions) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions wopt) {
        EXPECT_TRUE(request.finish_write());
        EXPECT_TRUE(wopt.is_last_message());
        EXPECT_EQ(request.common_object_request_params().encryption_algorithm(),
                  "test-only-algo");
        EXPECT_TRUE(request.has_object_checksums());
        EXPECT_EQ(request.object_checksums().md5_hash(), "test-md5");
        return sequencer.PushBack("Write");
      });
  EXPECT_CALL(*mock, Read)
      .WillOnce([&]() {
        return sequencer.PushBack("Read1").then([](auto f) {
          if (!f.get()) return std::optional<Response>();
          return std::make_optional(MakeTestResponse());
        });
      })
      .WillOnce([&]() {
        return sequencer.PushBack("Read2").then([](auto f) {
          f.get();
          return std::optional<Response>();
        });
      });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  // It shouldn't call Finish() because we use kFinalize!
  EXPECT_CALL(*hash, Finish).Times(0);

  auto request = MakeRequest();
  // Ensure it's explicitly not appendable.
  request.mutable_write_object_spec()->set_appendable(false);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), std::move(request), std::move(mock), hash, 1024);

  internal::OptionsSpan span(
      Options{}.set<storage::UseMD5ValueOption>("test-md5"));
  auto response = tested->Finalize(WritePayload{});

  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read1");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read2");
  next.first.set_value(true);
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(true);

  auto object = response.get();
  EXPECT_THAT(object, IsOkAndHolds(IsProtoEqual(MakeTestObject())))
      << "=" << object->DebugString();

  tested = {};
}

TEST(AsyncWriterConnectionTest, ResumeWithHandle) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  std::vector<std::string> seen_handles;

  EXPECT_CALL(*mock, Write)
      .Times(1)
      .WillRepeatedly([&](Request const& req, grpc::WriteOptions) {
        EXPECT_TRUE(req.has_append_object_spec());
        EXPECT_TRUE(req.append_object_spec().has_write_handle());
        seen_handles.push_back(
            req.append_object_spec().write_handle().handle());
        return sequencer.PushBack("Write");
      });

  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Finish).WillOnce([] {
    return make_ready_future(Status{});
  });

  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(0);

  google::storage::v2::BidiWriteObjectRequest req;
  req.mutable_append_object_spec()->set_bucket("bucket");
  req.mutable_append_object_spec()->set_object("object");
  req.mutable_append_object_spec()->mutable_write_handle()->set_handle(
      "test-handle");

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), req, std::move(mock), hash, 0);

  auto result = tested->Write(WritePayload("payload"));
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(true);
  EXPECT_STATUS_OK(result.get());

  ASSERT_EQ(seen_handles.size(), 1);
  EXPECT_EQ(seen_handles[0], "test-handle");
}

TEST(AsyncWriterConnectionTest, CloseEmpty) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions wopt) {
        EXPECT_TRUE(request.flush());
        EXPECT_TRUE(request.state_lookup());
        EXPECT_TRUE(wopt.is_last_message());
        EXPECT_EQ(request.common_object_request_params().encryption_algorithm(),
                  "test-only-algo");
        return sequencer.PushBack("Write");
      });
  EXPECT_CALL(*mock, Read)
      .WillOnce([&] {
        return sequencer.PushBack("Read1").then([](auto f) {
          if (!f.get()) return std::optional<Response>();
          return std::make_optional(Response{});
        });
      })
      .WillOnce([&] {
        return sequencer.PushBack("Read2").then([](auto f) {
          f.get();
          return std::optional<Response>();
        });
      });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(0);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 1024);
  auto close = tested->Close(WritePayload{});
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read1");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read2");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(true);

  EXPECT_THAT(close.get(), IsOk());
  tested = {};
}

TEST(AsyncWriterConnectionTest, CloseError) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write).WillOnce([&](Request const&, grpc::WriteOptions) {
    return sequencer.PushBack("Write");
  });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(0);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 1024);
  auto response = tested->Close(WritePayload{});
  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(false);  // Detect an error on Write()
  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(false);  // Return error from Finish()
  EXPECT_THAT(response.get(), StatusIs(PermanentError().code()));
}

TEST(AsyncWriterConnectionTest, CloseMultipleResponsesBeforeEOF) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);
  EXPECT_CALL(*mock, Write)
      .WillOnce([&](Request const& request, grpc::WriteOptions wopt) {
        EXPECT_TRUE(request.flush());
        EXPECT_TRUE(request.state_lookup());
        EXPECT_TRUE(wopt.is_last_message());
        return sequencer.PushBack("Write");
      });

  // Simulate the scenario where Close() prompts the server to return multiple
  // intermediate response messages before sending EOF. The client should
  // successfully consume all responses and complete Finish() cleanly without
  // hanging.
  EXPECT_CALL(*mock, Read)
      .WillOnce([&] {
        return sequencer.PushBack("Read1").then([](auto f) {
          f.get();
          return std::make_optional(Response{});
        });
      })
      .WillOnce([&] {
        return sequencer.PushBack("Read2").then([](auto f) {
          f.get();
          auto r = Response{};
          r.mutable_write_handle()->set_handle("intermediate-handle");
          return std::make_optional(r);
        });
      })
      .WillOnce([&] {
        return sequencer.PushBack("Read3").then([](auto f) {
          f.get();
          return std::optional<Response>();
        });
      });
  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });
  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);
  EXPECT_CALL(*hash, Finish).Times(0);

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), MakeRequest(), std::move(mock), hash, 1024);
  auto close = tested->Close(WritePayload{});

  auto next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Write");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read1");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read2");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Read3");
  next.first.set_value(true);

  next = sequencer.PopFrontWithName();
  ASSERT_THAT(next.second, "Finish");
  next.first.set_value(true);

  EXPECT_THAT(close.get(), IsOk());
  tested = {};
}

TEST(AsyncWriterConnectionTest, FlushConsumesIntermediateMessagesBeforeSize) {
  AsyncSequencer<bool> sequencer;
  auto mock = std::make_unique<MockStream>();
  EXPECT_CALL(*mock, Cancel).Times(1);

  EXPECT_CALL(*mock, Write).WillOnce([&](Request const&, grpc::WriteOptions) {
    return sequencer.PushBack("Write");
  });

  // We simulate a scenario where Flush() causes GCS to send
  // multiple responses. The first is an intermediate message (no size).
  // The second is the actual persisted_size response.
  EXPECT_CALL(*mock, Read)
      .WillOnce([&]() {
        return sequencer.PushBack("Read1").then([](auto f) {
          f.get();
          auto r = Response{};
          r.mutable_write_handle()->set_handle("intermediate-handle");
          return std::make_optional(r);
        });
      })
      .WillOnce([&]() {
        return sequencer.PushBack("Read2").then([](auto f) {
          f.get();
          auto r = Response{};
          r.set_persisted_size(1024);
          return std::make_optional(r);
        });
      });

  EXPECT_CALL(*mock, Finish).WillOnce([&] {
    return sequencer.PushBack("Finish").then([](auto f) {
      if (f.get()) return Status{};
      return PermanentError();
    });
  });

  auto hash = std::make_shared<MockHashFunction>();
  EXPECT_CALL(*hash, Update(_, An<absl::Cord const&>(), _)).Times(1);

  Request request;
  request.mutable_write_object_spec()->mutable_resource()->set_bucket(
      "test-bucket");
  request.mutable_write_object_spec()->mutable_resource()->set_name(
      "test-object");

  auto tested = std::make_unique<AsyncWriterConnectionImpl>(
      TestOptions(), request, std::move(mock), hash,
      /*persisted_size=*/0);

  auto flush = tested->Flush(WritePayload{std::string("fake-payload")});

  auto next = sequencer.PopFrontWithName();
  ASSERT_EQ(next.second, "Write");
  next.first.set_value(true);

  // The client requests the first read. We satisfy it with the intermediate
  // message.
  next = sequencer.PopFrontWithName();
  ASSERT_EQ(next.second, "Read1");
  next.first.set_value(true);

  // The client requests the second read. We satisfy it with the persisted_size.
  next = sequencer.PopFrontWithName();
  ASSERT_EQ(next.second, "Read2");
  next.first.set_value(true);

  // The flush should finally resolve successfully.
  auto result = flush.get();
  EXPECT_STATUS_OK(result);

  tested.reset();
  next = sequencer.PopFrontWithName();
  ASSERT_EQ(next.second, "Finish");
  next.first.set_value(true);
}

GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_END
}  // namespace storage_internal
}  // namespace cloud
}  // namespace google
