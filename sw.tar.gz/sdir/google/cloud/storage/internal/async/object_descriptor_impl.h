// Copyright 2024 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef GOOGLE_CLOUD_CPP_GOOGLE_CLOUD_STORAGE_INTERNAL_ASYNC_OBJECT_DESCRIPTOR_IMPL_H
#define GOOGLE_CLOUD_CPP_GOOGLE_CLOUD_STORAGE_INTERNAL_ASYNC_OBJECT_DESCRIPTOR_IMPL_H

#include "google/cloud/storage/async/object_descriptor_connection.h"
#include "google/cloud/storage/async/resume_policy.h"
#include "google/cloud/storage/internal/async/multi_stream_manager.h"
#include "google/cloud/storage/internal/async/object_descriptor_reader.h"
#include "google/cloud/storage/internal/async/open_stream.h"
#include "google/cloud/storage/internal/async/read_range.h"
#include "google/cloud/storage/options.h"
#include "google/cloud/status.h"
#include "google/cloud/version.h"
#include "google/storage/v2/storage.pb.h"
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <set>
#include <unordered_map>

namespace google {
namespace cloud {
namespace storage_internal {
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_BEGIN

struct ReadStream : public storage_internal::StreamBase {
  ReadStream(std::shared_ptr<OpenStream> stream,
             std::unique_ptr<storage::ResumePolicy> resume_policy)
      : stream(std::move(stream)), resume_policy(std::move(resume_policy)) {}

  void Cancel() override {
    if (stream) stream->Cancel();
  }

  std::shared_ptr<OpenStream> stream;
  std::unique_ptr<storage::ResumePolicy> resume_policy;
  google::storage::v2::BidiReadObjectRequest next_request;
  bool write_pending = false;
  bool read_pending = false;
  bool resuming = false;
  // Consecutive resume attempts for *this* stream, used only for diagnostics.
  // Guarded by the descriptor's `mu_`.
  //
  // A successful re-open builds a new `ReadStream` and calls
  // `ResumePolicy::OnStartSuccess()` on it, so the count starts over there.
  // That is the intent: the number reports how many times in a row the current
  // failure has been retried, not how many times the download has ever hiccuped
  // since it started.
  int resume_count = 0;
};

class ObjectDescriptorImpl
    : public storage::ObjectDescriptorConnection,
      public std::enable_shared_from_this<ObjectDescriptorImpl> {
 public:
  ObjectDescriptorImpl(std::unique_ptr<storage::ResumePolicy> resume_policy,
                       OpenStreamFactory make_stream,
                       google::storage::v2::BidiReadObjectSpec read_object_spec,
                       std::shared_ptr<OpenStream> stream, Options options = {},
                       std::function<bool()> transport_ok = {});

  /**
   * As above, but re-opens that follow a clean close use a separate factory.
   *
   * `ResumePolicy::OnFinish()` returns `kContinue` for an OK status, so a
   * stream that ends cleanly is re-opened too. That re-open routinely races
   * with descriptor teardown and fails with an internal "stream closed
   * successfully" error, which the retry policy counts as transient. Handing
   * those re-opens a factory that does not report its retries keeps a download
   * that in fact succeeded from emitting warnings.
   *
   * Every other re-open -- a resume after a stream failure, a resume after a
   * per-range error, and the streams `MakeSubsequentStream()` opens -- uses
   * @p make_stream, so a genuine stall while reconnecting is still reported.
   *
   * @p make_clean_resume_stream may be empty, in which case @p make_stream is
   * used for those re-opens as well.
   */
  ObjectDescriptorImpl(std::unique_ptr<storage::ResumePolicy> resume_policy,
                       OpenStreamFactory make_stream,
                       OpenStreamFactory make_clean_resume_stream,
                       google::storage::v2::BidiReadObjectSpec read_object_spec,
                       std::shared_ptr<OpenStream> stream, Options options,
                       std::function<bool()> transport_ok);

  ~ObjectDescriptorImpl() override;

  // Start the read loop.
  void Start(google::storage::v2::BidiReadObjectResponse first_response);

  // Cancel the underlying RPC and stop the resume loop.
  void Cancel();

  Options options() const override { return options_; }

  // Return the object metadata. This is only available after the first `Read()`
  // returns.
  std::optional<google::storage::v2::Object> metadata() const override;

  // Start a new ranged read.
  std::unique_ptr<storage::AsyncReaderConnection> Read(ReadParams p) override;

  void MakeSubsequentStream() override;

  std::size_t StreamSize() const;

  bool IsOpen() const override;

 private:
  using StreamManager = MultiStreamManager<ReadStream, ReadRange>;
  using StreamIterator =
      MultiStreamManager<ReadStream, ReadRange>::StreamIterator;

  std::weak_ptr<ObjectDescriptorImpl> WeakFromThis() {
    return shared_from_this();
  }

  // Logic to ensure a background stream is always connecting which must be
  // invoked while holding `mu_`.
  void AssurePendingStreamQueued(std::unique_lock<std::mutex> const&);

  void Flush(std::unique_lock<std::mutex> lk,
             std::shared_ptr<ReadStream> const& read_stream);
  void OnWrite(std::shared_ptr<ReadStream> const& read_stream,
               std::shared_ptr<OpenStream> const& stream, bool ok);
  void DoRead(std::unique_lock<std::mutex> lk,
              std::shared_ptr<ReadStream> const& read_stream);
  void OnRead(
      std::shared_ptr<ReadStream> const& read_stream,
      std::shared_ptr<OpenStream> const& stream,
      std::optional<google::storage::v2::BidiReadObjectResponse> response);
  void DoFinish(std::unique_lock<std::mutex> lk,
                std::shared_ptr<ReadStream> const& read_stream,
                std::shared_ptr<OpenStream> const& stream);
  void OnFinish(std::shared_ptr<ReadStream> const& read_stream,
                std::shared_ptr<OpenStream> const& stream,
                Status const& status);
  // Why a finished stream is being re-opened, as decided by
  // `ClassifyFinish()`.
  enum class ResumeKind {
    // The stream is not re-opened. The ranges are notified of the failure.
    kNo,
    // The server reported a per-range `BidiReadObjectError`. The affected
    // ranges have been completed with their own status; the stream is
    // re-opened to carry the remaining ones. The stream itself did not fail,
    // so this is not a retry.
    kRangeError,
    // The resume policy accepted the stream-level status. This is a retry when
    // the status is an error; a stream that ends cleanly lands here too,
    // because `ResumePolicy::OnFinish()` answers `kContinue` for an OK status.
    kStreamFailure,
  };

  void Resume(std::shared_ptr<ReadStream> const& read_stream,
              Status const& status, google::rpc::Status const& proto_status,
              ResumeKind kind);
  void OnResume(std::shared_ptr<ReadStream> const& old_read_stream,
                std::shared_ptr<OpenStream> const& old_stream,
                StatusOr<OpenStreamResult> result);
  ResumeKind ClassifyFinish(std::shared_ptr<ReadStream> const& read_stream,
                            Status const& status,
                            google::rpc::Status const& proto_status);
  bool ApplyPacingAndCheckEviction(std::int64_t id, std::size_t chunk_size,
                                   StreamIterator it);

  std::shared_ptr<storage::internal::HashFunction> CreateHashFunction(
      bool is_full_read) const;
  std::unique_ptr<storage::internal::HashValidator> CreateHashValidator(
      bool is_full_read) const;

  std::unique_ptr<storage::ResumePolicy> resume_policy_prototype_;
  OpenStreamFactory make_stream_;
  // Used only to re-open a stream that ended cleanly. See the constructor.
  // May be empty, in which case `make_stream_` is used for those re-opens too.
  OpenStreamFactory make_clean_resume_stream_;

  mutable std::mutex mu_;
  google::storage::v2::BidiReadObjectSpec read_object_spec_;
  std::optional<google::storage::v2::Object> metadata_;
  std::int64_t read_id_generator_ = 0;

  // Information about a pre-warmed range that has not been claimed yet.
  struct PrewarmedRange {
    std::shared_ptr<ReadRange> range;
    std::int64_t read_id;
  };
  // Cache of pre-warmed ranges, keyed by (offset, length).
  using PrewarmedRangesMap =
      std::map<std::pair<std::int64_t, std::int64_t>, PrewarmedRange>;
  PrewarmedRangesMap prewarmed_ranges_;

  struct UnclaimedRangeState {
    std::size_t bytes_buffered;
    PrewarmedRangesMap::iterator cache_it;
  };

  // Map of read_id to unclaimed range state (bytes buffered and original key).
  std::unordered_map<std::int64_t, UnclaimedRangeState> unclaimed_ranges_;
  // Set capturing tombstones for evicted pre-warmed ranges.
  std::set<std::pair<std::int64_t, std::int64_t>> evicted_ranges_;
  // Total bytes currently buffered across all unclaimed pre-warmed ranges.
  std::size_t total_prewarmed_bytes_buffered_ = 0;
  // Maximum bytes allowed to be buffered across all unclaimed pre-warmed ranges
  // before we start evicting them.
  std::size_t max_prewarmed_buffer_size_ =
      5 * 1024 * 1024;  // Default 5 MiB pacing limit

  Options options_;
  std::unique_ptr<StreamManager> stream_manager_;
  // The future for the proactive background stream.
  google::cloud::future<
      google::cloud::StatusOr<storage_internal::OpenStreamResult>>
      pending_stream_;
  bool cancelled_ = false;
  bool has_initial_read_ranges_ = false;
  std::function<bool()> transport_ok_;
};

GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_END
}  // namespace storage_internal
}  // namespace cloud
}  // namespace google

#endif  // GOOGLE_CLOUD_CPP_GOOGLE_CLOUD_STORAGE_INTERNAL_ASYNC_OBJECT_DESCRIPTOR_IMPL_H
