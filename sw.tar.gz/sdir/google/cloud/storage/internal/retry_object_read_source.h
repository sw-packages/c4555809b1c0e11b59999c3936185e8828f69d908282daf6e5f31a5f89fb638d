// Copyright 2019 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef GOOGLE_CLOUD_CPP_GOOGLE_CLOUD_STORAGE_INTERNAL_RETRY_OBJECT_READ_SOURCE_H
#define GOOGLE_CLOUD_CPP_GOOGLE_CLOUD_STORAGE_INTERNAL_RETRY_OBJECT_READ_SOURCE_H

#include "google/cloud/storage/internal/object_read_source.h"
#include "google/cloud/storage/internal/object_requests.h"
#include "google/cloud/storage/retry_policy.h"
#include "google/cloud/storage/version.h"
#include "google/cloud/options.h"
#include <chrono>
#include <functional>
#include <memory>
#include <optional>

namespace google {
namespace cloud {
namespace storage {
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_BEGIN
namespace internal {

enum OffsetDirection { kFromBeginning, kFromEnd };

/**
 * A data source for ObjectReadStreambuf.
 *
 * This object represents an open download stream. It is an abstract class
 * because (a) we do not want to expose CURL types in the public headers, and
 * (b) we want to break the functionality for retry vs. simple downloads in
 * different classes.
 */
class RetryObjectReadSource : public ObjectReadSource {
 public:
  using ReadSourceFactory =
      std::function<StatusOr<std::unique_ptr<ObjectReadSource>>(
          ReadObjectRangeRequest const&, RetryPolicy&, BackoffPolicy&)>;

  RetryObjectReadSource(ReadSourceFactory factory,
                        google::cloud::internal::ImmutableOptions options,
                        ReadObjectRangeRequest request,
                        std::unique_ptr<ObjectReadSource> child,
                        std::unique_ptr<RetryPolicy> retry_policy,
                        std::unique_ptr<BackoffPolicy> backoff_policy,
                        std::function<void(std::chrono::milliseconds)> backoff);
  RetryObjectReadSource(ReadSourceFactory factory,
                        google::cloud::internal::ImmutableOptions options,
                        ReadObjectRangeRequest request,
                        std::unique_ptr<ObjectReadSource> child,
                        std::unique_ptr<RetryPolicy> retry_policy,
                        std::unique_ptr<BackoffPolicy> backoff_policy);

  bool IsOpen() const override { return child_ && child_->IsOpen(); }
  StatusOr<HttpResponse> Close() override {
    // `Read()` releases the child when it retries, and leaves it released if
    // the retry policy is then exhausted. There is no connection left to
    // close, and callers (e.g. `ObjectReadStreambuf::Close()`) do not check
    // `IsOpen()` first.
    if (!child_) return HttpResponse{HttpStatusCode::kOk, {}, {}};
    return child_->Close();
  }
  StatusOr<ReadSourceResult> Read(char* buf, std::size_t n) override;

 private:
  bool HandleResult(StatusOr<ReadSourceResult> const& r);
  Status MakeChild(RetryPolicy& retry_policy, BackoffPolicy& backoff_policy);
  StatusOr<std::unique_ptr<ObjectReadSource>> ReadDiscard(
      std::unique_ptr<ObjectReadSource> child, std::int64_t count) const;

  ReadSourceFactory factory_;
  google::cloud::internal::ImmutableOptions options_;
  ReadObjectRangeRequest request_;
  std::unique_ptr<ObjectReadSource> child_;
  std::optional<std::int64_t> generation_;
  std::unique_ptr<RetryPolicy const> retry_policy_prototype_;
  std::unique_ptr<BackoffPolicy const> backoff_policy_prototype_;
  OffsetDirection offset_direction_;
  std::int64_t current_offset_ = 0;
  bool is_gunzipped_ = false;
  std::function<void(std::chrono::milliseconds)> backoff_;
};

}  // namespace internal
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_END
}  // namespace storage
}  // namespace cloud
}  // namespace google

#endif  // GOOGLE_CLOUD_CPP_GOOGLE_CLOUD_STORAGE_INTERNAL_RETRY_OBJECT_READ_SOURCE_H
