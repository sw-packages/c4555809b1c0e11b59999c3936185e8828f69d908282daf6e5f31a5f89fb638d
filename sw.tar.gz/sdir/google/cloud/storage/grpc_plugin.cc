// Copyright 2020 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "google/cloud/storage/grpc_plugin.h"
#include "google/cloud/storage/internal/connection_factory.h"
#include "google/cloud/storage/internal/generic_stub_factory.h"
#include "google/cloud/storage/internal/grpc/default_options.h"
#include "google/cloud/storage/internal/grpc/enable_metrics.h"
#include "google/cloud/storage/internal/grpc/stub.h"
#include "google/cloud/storage/internal/tracing_connection.h"
#include "google/cloud/background_threads.h"
#include "google/cloud/grpc_options.h"
#include "google/cloud/internal/getenv.h"
#include "google/cloud/internal/opentelemetry.h"
#include <functional>
#include <memory>
#include <utility>

namespace google {
namespace cloud {
namespace storage {
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_BEGIN

google::cloud::storage::Client MakeGrpcClient(Options opts) {
  opts = google::cloud::storage_internal::DefaultOptionsGrpc(std::move(opts));
  storage_internal::EnableGrpcMetrics(opts);
  auto stub = std::make_unique<storage_internal::GrpcStub>(opts);
  storage_internal::TracingConnection::AsyncRunner runner;
  if (google::cloud::internal::TracingEnabled(opts)) {
    runner = [cq = stub->cq()](std::function<void()> f) mutable {
      cq.RunAsync(std::move(f));
    };
  }
  return storage::internal::ClientImplDetails::CreateWithoutDecorations(
      MakeStorageConnection(std::move(opts), std::move(stub),
                            std::move(runner)));
}

GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_END
}  // namespace storage
}  // namespace cloud
}  // namespace google
